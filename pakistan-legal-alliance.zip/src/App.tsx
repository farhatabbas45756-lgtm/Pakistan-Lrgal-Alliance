import React, { useState, useEffect, useRef } from 'react';
import { ActivePage, UserState, AnnouncementItem, AdminActionLog } from './types';
import { ANNOUNCEMENTS } from './data';
import Header from './components/Header';
import Footer from './components/Footer';
import DashboardSidebar from './components/DashboardSidebar';
import DashboardTopbar from './components/DashboardTopbar';
import PageHome from './components/PageHome';
import PageAbout from './components/PageAbout';
import PagePracticeAreas from './components/PagePracticeAreas';
import PageNewsGazette from './components/PageNewsGazette';
import PageRecruitment from './components/PageRecruitment';
import PageContact from './components/PageContact';
import PageLogin from './components/PageLogin';
import PageForgotPassword from './components/PageForgotPassword';
import PageResetPassword from './components/PageResetPassword';
import PageDashboard from './components/PageDashboard';
import PageAnnouncements from './components/PageAnnouncements';
import PageDirectory from './components/PageDirectory';
import PageAdminAnnouncements from './components/PageAdminAnnouncements';
import PageAdminLogs from './components/PageAdminLogs';
import PageAdminMemberCreate from './components/PageAdminMemberCreate';
import { onAuthStateChanged, signOut as firebaseSignOut } from 'firebase/auth';
import { doc, getDoc, collection, query, orderBy, onSnapshot } from 'firebase/firestore';
import { auth, db } from './lib/firebase';

export default function App() {
  // Navigation State (single-page router)
  const [activePage, setActivePage] = useState<ActivePage>('home');
  
  // Simulated Authentication State
  const [userState, setUserState] = useState<UserState>({
    isAuthenticated: false,
    name: '',
    memberId: '',
    email: '',
  });

  // Announcements database state
  const [announcements, setAnnouncements] = useState<AnnouncementItem[]>(() => {
    const localData = localStorage.getItem('pla_announcements_database');
    if (localData) {
      try {
        return JSON.parse(localData);
      } catch (e) {
        console.error('Error loading announcements from localStorage', e);
      }
    }
    return ANNOUNCEMENTS;
  });

  // Save announcements to localStorage when updated
  useEffect(() => {
    localStorage.setItem('pla_announcements_database', JSON.stringify(announcements));
  }, [announcements]);

  // Sync announcements from Firestore in real-time
  useEffect(() => {
    const q = query(collection(db, 'announcements'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const items: AnnouncementItem[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        let dateStr = '';
        if (data.createdAt) {
          try {
            const t = data.createdAt;
            if (t.toDate) {
              dateStr = t.toDate().toISOString().split('T')[0];
            } else if (t.seconds) {
              dateStr = new Date(t.seconds * 1000).toISOString().split('T')[0];
            }
          } catch (e) {
            console.error('Error parsing createdAt timestamp:', e);
          }
        }
        if (!dateStr) {
          dateStr = data.date || new Date().toISOString().split('T')[0];
        }

        items.push({
          id: docSnap.id,
          title: data.title || '',
          body: data.body || '',
          date: dateStr,
          postedBy: data.postedBy || 'PLA Secretariat',
          chapter: data.chapter || 'All Chapters',
          category: data.category || 'Notice',
          eventDate: data.eventDate || '',
          eventLocation: data.eventLocation || '',
        });
      });

      if (items.length > 0) {
        setAnnouncements(items);
      } else {
        // Fallback to static data if Firestore is empty
        const enrichedStatic = ANNOUNCEMENTS.map(ann => {
          let category: any = ann.category || 'Notice';
          let eventDate = ann.eventDate || '';
          let eventLocation = ann.eventLocation || '';
          if (ann.id === 'ANN-2') {
            category = 'Upcoming Event';
            eventDate = '2026-09-12';
            eventLocation = 'Main Head Office, Lahore, Punjab';
          } else if (ann.id === 'ANN-3') {
            category = 'Publication';
          } else if (ann.id === 'ANN-5') {
            category = 'Statement';
          }
          return {
            ...ann,
            category,
            eventDate,
            eventLocation
          };
        });
        setAnnouncements(enrichedStatic);
      }
    }, (error) => {
      console.warn('Firestore announcements listener failed (fallback active):', error);
      const enrichedStatic = ANNOUNCEMENTS.map(ann => {
        let category: any = ann.category || 'Notice';
        let eventDate = ann.eventDate || '';
        let eventLocation = ann.eventLocation || '';
        if (ann.id === 'ANN-2') {
          category = 'Upcoming Event';
          eventDate = '2026-09-12';
          eventLocation = 'Main Head Office, Lahore, Punjab';
        } else if (ann.id === 'ANN-3') {
          category = 'Publication';
        } else if (ann.id === 'ANN-5') {
          category = 'Statement';
        }
        return {
          ...ann,
          category,
          eventDate,
          eventLocation
        };
      });
      setAnnouncements(enrichedStatic);
    });

    return () => unsubscribe();
  }, []);

  // Admin action logs state
  const [actionLogs, setActionLogs] = useState<AdminActionLog[]>(() => {
    const localData = localStorage.getItem('pla_admin_action_logs');
    if (localData) {
      try {
        return JSON.parse(localData);
      } catch (e) {
        console.error('Error loading action logs', e);
      }
    }
    return [
      {
        id: 'LOG-001',
        timestamp: '2026-07-18 10:15:32',
        adminName: 'Nabeel Saad Khan',
        actionType: 'MEMBER_RESET',
        details: 'Initial system boot: Verified and signed 16 founding members into the PLA central cryptographically secured database.',
      },
      {
        id: 'LOG-002',
        timestamp: '2026-07-18 14:40:10',
        adminName: 'Rehana Rehmet',
        actionType: 'ANNOUNCEMENT_PUBLISH',
        details: 'Published founding bulletin: "PLA Central Council Releases Statement on Judicial Appointments" to the public registry.',
      }
    ];
  });

  // Save action logs to localStorage
  useEffect(() => {
    localStorage.setItem('pla_admin_action_logs', JSON.stringify(actionLogs));
  }, [actionLogs]);

  // Log action helper
  const addActionLog = (actionType: AdminActionLog['actionType'], details: string) => {
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, '0');
    const timestamp = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
    
    const newLog: AdminActionLog = {
      id: `LOG-${Date.now()}`,
      timestamp,
      adminName: userState.name || 'System Administrator',
      actionType,
      details,
    };
    setActionLogs((prev) => [newLog, ...prev]);
  };

  const handleClearLogs = () => {
    if (confirm('Are you sure you want to permanently clear the audit logs? This action is irreversible.')) {
      setActionLogs([]);
    }
  };

  // Mobile drawer controls for dashboard
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Listen to Auth State Changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        try {
          // Force refresh the ID token to pull in current custom claims
          const idTokenResult = await user.getIdTokenResult(true);
          const isAdmin = idTokenResult.claims.admin === true;

          // Call the server registerSignIn to sync claims & document state
          const idToken = await user.getIdToken();
          const response = await fetch('/api/registerSignIn', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${idToken}`
            }
          });

          let serverIsAdmin = isAdmin;
          if (response.ok) {
            const resData = await response.json();
            if (resData.isAdmin) {
              serverIsAdmin = true;
            }
          }

          // Fetch member details from Firestore
          const memberDoc = await getDoc(doc(db, 'members', user.uid));
          let displayName = user.displayName || user.email?.split('@')[0].toUpperCase() || 'MEMBER';
          let memberId = 'PLA-MEMBER';

          if (memberDoc.exists()) {
            const data = memberDoc.data();
            displayName = data.displayName || displayName;
            memberId = data.memberId || memberId;
          }

          setUserState({
            isAuthenticated: true,
            name: displayName,
            memberId,
            email: user.email || '',
            isAdmin: serverIsAdmin,
            token: idToken,
          });
        } catch (err) {
          console.error('Error syncing authentication state:', err);
        }
      }
    });
    return () => unsubscribe();
  }, []);

  // Motion reduced settings detection
  const [reducedMotion, setReducedMotion] = useState(false);
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    // Detect prefers-reduced-motion
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReducedMotion(mediaQuery.matches);
    const handler = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mediaQuery.addEventListener('change', handler);
    
    // Add scroll tracking for background crossfades
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });

    return () => {
      mediaQuery.removeEventListener('change', handler);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // Calculate backdrop crossfade opacity (from emerald to transparent paper)
  // Crossfades over the first 450px of scrolling past the hero.
  // Disabled if user prefers reduced motion.
  const backdropOpacity = reducedMotion ? 1 : Math.max(0, 1 - scrollY / 450);

  // Authentication triggers
  const handleSignIn = (name: string, email: string, memberId: string, isAdmin?: boolean, token?: string) => {
    setUserState({
      isAuthenticated: true,
      name,
      memberId,
      email,
      isAdmin,
      token,
    });
  };

  const handleSignOut = () => {
    firebaseSignOut(auth).catch(err => console.error('Firebase signout error:', err));
    setUserState({
      isAuthenticated: false,
      name: '',
      memberId: '',
      email: '',
      isAdmin: false,
    });
    setActivePage('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Check if current active page is a portal page (requires dashboard layout)
  const isPortalPage = activePage === 'dashboard' || activePage === 'announcements' || activePage === 'directory' || activePage === 'announcements-publishing' || activePage === 'admin-logs' || activePage === 'admin';

  // Navigation Guard: if user is not authenticated and tries to open portal, force login
  useEffect(() => {
    if (isPortalPage && !userState.isAuthenticated) {
      setActivePage('login');
      alert('Authentication required. Redirecting to legal member login portal.');
    }
  }, [activePage, userState.isAuthenticated, isPortalPage]);

  // Protect /admin page
  useEffect(() => {
    if (activePage === 'admin') {
      const verifyAdminAccess = async () => {
        const user = auth.currentUser;
        if (!user) {
          setActivePage('login');
          alert('Access denied. Administrator credentials required.');
          return;
        }

        try {
          // Force refresh the ID token
          const idTokenResult = await user.getIdTokenResult(true);
          if (idTokenResult.claims.admin !== true) {
            setActivePage('dashboard');
            alert('Access denied. You do not have administrator permissions.');
          }
        } catch (err) {
          console.error('Error verifying administrator claims:', err);
          setActivePage('dashboard');
        }
      };

      verifyAdminAccess();
    }
  }, [activePage, userState.isAuthenticated]);

  // Render Page Content based on route state
  const renderPageContent = () => {
    switch (activePage) {
      case 'home':
        return <PageHome onNavigate={setActivePage} />;
      case 'about':
        return <PageAbout />;
      case 'practice-areas':
        return <PagePracticeAreas onNavigate={setActivePage} />;
      case 'news-gazette':
        return <PageNewsGazette />;
      case 'recruitment':
        return <PageRecruitment />;
      case 'contact':
        return <PageContact />;
      case 'login':
        return <PageLogin onNavigate={setActivePage} onSignIn={handleSignIn} />;
      case 'forgot-password':
        return <PageForgotPassword onNavigate={setActivePage} />;
      case 'reset-password':
        return <PageResetPassword onNavigate={setActivePage} onSignIn={handleSignIn} />;
      case 'dashboard':
        return <PageDashboard onNavigate={setActivePage} userState={userState} announcements={announcements} />;
      case 'announcements':
        return <PageAnnouncements onNavigate={setActivePage} userState={userState} announcements={announcements} />;
      case 'directory':
        return <PageDirectory userState={userState} onLogAction={addActionLog} />;
      case 'announcements-publishing':
        return <PageAdminAnnouncements userState={userState} announcements={announcements} onLogAction={addActionLog} />;
      case 'admin-logs':
        return <PageAdminLogs userState={userState} actionLogs={actionLogs} onClearLogs={handleClearLogs} />;
      case 'admin':
        return <PageAdminMemberCreate userState={userState} onLogAction={addActionLog} />;
      default:
        return <PageHome onNavigate={setActivePage} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col relative bg-paper text-ink selection:bg-gold-light/45 selection:text-emerald-custom">
      
      {/* 
        GLOBAL MOTION LAYER - CROSSFADING BACKGROUND BACKDROP
        Rendered on public pages. Hero has dark green backdrop; as you scroll,
        the fixed emerald gradient fades out, revealing the elegant paper texture below.
      */}
      {!isPortalPage && (
        <div 
          className="fixed inset-0 w-full h-full bg-gradient-to-b from-[#0F3D2E] to-[#071F17] pointer-events-none z-0"
          style={{ 
            opacity: backdropOpacity,
            transition: reducedMotion ? 'none' : 'opacity 150ms ease-out',
          }}
          id="pla-fixed-backdrop"
        />
      )}

      {/* RENDER SHELL 1: PORTAL (DASHBOARD & ANNOUNCEMENTS) LAYOUT */}
      {isPortalPage && userState.isAuthenticated ? (
        <div className="flex h-screen overflow-hidden w-full relative z-10" id="pla-portal-shell">
          
          {/* Dashboard Sidebar */}
          <DashboardSidebar
            activePage={activePage}
            onNavigate={setActivePage}
            userState={userState}
            onSignOut={handleSignOut}
            isOpen={mobileSidebarOpen}
            onClose={() => setMobileSidebarOpen(false)}
          />

          {/* Main workspace container */}
          <div className="flex-1 flex flex-col md:pl-64 min-w-0">
            {/* Dashboard Topbar */}
            <DashboardTopbar
              activePage={activePage}
              onNavigate={setActivePage}
              userState={userState}
              onSignOut={handleSignOut}
              onToggleSidebar={() => setMobileSidebarOpen(!mobileSidebarOpen)}
            />

            {/* Scrollable workspace content */}
            <main className="flex-grow overflow-y-auto bg-paper flex flex-col">
              {renderPageContent()}
            </main>
          </div>

        </div>
      ) : (
        /* RENDER SHELL 2: PUBLIC GUEST LAYOUT (HOME, ABOUT, ETC.) */
        <div className="flex flex-col min-h-screen w-full relative z-10" id="pla-public-shell">
          {/* Public Header */}
          <Header
            activePage={activePage}
            onNavigate={setActivePage}
            userState={userState}
            onSignOut={handleSignOut}
          />

          {/* Core content body */}
          <main className="flex-grow w-full flex flex-col">
            {renderPageContent()}
          </main>

          {/* Public Footer */}
          <Footer onNavigate={setActivePage} />
        </div>
      )}

    </div>
  );
}
