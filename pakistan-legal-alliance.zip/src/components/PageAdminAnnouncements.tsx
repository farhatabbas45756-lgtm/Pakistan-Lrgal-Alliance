import React, { useState, useEffect } from 'react';
import { UserState, AnnouncementItem } from '../types';
import ScrollReveal from './ScrollReveal';
import { 
  ShieldAlert, 
  Plus, 
  Trash2, 
  Edit2, 
  CheckCircle, 
  AlertCircle,
  Calendar,
  MapPin,
  User,
  Bell,
  RefreshCw,
  X
} from 'lucide-react';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';

interface PageAdminAnnouncementsProps {
  userState: UserState;
  announcements: AnnouncementItem[];
  onLogAction?: (actionType: any, details: string) => void;
}

export default function PageAdminAnnouncements({ 
  userState, 
  announcements, 
  onLogAction 
}: PageAdminAnnouncementsProps) {
  
  // Hardcoded Secretariat email allow-list for UX enforcement
  const ALLOWED_ADMINS = [
    'thread.fia@gmail.com',
    'n.saad.khan@barcounsel.pk',
    'r.rehmet@barcounsel.pk',
    'c.numan.ali@barcounsel.pk'
  ];

  const hasAccess = userState.isAuthenticated && (
    userState.isAdmin || ALLOWED_ADMINS.includes(userState.email.toLowerCase())
  );

  // Form states
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [category, setCategory] = useState<'Upcoming Event' | 'Notice' | 'Publication' | 'Statement'>('Notice');
  const [eventDate, setEventDate] = useState('');
  const [eventLocation, setEventLocation] = useState('');
  const [chapter, setChapter] = useState('All Chapters');
  
  // Display name retrieved from members collection or userState.name
  const [adminDisplayName, setAdminDisplayName] = useState(userState.name || 'Farhat Abbas');

  // Edit mode tracking
  const [editId, setEditId] = useState<string | null>(null);

  // Interface message states
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Retrieve true display name from user's member doc on mount
  useEffect(() => {
    const fetchAdminDetails = async () => {
      if (userState.isAuthenticated) {
        try {
          const authUser = userState.email ? userState : null;
          // Look up if we can find in members db
          const uidMatch = announcements.find(a => a.postedBy.toLowerCase() === userState.name.toLowerCase());
          if (userState.name) {
            setAdminDisplayName(userState.name);
          }
        } catch (e) {
          console.error('Error matching admin name:', e);
        }
      }
    };
    fetchAdminDetails();
  }, [userState, announcements]);

  if (!hasAccess) {
    return (
      <div className="w-full flex-grow flex items-center justify-center p-6 bg-paper" id="pla-unauthorized-announcements">
        <ScrollReveal className="max-w-md w-full bg-paper border border-rose-200 p-8 text-center space-y-5 shadow-xs">
          <ShieldAlert size={48} className="text-rose-700 mx-auto" />
          <h2 className="font-serif text-xl font-bold text-rose-900 tracking-tight uppercase">
            Unauthorized Secretariat Decree
          </h2>
          <p className="text-xs text-ink-soft leading-relaxed font-sans">
            Access to the Announcements and Bulletins Decrees Console is restricted to designated Secretariat officers. Your account <strong>{userState.email || 'Anonymous'}</strong> does not possess active credentials in our master clearance registry.
          </p>
          <div className="text-[10px] font-mono text-rose-800 bg-rose-50 border border-rose-100 p-2.5">
            LOGGED ATTEMPT REF: SEC-AUTH-{Date.now()}
          </div>
        </ScrollReveal>
      </div>
    );
  }

  const handleCancelEdit = () => {
    setEditId(null);
    setTitle('');
    setBody('');
    setCategory('Notice');
    setEventDate('');
    setEventLocation('');
    setChapter('All Chapters');
    setErrorMessage(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !body || !category || !chapter) {
      setErrorMessage('Please fill in all required bulletin parameters.');
      return;
    }

    if (category === 'Upcoming Event' && (!eventDate || !eventLocation)) {
      setErrorMessage('Upcoming Events require event date and location.');
      return;
    }

    setIsSubmitting(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    const apiEndpoint = editId ? '/api/updateAnnouncement' : '/api/createAnnouncement';
    const payload = {
      id: editId,
      title: title.trim(),
      body: body.trim(),
      category,
      chapter,
      eventDate: category === 'Upcoming Event' ? eventDate : null,
      eventLocation: category === 'Upcoming Event' ? eventLocation : null,
    };

    try {
      const token = userState.token;
      const response = await fetch(apiEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token || ''}`,
        },
        body: JSON.stringify(payload),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || 'Failed to persist the bulletin registry state.');
      }

      setSuccessMessage(
        editId 
          ? 'Circular successfully revised in the master PLA ledger.' 
          : 'New decree successfully propagated to the central registry.'
      );

      // Reset form on success
      handleCancelEdit();
      setTimeout(() => setSuccessMessage(null), 4000);

      // Log action to Secretariat logs
      if (onLogAction) {
        onLogAction(
          editId ? 'ANNOUNCEMENT_PUBLISH' : 'ANNOUNCEMENT_PUBLISH',
          editId 
            ? `Revised bulletin "${payload.title}" (ID: PLA-${editId}) in regional registries.`
            : `Propagated central decree bulletin "${payload.title}" (ID: PLA-${result.id}) targeting Chapter: ${chapter}.`
        );
      }

    } catch (err: any) {
      console.error('Error persisting announcement:', err);
      setErrorMessage(err.message || 'An unexpected database error occurred during registry write.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEditClick = (ann: AnnouncementItem) => {
    setEditId(ann.id);
    setTitle(ann.title);
    setBody(ann.body);
    setCategory(ann.category || 'Notice');
    setEventDate(ann.eventDate || '');
    setEventLocation(ann.eventLocation || '');
    setChapter(ann.chapter || 'All Chapters');
    setErrorMessage(null);
    
    // Smooth scroll to form
    const formElement = document.getElementById('announcement-form-container');
    if (formElement) {
      formElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleDeleteClick = async (id: string, annTitle: string) => {
    if (!confirm(`Are you sure you want to permanently revoke bulletin "PLA-${id}: ${annTitle}"? This action is irreversible.`)) {
      return;
    }

    setErrorMessage(null);
    setSuccessMessage(null);

    try {
      const token = userState.token;
      const response = await fetch('/api/deleteAnnouncement', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token || ''}`,
        },
        body: JSON.stringify({ id }),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || 'Failed to revoke the bulletin.');
      }

      setSuccessMessage('Decree successfully expunged and revoked from the central database.');
      setTimeout(() => setSuccessMessage(null), 4000);

      if (onLogAction) {
        onLogAction(
          'ANNOUNCEMENT_DELETE',
          `Revoked and expunged official bulletin "${annTitle}" with ID: PLA-${id} from regional chapters.`
        );
      }
    } catch (err: any) {
      console.error('Error revoking announcement:', err);
      setErrorMessage(err.message || 'An unexpected database error occurred during registry purge.');
    }
  };

  const getCategoryPill = (cat?: string) => {
    switch (cat) {
      case 'Upcoming Event':
        return (
          <span className="inline-block px-2 py-0.5 border text-[9px] uppercase font-mono tracking-wider bg-purple-50 text-purple-800 border-purple-200">
            Upcoming Event
          </span>
        );
      case 'Publication':
        return (
          <span className="inline-block px-2 py-0.5 border text-[9px] uppercase font-mono tracking-wider bg-amber-50 text-amber-800 border-[#D8D0BC]">
            Publication
          </span>
        );
      case 'Statement':
        return (
          <span className="inline-block px-2 py-0.5 border text-[9px] uppercase font-mono tracking-wider bg-blue-50 text-blue-800 border-blue-200">
            Statement
          </span>
        );
      case 'Notice':
      default:
        return (
          <span className="inline-block px-2 py-0.5 border text-[9px] uppercase font-mono tracking-wider bg-emerald-50 text-emerald-800 border-emerald-200">
            Notice
          </span>
        );
    }
  };

  return (
    <div className="w-full flex-grow p-4 md:p-8" id="pla-admin-announcements">
      <div className="max-w-6xl mx-auto space-y-8">
        
        {/* Header Block */}
        <div className="border-b border-border-custom pb-4 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
          <div>
            <span className="font-mono text-[10px] text-gold-dark uppercase tracking-widest block font-bold">
              Registry Control Suite
            </span>
            <h2 className="font-serif text-xl font-bold text-emerald-custom uppercase mt-1">
              Announcements & decrees manager
            </h2>
            <p className="text-xs text-ink-soft font-sans mt-0.5">
              Draft, revised, or revoke official bulletins. Synchronized globally across all regional bar chapters.
            </p>
          </div>
        </div>

        {/* Status Alerts */}
        {successMessage && (
          <div className="bg-[#1C5A43]/10 border border-[#1C5A43]/30 p-4 flex items-center space-x-3 text-emerald-custom shadow-3xs animate-fade-in">
            <CheckCircle size={18} className="shrink-0" />
            <p className="text-xs font-sans font-medium">{successMessage}</p>
          </div>
        )}

        {/* Split Grid: Form (Left) & Registry (Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Form Panel */}
          <div className="lg:col-span-5 space-y-4" id="announcement-form-container">
            <div className="bg-paper border border-border-custom p-6 space-y-5 shadow-3xs">
              <div className="border-b border-border-custom/50 pb-2">
                <h3 className="font-serif text-sm font-bold text-emerald-custom uppercase flex items-center gap-2">
                  <Plus size={16} className="text-gold-dark" />
                  {editId ? 'Revise Circular decree' : 'Propagate New Circular'}
                </h3>
                {editId && (
                  <span className="block font-mono text-[8px] uppercase tracking-wider text-rose-800 mt-1">
                    * Modifying Circular ID: PLA-{editId}
                  </span>
                )}
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1 font-semibold">
                    Bulletin Title *
                  </label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Constitutional Bench Assignment Updates"
                    className="w-full bg-white border border-[#D8D0BC] px-3 py-2 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1 font-semibold">
                      Posted By (Author)
                    </label>
                    <input
                      type="text"
                      readOnly
                      disabled
                      value={adminDisplayName}
                      className="w-full bg-gray-50 border border-[#D8D0BC] px-3 py-2 font-sans text-xs text-ink-faint select-none cursor-not-allowed font-medium"
                    />
                  </div>
                  <div>
                    <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1 font-semibold">
                      Chapter Scope *
                    </label>
                    <select
                      value={chapter}
                      onChange={(e) => setChapter(e.target.value)}
                      className="w-full bg-white border border-[#D8D0BC] px-3 py-2 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
                    >
                      <option value="All Chapters">All Chapters</option>
                      <option value="Islamabad Chapter">Islamabad Chapter</option>
                      <option value="Lahore Chapter">Lahore Chapter</option>
                      <option value="Karachi Chapter">Karachi Chapter</option>
                      <option value="Peshawar Chapter">Peshawar Chapter</option>
                      <option value="Quetta Chapter">Quetta Chapter</option>
                      <option value="Central Secretariat">Central Secretariat</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1 font-semibold">
                    Bulletin Category *
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full bg-white border border-[#D8D0BC] px-3 py-2 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink font-sans"
                  >
                    <option value="Notice">Notice</option>
                    <option value="Upcoming Event">Upcoming Event</option>
                    <option value="Publication">Publication</option>
                    <option value="Statement">Statement</option>
                  </select>
                </div>

                {/* Conditional Event details */}
                {category === 'Upcoming Event' && (
                  <ScrollReveal className="space-y-4 p-4 bg-[#FAF7F0] border border-[#C9A227]/30">
                    <span className="font-mono text-[8px] uppercase tracking-widest text-gold-dark font-bold block">
                      Event logistics parameters
                    </span>
                    <div>
                      <label className="block font-mono text-[9px] text-ink-soft uppercase tracking-wider mb-1 font-semibold">
                        Event Date *
                      </label>
                      <input
                        type="date"
                        required
                        value={eventDate}
                        onChange={(e) => setEventDate(e.target.value)}
                        className="w-full bg-white border border-[#D8D0BC] px-3 py-1.5 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
                      />
                    </div>
                    <div>
                      <label className="block font-mono text-[9px] text-ink-soft uppercase tracking-wider mb-1 font-semibold">
                        Event Location / Venue *
                      </label>
                      <input
                        type="text"
                        required
                        value={eventLocation}
                        onChange={(e) => setEventLocation(e.target.value)}
                        placeholder="e.g. High Court Auditorium / Zoom Room"
                        className="w-full bg-white border border-[#D8D0BC] px-3 py-1.5 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
                      />
                    </div>
                  </ScrollReveal>
                )}

                <div>
                  <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1 font-semibold">
                    Directive Body text *
                  </label>
                  <textarea
                    required
                    rows={6}
                    value={body}
                    onChange={(e) => setBody(e.target.value)}
                    placeholder="Draft the authoritative decree text in clean, professional legalese..."
                    className="w-full bg-white border border-[#D8D0BC] px-3 py-2 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink leading-relaxed"
                  />
                </div>

                {errorMessage && (
                  <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs font-sans">
                    {errorMessage}
                  </div>
                )}

                <div className="flex gap-3">
                  {editId && (
                    <button
                      type="button"
                      onClick={handleCancelEdit}
                      className="flex-1 bg-white hover:bg-gray-50 border border-border-custom text-ink-soft py-2.5 font-mono text-xs uppercase tracking-wider transition-all flex items-center justify-center space-x-1 cursor-pointer"
                    >
                      <X size={12} />
                      <span>Cancel</span>
                    </button>
                  )}
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-2 bg-emerald-custom hover:bg-emerald-light border border-gold-custom text-paper py-2.5 font-mono text-xs uppercase tracking-widest font-bold transition-all flex items-center justify-center space-x-2 cursor-pointer shadow-2xs disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <>
                        <RefreshCw size={12} className="animate-spin text-gold-custom" />
                        <span>Propagating...</span>
                      </>
                    ) : (
                      <>
                        <Plus size={14} className="text-gold-custom" />
                        <span>{editId ? 'Commit Revision' : 'Publish Circular'}</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Right Bulletin Registry Panel */}
          <div className="lg:col-span-7 space-y-4">
            <div className="border-b border-border-custom pb-2 flex justify-between items-baseline">
              <h3 className="font-sans text-xs uppercase tracking-widest font-bold text-ink">
                Active Bulletin Records ({announcements.length})
              </h3>
              <span className="text-[9px] font-mono text-ink-faint uppercase">
                Sorted by recency
              </span>
            </div>

            <div className="space-y-4 max-h-[620px] overflow-y-auto pr-1">
              {announcements.length === 0 ? (
                <div className="text-center p-12 bg-paper border border-dashed border-border-custom text-ink-soft space-y-2">
                  <AlertCircle className="mx-auto text-gold-dark" size={24} />
                  <p className="font-serif text-sm font-semibold">No active circular records found</p>
                  <p className="text-xs font-sans">Draft a new decree to publish to the bar portal registries.</p>
                </div>
              ) : (
                announcements.map((ann, idx) => (
                  <ScrollReveal 
                    key={ann.id} 
                    delay={Math.min(idx * 40, 200)}
                    className="bg-paper border border-border-custom p-5 space-y-3 relative overflow-hidden shadow-3xs"
                  >
                    <div className="flex justify-between items-start gap-4">
                      <div>
                        <div className="flex flex-wrap items-center gap-2 mb-1.5">
                          {getCategoryPill(ann.category)}
                          <span className="font-mono text-[8px] uppercase tracking-wider text-gold-dark">
                            ID: PLA-{ann.id}
                          </span>
                        </div>
                        <h4 className="font-serif text-sm font-bold text-emerald-custom leading-tight">
                          {ann.title}
                        </h4>
                      </div>

                      <div className="flex gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleEditClick(ann)}
                          className="text-ink-faint hover:text-emerald-700 transition-colors p-1.5 border border-transparent hover:border-emerald-200 hover:bg-emerald-50 rounded-xs cursor-pointer"
                          title="Edit Decree"
                        >
                          <Edit2 size={12} />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteClick(ann.id, ann.title)}
                          className="text-ink-faint hover:text-red-600 transition-colors p-1.5 border border-transparent hover:border-red-200 hover:bg-red-50 rounded-xs cursor-pointer"
                          title="Revoke Decree"
                        >
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </div>

                    <p className="text-xs text-ink-soft leading-relaxed pr-4 font-sans whitespace-pre-line">
                      {ann.body}
                    </p>

                    {/* Show logistics for Upcoming Event */}
                    {ann.category === 'Upcoming Event' && ann.eventDate && (
                      <div className="mt-2.5 p-3 bg-purple-50/50 border border-purple-100 rounded-sm space-y-1 text-[11px] font-sans text-purple-950">
                        <div className="flex items-center gap-2">
                          <Calendar size={11} className="text-purple-700" />
                          <span className="font-medium">Scheduled Date: {ann.eventDate}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <MapPin size={11} className="text-purple-700" />
                          <span>Venue: {ann.eventLocation}</span>
                        </div>
                      </div>
                    )}

                    <div className="pt-2 border-t border-border-custom/40 flex flex-wrap justify-between gap-3 text-[9px] font-mono text-ink-faint uppercase">
                      <span className="flex items-center gap-1">
                        <Calendar size={10} />
                        Posted: {ann.date}
                      </span>
                      <span className="flex items-center gap-1">
                        <User size={10} />
                        By: {ann.postedBy}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin size={10} />
                        Scope: {ann.chapter}
                      </span>
                    </div>
                  </ScrollReveal>
                ))
              )}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
