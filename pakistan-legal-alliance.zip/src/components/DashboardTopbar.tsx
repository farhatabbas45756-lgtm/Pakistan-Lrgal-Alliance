import React, { useState, useEffect, useRef } from 'react';
import { ActivePage, UserState } from '../types';
import { Menu, Bell, MoreVertical, Settings, MessageSquare, HelpCircle, LogOut, ArrowLeft } from 'lucide-react';

interface DashboardTopbarProps {
  activePage: ActivePage;
  onNavigate: (page: ActivePage) => void;
  userState: UserState;
  onSignOut: () => void;
  onToggleSidebar: () => void;
}

export default function DashboardTopbar({
  activePage,
  onNavigate,
  userState,
  onSignOut,
  onToggleSidebar,
}: DashboardTopbarProps) {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getPageTitle = () => {
    switch (activePage) {
      case 'dashboard':
        return 'Member Dashboard';
      case 'announcements':
        return 'Official Announcements';
      default:
        return 'Advocate Workspace';
    }
  };

  const handleDropdownOption = (action: string) => {
    setDropdownOpen(false);
    if (action === 'settings') {
      alert('Settings interface is locked under secure bar-registry policy. Contact your registrar.');
    } else if (action === 'announcements') {
      onNavigate('announcements');
    } else if (action === 'help') {
      alert('PLA Member Helpdesk Chat is currently offline. Please call the Head Office at Lahore, Punjab.');
    } else if (action === 'signout') {
      onSignOut();
    }
  };

  return (
    <header className="w-full h-16 bg-[#FAF7F0] border-b border-[#D8D0BC] px-4 md:px-8 flex items-center justify-between relative z-20" id="pla-dashboard-topbar">
      
      {/* Left side: Hamburger (mobile) or back button + Title */}
      <div className="flex items-center space-x-4">
        <button
          onClick={onToggleSidebar}
          className="md:hidden p-1.5 text-[#1C1C1A] hover:text-[#C9A227] transition-colors cursor-pointer"
          aria-label="Toggle Navigation Drawer"
          id="pla-dashboard-sidebar-hamburger"
        >
          <Menu size={20} />
        </button>

        <button
          onClick={() => {
            onNavigate('home');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="hidden sm:flex items-center space-x-1.5 font-mono text-[10px] text-[#8A8578] hover:text-[#0F3D2E] hover:border-[#0F3D2E] uppercase tracking-widest cursor-pointer border border-[#D8D0BC] px-2.5 py-1 bg-[#FAF7F0] transition-colors"
        >
          <ArrowLeft size={10} />
          <span>Exit Portal</span>
        </button>

        <h1 className="font-serif text-base sm:text-lg font-bold text-[#1C1C1A] tracking-tight leading-none uppercase">
          {getPageTitle()}
        </h1>
      </div>

      {/* Right side: Notifications, Action Button, and dropdown */}
      <div className="flex items-center space-x-6">
        
        {/* Geometric square notification indicator */}
        <button
          onClick={() => {
            onNavigate('announcements');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="relative p-1 transition-transform hover:scale-105 cursor-pointer"
          aria-label="View Announcements Feed"
        >
          <div className="w-5 h-5 border border-[#1C1C1A] opacity-30 flex items-center justify-center">
            <span className="text-[9px] font-mono leading-none opacity-60">N</span>
          </div>
          <div className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#8B2E2E] border border-[#FAF7F0]" />
        </button>

        {/* Profile Settings shortcut outline button from Design HTML */}
        <button
          onClick={() => alert('Settings interface is locked under secure bar-registry policy. Contact your registrar.')}
          className="hidden md:inline-block px-4 py-1.5 border border-[#1C1C1A] text-[11px] font-mono uppercase tracking-widest hover:bg-[#1C1C1A] hover:text-[#FAF7F0] transition-colors cursor-pointer"
        >
          Profile Settings
        </button>

        {/* Accessible Three-dot Kebab Menu */}
        <div className="relative" ref={dropdownRef}>
          <button
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className="p-1.5 text-[#1C1C1A] hover:text-[#C9A227] transition-colors cursor-pointer rounded hover:bg-[#D8D0BC]/20"
            aria-label="Open Workspace Menu"
            aria-haspopup="true"
            aria-expanded={dropdownOpen}
            id="pla-kebab-menu-button"
          >
            <MoreVertical size={18} />
          </button>

          {dropdownOpen && (
            <div className="absolute right-0 mt-2 w-48 bg-[#FAF7F0] border border-[#D8D0BC] shadow-lg py-1 z-30" id="pla-kebab-dropdown">
              <button
                onClick={() => handleDropdownOption('settings')}
                className="w-full text-left px-4 py-2 font-mono text-xs text-[#1C1C1A] hover:bg-[#FAF7F0]/80 flex items-center space-x-2"
              >
                <Settings size={14} className="text-[#A9841A]" />
                <span>Profile Settings</span>
              </button>
              <button
                onClick={() => handleDropdownOption('announcements')}
                className="w-full text-left px-4 py-2 font-mono text-xs text-[#1C1C1A] hover:bg-[#FAF7F0]/80 flex items-center space-x-2"
              >
                <MessageSquare size={14} className="text-[#A9841A]" />
                <span>View Bulletins</span>
              </button>
              <button
                onClick={() => handleDropdownOption('help')}
                className="w-full text-left px-4 py-2 font-mono text-xs text-[#1C1C1A] hover:bg-[#FAF7F0]/80 flex items-center space-x-2"
              >
                <HelpCircle size={14} className="text-[#A9841A]" />
                <span>Help & Support</span>
              </button>
              <hr className="border-[#D8D0BC]/50 my-1" />
              <button
                onClick={() => handleDropdownOption('signout')}
                className="w-full text-left px-4 py-2 font-mono text-xs text-[#8B2E2E] hover:bg-red-50 flex items-center space-x-2"
              >
                <LogOut size={14} />
                <span>Sign Out</span>
              </button>
            </div>
          )}
        </div>

      </div>

    </header>
  );
}
