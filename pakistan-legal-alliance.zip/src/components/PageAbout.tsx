import React from 'react';
import ScrollReveal from './ScrollReveal';
import { VALUES_DATA } from '../data';
import { Award, ShieldAlert, Landmark, Scale, ChevronRight } from 'lucide-react';

export default function PageAbout() {
  const governingBoard = [
    { role: 'Founder and CEO', name: 'ADV Ehtasham Khan', phone: '0318-4804872' },
    { role: 'President', name: 'Nabeel Saad Khan', phone: '03419995007' },
    { role: 'Secretary-General', name: 'Barrister Aisha Malik Jahangir' },
    { role: 'Central Council Chairperson', name: 'Syed Mansoor Shah' },
    { role: 'Disciplinary Committee Registrar', name: 'Zia-ur-Rehman Sandhu' },
  ];

  return (
    <div className="w-full" id="pla-page-about">
      {/* 1. Hero Section on Dark Emerald */}
      <section className="w-full bg-gradient-to-b from-emerald-custom to-[#0a271e] text-paper relative py-16 md:py-20 border-b border-gold-custom/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 relative z-10 text-center md:text-left">
          <span className="font-mono text-xs text-gold-custom uppercase tracking-widest inline-block border-l-2 border-gold-custom pl-3 mb-4">
            Founding Manifesto & Structure
          </span>
          <h1 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white leading-tight">
            A society built by advocates, <br />
            <span className="text-gold-light">for advocates.</span>
          </h1>
          <p className="text-xs md:text-sm text-paper-dim/80 max-w-xl font-sans mt-4 leading-relaxed">
            The Pakistan Legal Alliance was established in April 2026 as an independent legal society to support legal practitioners, safeguard constitutional rights, and ensure democratic accountability.
          </p>
        </div>
      </section>

      {/* 2. Split Section: Mandate & Governing Structure */}
      <section className="w-full bg-paper py-16 md:py-24 border-b border-border-custom px-4 sm:px-6 md:px-8 relative z-20">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 md:gap-16 items-start">
            
            {/* Mandate Column */}
            <div className="flex flex-col space-y-6">
              <div>
                <span className="font-mono text-xs text-gold-dark uppercase tracking-widest block mb-2">
                  Chapter I: Mandate
                </span>
                <h2 className="font-serif text-2xl md:text-3xl font-bold text-emerald-custom tracking-tight">
                  Our Central Mandate & Pledge
                </h2>
                <div className="w-12 h-0.5 bg-gold-custom mt-3" />
              </div>
              
              <p className="text-xs sm:text-sm text-ink-soft font-sans leading-relaxed">
                As the nationwide guardian of procedural justice, the Pakistan Legal Alliance operates on the primary constitution of advancing legal scholarship, assuring standard ethics codes, and shielding judicial officers from partisan coercion. We hold that the independence of the bar is the final bulwark protecting civil liberties.
              </p>

              <div className="border-l-4 border-[#0F3D2E] bg-paper-dim/40 p-6">
                <span className="font-serif text-xs italic text-ink-soft block leading-relaxed">
                  "The independence of the advocate is not a privilege of the profession, but a fundamental protection of free society. To defend that independence is the first constitutional duty of this Alliance."
                </span>
                <span className="block font-mono text-[9px] uppercase tracking-wider text-ink-faint mt-3">
                  — PLA founding charter, preamble, April 2026
                </span>
              </div>

              <p className="text-xs text-ink-soft font-sans leading-relaxed">
                Our structure integrates regional councils in Islamabad, Lahore, Karachi, Peshawar, and Quetta. By pooling research, enforcing educational compliance, and delivering substantial pro-bono representations, we bridge the gap between abstract statutes and marginalized communities.
              </p>
            </div>

            {/* Governing Structure Column */}
            <ScrollReveal className="bg-[#FAF7F0] border border-border-custom p-8">
              <div className="flex items-center space-x-3 mb-6">
                <Landmark className="text-gold-dark shrink-0" size={20} />
                <h3 className="font-serif text-lg font-bold text-emerald-custom tracking-tight">
                  Governing Structure
                </h3>
              </div>
              <p className="text-xs text-ink-soft font-sans mb-6 leading-relaxed">
                The governing organs of the Alliance are democratically elected every two years by registered members, working across specialized standing boards:
              </p>

              <div className="space-y-4">
                {governingBoard.map((member, idx) => (
                  <div key={idx} className="border-b border-border-custom/50 pb-3 last:border-b-0 last:pb-0">
                    <span className="block font-mono text-[9px] text-gold-dark uppercase tracking-widest">
                      {member.role}
                    </span>
                    <span className="block font-serif text-sm font-bold text-ink mt-0.5 flex flex-wrap items-center gap-2">
                      <span>{member.name}</span>
                      {member.phone && (
                        <a 
                          href={`tel:${member.phone.replace(/-/g, '')}`}
                          className="font-mono text-[10px] text-emerald-custom bg-emerald-custom/5 hover:bg-emerald-custom/10 border border-emerald-custom/20 rounded-xs px-1.5 py-0.5 font-normal transition-colors"
                        >
                          {member.phone}
                        </a>
                      )}
                    </span>
                  </div>
                ))}
              </div>

              <div className="mt-8 pt-4 border-t border-border-custom/50 flex items-center justify-between">
                <span className="text-[10px] font-mono text-ink-faint uppercase tracking-wider">
                  Term: 2026 – 2028
                </span>
                <span className="text-[10px] font-mono text-gold-dark uppercase tracking-wider font-semibold">
                  PLA Secretariat
                </span>
              </div>
            </ScrollReveal>

          </div>
        </div>
      </section>

      {/* 3. Numbered Value Cards Section */}
      <section className="w-full bg-paper py-16 md:py-24 border-b border-border-custom px-4 sm:px-6 md:px-8 relative z-20">
        <div className="max-w-7xl mx-auto">
          <div className="mb-12 text-center md:text-left">
            <span className="font-mono text-xs text-gold-dark uppercase tracking-widest block mb-2">
              Chapter II: Values
            </span>
            <h2 className="font-serif text-2xl md:text-3xl font-bold text-emerald-custom tracking-tight">
              Constitutional Pillars of the Alliance
            </h2>
            <div className="w-16 h-1 bg-gold-custom mt-3 mx-auto md:mx-0" />
          </div>

          {/* Hairline-bordered grid with flat edges, no rounded corners or shadows */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-border-custom border border-border-custom">
            {VALUES_DATA.map((value, idx) => (
              <ScrollReveal 
                key={idx} 
                delay={idx * 100} 
                className="bg-paper p-6 min-h-[220px] flex flex-col justify-between"
              >
                <div>
                  <span className="block font-mono text-xs text-gold-dark font-medium border border-gold-custom/30 w-fit px-2 py-0.5 mb-6 bg-gold-light/5">
                    {value.num}
                  </span>
                  <h3 className="font-serif text-base font-bold text-ink mb-2">
                    {value.title}
                  </h3>
                  <p className="text-xs text-ink-soft leading-relaxed font-sans">
                    {value.desc}
                  </p>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
