import React, { useState, useRef } from 'react';
import Papa from 'papaparse';
import { UserState } from '../types';
import ScrollReveal from './ScrollReveal';
import { 
  ShieldAlert, 
  Award, 
  UserPlus, 
  CheckCircle, 
  Copy, 
  Link as LinkIcon, 
  RotateCcw,
  FileSpreadsheet,
  UploadCloud,
  AlertCircle,
  Download,
  Trash2,
  Database,
  ArrowRight,
  RefreshCw
} from 'lucide-react';

interface PageAdminMemberCreateProps {
  userState: UserState;
  onLogAction?: (actionType: any, details: string) => void;
}

export default function PageAdminMemberCreate({ userState, onLogAction }: PageAdminMemberCreateProps) {
  // Hardcoded Secretariat email allow-list for UX enforcement
  const ALLOWED_ADMINS = [
    'thread.fia@gmail.com',
    'n.saad.khan@barcounsel.pk',
    'r.rehmet@barcounsel.pk',
    'c.numan.ali@barcounsel.pk'
  ];

  const hasAccess = userState.isAuthenticated && (userState.isAdmin || ALLOWED_ADMINS.includes(userState.email.toLowerCase()));

  // Tab State
  const [activeTab, setActiveTab] = useState<'single' | 'bulk'>('single');

  // Single Form States
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [barNo, setBarNo] = useState('');
  const [chapter, setChapter] = useState('Punjab Bar Council');
  const [designation, setDesignation] = useState<'Senior Advocate' | 'Junior Advocate' | 'Counsel'>('Counsel');
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successData, setSuccessData] = useState<{
    uid: string;
    memberId: string;
    resetLink: string;
    message: string;
  } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  // Bulk Import States
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [previewRows, setPreviewRows] = useState<any[]>([]);
  const [bulkError, setBulkError] = useState<string | null>(null);
  const [bulkIsSubmitting, setBulkIsSubmitting] = useState(false);
  const [bulkResults, setBulkResults] = useState<{
    totalProcessed: number;
    successfulCount: number;
    failedCount: number;
    successful: any[];
    failed: any[];
  } | null>(null);
  const [bulkCopiedIndex, setBulkCopiedIndex] = useState<number | null>(null);

  const handleFileChange = (file: File) => {
    setBulkError(null);
    setBulkResults(null);
    setCsvFile(file);

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        if (results.errors && results.errors.length > 0) {
          console.warn('CSV parsing warnings:', results.errors);
        }

        const data = results.data as any[];
        if (!data || data.length === 0) {
          setBulkError('The uploaded CSV file contains no parsed rows.');
          setPreviewRows([]);
          return;
        }

        // Map column headers dynamically (supporting various spellings and casings)
        const parsed: any[] = data.map((row) => {
          const keys = Object.keys(row);
          const findVal = (possibleKeys: string[]) => {
            const matchedKey = keys.find(k => 
              possibleKeys.includes(k.toLowerCase().trim().replace(/[\s_-]+/g, ''))
            );
            return matchedKey ? String(row[matchedKey]).trim() : '';
          };

          return {
            displayName: findVal(['displayname', 'name', 'fullname', 'advocatename', 'advocate']),
            email: findVal(['email', 'emailaddress', 'emailid']),
            memberId: findVal(['memberid', 'id', 'registrationid', 'membernumber']),
            barCouncilNo: findVal(['barcouncilno', 'barno', 'barcouncilnumber', 'enrolmentno', 'enrolmentnumber', 'barcouncilno']),
            chapter: findVal(['chapter', 'barcouncilchapter', 'barcouncil', 'accreditedchapter']),
            designation: findVal(['designation', 'memberdesignation', 'rank', 'role', 'advocatedesignation']),
          };
        });

        // Filter out completely blank lines
        const validRows = parsed.filter(r => r.displayName || r.email || r.barCouncilNo);

        if (validRows.length === 0) {
          setBulkError('No valid member records found. Please ensure headers are correct (e.g., displayName, email, barCouncilNo, chapter).');
          setPreviewRows([]);
          return;
        }

        setPreviewRows(validRows);
      },
      error: (err) => {
        setBulkError(`Failed to parse CSV file: ${err.message}`);
        setPreviewRows([]);
      }
    });
  };

  const handleBulkSubmit = async () => {
    if (previewRows.length === 0) return;

    setBulkIsSubmitting(true);
    setBulkError(null);
    setBulkResults(null);

    try {
      const response = await fetch('/api/bulkCreateMembers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${userState.token || ''}`,
        },
        body: JSON.stringify({
          members: previewRows,
        }),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || 'The Central Registry rejected the bulk transmission.');
      }

      setBulkResults(result);

      // Cache successful ones in the client database cache
      if (result.successful && result.successful.length > 0) {
        const localData = localStorage.getItem('pla_members_database');
        if (localData) {
          try {
            const membersList = JSON.parse(localData);
            const newMembers = result.successful.map((item: any, idx: number) => ({
              id: item.memberId,
              serialNo: membersList.length + idx + 1,
              name: item.displayName,
              role: 'Accredited Advocate',
              email: item.email,
              barNo: previewRows[idx]?.barCouncilNo || 'PLA-BULK-N/A',
              chapter: previewRows[idx]?.chapter || 'Islamabad Capital Territory',
              status: 'Pending',
              dateJoined: new Date().toISOString().split('T')[0],
              designation: previewRows[idx]?.designation || 'Counsel',
            }));
            localStorage.setItem('pla_members_database', JSON.stringify([...membersList, ...newMembers]));
          } catch (e) {
            console.error('Error updating cached database:', e);
          }
        }

        // Action log
        if (onLogAction) {
          onLogAction(
            'MEMBER_ADD',
            `Bulk imported ${result.successfulCount} certified advocate dossiers (System bypass failed count: ${result.failedCount})`
          );
        }
      }

    } catch (err: any) {
      console.error('Error during bulk submit:', err);
      setBulkError(err.message || 'An unexpected error occurred during secure transit of member dossiers.');
    } finally {
      setBulkIsSubmitting(false);
    }
  };

  const downloadSampleCsv = () => {
    const sample = [
      { displayName: "Advocate Tariq Mahmood", email: "t.mahmood@barcounsel.pk", memberId: "PLA-582912", barCouncilNo: "IHC-9241-ADV", chapter: "Islamabad Capital Territory" },
      { displayName: "Maimoona Alvi", email: "m.alvi@barcounsel.pk", memberId: "", barCouncilNo: "LHC-10825-ADV", chapter: "Punjab Bar Council" }
    ];
    const csv = Papa.unparse(sample);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'pla_members_import_template.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const downloadFailedRowsCsv = () => {
    if (!bulkResults || bulkResults.failed.length === 0) return;

    const rows = bulkResults.failed.map((f: any) => ({
      displayName: f.row.displayName || '',
      email: f.row.email || '',
      memberId: f.row.memberId || '',
      barCouncilNo: f.row.barCouncilNo || '',
      chapter: f.row.chapter || '',
    }));

    const csvContent = Papa.unparse(rows);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'failed_members_import_corrections.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleResetBulk = () => {
    setCsvFile(null);
    setPreviewRows([]);
    setBulkError(null);
    setBulkResults(null);
    setBulkCopiedIndex(null);
  };

  if (!hasAccess) {
    return (
      <div className="w-full min-h-[calc(100vh-140px)] bg-paper flex items-center justify-center p-6" id="pla-unauthorized-console">
        <ScrollReveal className="max-w-md w-full bg-paper border border-rose-200 p-8 text-center space-y-5 shadow-xs">
          <ShieldAlert size={48} className="text-rose-700 mx-auto" />
          <h2 className="font-serif text-xl font-bold text-rose-900 tracking-tight uppercase">
            Unauthorized Secretariat Decree
          </h2>
          <p className="text-xs text-ink-soft leading-relaxed font-sans">
            Access to the Central Registrar Credentials Console is restricted to designated Secretariat officers. Your account <strong>{userState.email || 'Anonymous'}</strong> does not possess active credentials in our master clearance registry.
          </p>
          <div className="text-[10px] font-mono text-rose-800 bg-rose-50 border border-rose-100 p-2.5">
            LOGGED ATTEMPT REF: SEC-AUTH-{Date.now()}
          </div>
        </ScrollReveal>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !barNo) {
      setError('Please fill in all mandatory registry fields.');
      return;
    }

    setIsSubmitting(true);
    setError(null);
    setSuccessData(null);

    try {
      const response = await fetch('/api/createMember', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${userState.token || ''}`,
        },
        body: JSON.stringify({
          name: name.trim(),
          email: email.trim().toLowerCase(),
          barCouncilNo: barNo.trim(),
          chapter,
          designation,
        }),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || 'Failed to register the advocate credentials.');
      }

      setSuccessData(result);

      // Save to localStorage or mock database for immediate UI representation
      const localData = localStorage.getItem('pla_members_database');
      if (localData) {
        try {
          const membersList = JSON.parse(localData);
          const newMember = {
            id: result.memberId || `M-${Math.floor(1000 + Math.random() * 9000)}`,
            serialNo: membersList.length + 1,
            name: name.trim(),
            role: 'Accredited Advocate',
            email: email.trim().toLowerCase(),
            barNo: barNo.trim(),
            chapter,
            status: 'Pending',
            dateJoined: new Date().toISOString().split('T')[0],
            designation,
          };
          localStorage.setItem('pla_members_database', JSON.stringify([...membersList, newMember]));
        } catch (e) {
          console.error('Error updating client-side database cache:', e);
        }
      }

      // Log action to Secretariat logs
      if (onLogAction) {
        onLogAction(
          'MEMBER_ADD',
          `Provisioned pending account for advocate "${name.trim()}" (ID: ${result.memberId}) with reset authorization: ${result.resetLink}`
        );
      }

    } catch (err: any) {
      console.error('Error during secure member provisioning:', err);
      setError(err.message || 'An unexpected database error occurred during encryption keys initialization.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const copyResetLink = () => {
    if (successData?.resetLink) {
      navigator.clipboard.writeText(successData.resetLink);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleResetForm = () => {
    setName('');
    setEmail('');
    setBarNo('');
    setChapter('Punjab Bar Council');
    setDesignation('Counsel');
    setSuccessData(null);
    setError(null);
  };

  return (
    <div className="w-full" id="pla-page-admin-member">
      <section className="w-full bg-[#0F3D2E] text-paper relative py-12 border-b border-gold-custom/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 relative z-10">
          <span className="font-mono text-[9px] text-gold-custom uppercase tracking-widest inline-block border-l-2 border-gold-custom pl-3 mb-2 font-bold">
            Registrar Console
          </span>
          <h1 className="font-serif text-2xl md:text-3xl font-bold tracking-tight text-white uppercase">
            Provision Certified Advocate
          </h1>
          <p className="text-xs text-paper-dim/80 max-w-xl font-sans mt-2">
            Securely encrypt and generate state-validated credentials for verified Pakistan Legal Alliance bar applicants.
          </p>
        </div>
      </section>

      <section className="w-full bg-paper py-12 px-4 sm:px-6 md:px-8 relative z-20">
        <div className="max-w-2xl mx-auto">
          {/* Action Tabs */}
          <div className="flex border-b border-border-custom mb-8">
            <button
              onClick={() => setActiveTab('single')}
              className={`flex items-center gap-2 pb-3.5 px-4 font-mono text-xs uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
                activeTab === 'single'
                  ? 'border-emerald-custom text-emerald-custom font-bold'
                  : 'border-transparent text-ink-soft hover:text-ink'
              }`}
            >
              <UserPlus size={14} />
              <span>Single Enrollment</span>
            </button>
            <button
              onClick={() => setActiveTab('bulk')}
              className={`flex items-center gap-2 pb-3.5 px-4 font-mono text-xs uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
                activeTab === 'bulk'
                  ? 'border-emerald-custom text-emerald-custom font-bold'
                  : 'border-transparent text-ink-soft hover:text-ink'
              }`}
            >
              <FileSpreadsheet size={14} />
              <span>Bulk CSV Import</span>
            </button>
          </div>

          {activeTab === 'single' ? (
            successData ? (
              <ScrollReveal className="bg-[#FAF7F0] border border-gold-custom p-8 space-y-6 shadow-sm">
                <div className="text-center space-y-2">
                  <CheckCircle size={44} className="text-emerald-custom mx-auto" />
                  <h2 className="font-serif text-lg font-bold text-emerald-custom uppercase">
                    Dossier Registered & Signed
                  </h2>
                  <p className="text-xs text-ink-soft font-sans">
                    The credentials database has been updated. Advocate registered under status <strong>Pending</strong>.
                  </p>
                </div>

                <div className="border-t border-b border-[#D8D0BC] py-4 space-y-2.5 font-sans text-xs text-ink-soft">
                  <div className="flex justify-between border-b border-[#D8D0BC]/40 pb-2">
                    <span className="font-mono text-[10px] uppercase font-bold">Certified Advocate:</span>
                    <span className="font-serif font-bold text-[#1C1C1A]">{name}</span>
                  </div>
                  <div className="flex justify-between border-b border-[#D8D0BC]/40 pb-2">
                    <span className="font-mono text-[10px] uppercase font-bold">Email Address:</span>
                    <span className="text-[#1C1C1A]">{email}</span>
                  </div>
                  <div className="flex justify-between border-b border-[#D8D0BC]/40 pb-2">
                    <span className="font-mono text-[10px] uppercase font-bold">Registration ID:</span>
                    <span className="font-mono font-bold text-[#1C5A43]">{successData.memberId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-mono text-[10px] uppercase font-bold">Firestore UID:</span>
                    <span className="font-mono text-[11px] text-ink-faint truncate max-w-[200px]">{successData.uid}</span>
                  </div>
                </div>

                <div className="bg-white border border-[#D8D0BC] p-4.5 space-y-3.5 rounded-sm">
                  <div>
                    <span className="font-mono text-[10px] uppercase font-bold text-gold-dark flex items-center gap-1.5">
                      <LinkIcon size={12} />
                      Branded Activation & Reset Link
                    </span>
                    <p className="text-[11px] text-ink-soft leading-normal mt-1">
                      Provide the following secure, expiring token link to the candidate so they can set their password and activate their bar portal:
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      readOnly
                      value={successData.resetLink}
                      className="flex-1 bg-[#FAF7F0] border border-[#D8D0BC] px-3 py-2 font-mono text-[10px] text-emerald-custom select-all focus:outline-none"
                    />
                    <button
                      onClick={copyResetLink}
                      className="bg-emerald-custom text-paper hover:bg-emerald-light border border-gold-custom p-2.5 cursor-pointer transition-all flex items-center justify-center rounded-sm"
                      title="Copy Link"
                    >
                      <Copy size={14} />
                    </button>
                  </div>

                  {copied && (
                    <span className="block text-[10px] font-mono text-[#1C5A43] font-semibold text-right">
                      ✓ Reset Link Copied to Clipboard
                    </span>
                  )}
                  
                  <p className="text-[10px] text-ink-faint font-sans leading-normal bg-amber-50 p-2.5 border border-[#D8D0BC]/60 italic">
                    * Note: For prototype testing, you can click or copy-paste this reset link directly in a new tab to see the "Establish Secure Password" workflow immediately.
                  </p>
                </div>

                <button
                  onClick={handleResetForm}
                  className="w-full bg-emerald-custom text-paper hover:bg-emerald-light py-2.5 font-mono text-xs uppercase tracking-wider font-bold border border-gold-custom cursor-pointer flex items-center justify-center space-x-2"
                >
                  <RotateCcw size={12} />
                  <span>Provision Another Member</span>
                </button>
              </ScrollReveal>
            ) : (
              <div className="bg-paper border border-border-custom p-8 shadow-3xs">
                <span className="font-mono text-xs text-gold-dark uppercase tracking-widest block mb-1">
                  Central Registry Protocol
                </span>
                <h2 className="font-serif text-xl font-bold text-emerald-custom mb-6 uppercase tracking-tight flex items-center gap-2">
                  <UserPlus size={20} className="text-[#C9A227]" />
                  Certified Enrollment Dossier
                </h2>

                <form onSubmit={handleSubmit} className="space-y-5">
                  <div>
                    <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1.5 font-semibold">
                      Advocate Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-paper border border-border-custom px-3 py-2 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
                      placeholder="e.g. Advocate Muhammad Raza"
                    />
                  </div>

                  <div>
                    <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1.5 font-semibold">
                      Certified Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-paper border border-border-custom px-3 py-2 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
                      placeholder="e.g. m.raza@barcounsel.pk"
                    />
                  </div>

                  <div>
                    <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1.5 font-semibold">
                      Bar Council Enrolment Number *
                    </label>
                    <input
                      type="text"
                      required
                      value={barNo}
                      onChange={(e) => setBarNo(e.target.value)}
                      className="w-full bg-paper border border-border-custom px-3 py-2 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
                      placeholder="e.g. LHC-10251-ADV"
                    />
                  </div>

                  <div>
                    <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1.5 font-semibold">
                      Accredited Chapter Selection *
                    </label>
                    <select
                      value={chapter}
                      onChange={(e) => setChapter(e.target.value)}
                      className="w-full bg-paper border border-border-custom px-3 py-2 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
                    >
                      <option value="Islamabad Capital Territory">Islamabad Capital Territory</option>
                      <option value="Punjab Bar Council">Punjab Bar Council (Lahore)</option>
                      <option value="Sindh Bar Council">Sindh Bar Council (Karachi)</option>
                      <option value="KPK Bar Council">KPK Bar Council (Peshawar)</option>
                      <option value="Balochistan Bar Council">Balochistan Bar Council (Quetta)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1.5 font-semibold">
                      Candidate Bar Designation *
                    </label>
                    <select
                      value={designation}
                      onChange={(e) => setDesignation(e.target.value as any)}
                      className="w-full bg-paper border border-border-custom px-3 py-2 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
                    >
                      <option value="Senior Advocate">Senior Advocate</option>
                      <option value="Junior Advocate">Junior Advocate</option>
                      <option value="Counsel">Counsel</option>
                    </select>
                  </div>

                  {error && (
                    <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs font-sans rounded-xs">
                      {error}
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-emerald-custom text-paper hover:bg-emerald-light disabled:opacity-50 py-3 font-mono text-xs uppercase tracking-widest font-bold transition-all cursor-pointer border border-gold-custom flex items-center justify-center space-x-2"
                  >
                    <span>{isSubmitting ? 'Signing Enrollment decree...' : 'Provision Secure Candidate'}</span>
                  </button>
                </form>
              </div>
            )
          ) : (
            <div className="space-y-6">
              {bulkResults ? (
                /* Results Summary View */
                <ScrollReveal className="bg-[#FAF7F0] border border-gold-custom p-8 space-y-6 shadow-sm animate-fade-in">
                  <div className="text-center space-y-2">
                    <CheckCircle size={44} className="text-emerald-custom mx-auto" />
                    <h2 className="font-serif text-lg font-bold text-emerald-custom uppercase">
                      Bulk Import Cycle Finished
                    </h2>
                    <p className="text-xs text-ink-soft font-sans">
                      The central credentials registry processing run has completed successfully.
                    </p>
                  </div>

                  {/* Summary Stats Cards */}
                  <div className="grid grid-cols-3 gap-4 text-center font-sans">
                    <div className="bg-white border border-[#D8D0BC] p-3 rounded-sm">
                      <span className="block text-[10px] font-mono uppercase font-bold text-ink-soft">Total Loaded</span>
                      <span className="text-xl font-bold text-ink">{bulkResults.totalProcessed}</span>
                    </div>
                    <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-sm">
                      <span className="block text-[10px] font-mono uppercase font-bold text-emerald-800">Succeeded</span>
                      <span className="text-xl font-bold text-[#1C5A43]">{bulkResults.successfulCount}</span>
                    </div>
                    <div className="bg-rose-50 border border-rose-200 p-3 rounded-sm">
                      <span className="block text-[10px] font-mono uppercase font-bold text-rose-800">Failed</span>
                      <span className="text-xl font-bold text-rose-700">{bulkResults.failedCount}</span>
                    </div>
                  </div>

                  {/* Succeeded List */}
                  {bulkResults.successful.length > 0 && (
                    <div className="space-y-2.5">
                      <h3 className="font-mono text-[10px] uppercase font-bold text-emerald-800 flex items-center gap-1.5">
                        <CheckCircle size={12} />
                        Successfully Provisioned Members ({bulkResults.successfulCount})
                      </h3>
                      <div className="bg-white border border-[#D8D0BC] max-h-56 overflow-y-auto divide-y divide-[#D8D0BC]/40 text-xs font-sans rounded-sm">
                        {bulkResults.successful.map((item, idx) => (
                          <div key={item.uid || idx} className="p-3 flex justify-between items-center gap-4 hover:bg-[#FAF7F0]/30 transition-all">
                            <div className="min-w-0 flex-1">
                              <p className="font-serif font-bold text-ink">{item.displayName}</p>
                              <p className="text-[10px] text-ink-soft font-mono truncate">{item.email} • ID: {item.memberId}</p>
                            </div>
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => {
                                  navigator.clipboard.writeText(item.resetLink);
                                  setBulkCopiedIndex(idx);
                                  setTimeout(() => setBulkCopiedIndex(null), 2000);
                                }}
                                className="bg-[#FAF7F0] border border-[#D8D0BC] hover:bg-white text-ink px-2.5 py-1 text-[10px] font-mono uppercase tracking-wider cursor-pointer flex items-center gap-1 rounded-xs transition-all"
                                title="Copy Reset Link"
                              >
                                {bulkCopiedIndex === idx ? (
                                  <span className="text-[#1C5A43] font-bold">✓ Copied</span>
                                ) : (
                                  <>
                                    <Copy size={10} />
                                    <span>Reset Link</span>
                                  </>
                                )}
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Failed List with Correction CSV */}
                  {bulkResults.failed.length > 0 && (
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <h3 className="font-mono text-[10px] uppercase font-bold text-rose-800 flex items-center gap-1.5">
                          <AlertCircle size={12} />
                          Failed Records ({bulkResults.failedCount})
                        </h3>
                        <button
                          onClick={downloadFailedRowsCsv}
                          className="bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-800 px-2.5 py-1 text-[10px] font-mono uppercase tracking-wider cursor-pointer flex items-center gap-1.5 rounded-xs transition-all"
                        >
                          <Download size={11} />
                          <span>Export Failed Rows CSV</span>
                        </button>
                      </div>
                      
                      <div className="bg-white border border-[#D8D0BC] max-h-48 overflow-y-auto divide-y divide-[#D8D0BC]/40 text-xs font-sans rounded-sm">
                        {bulkResults.failed.map((item, idx) => (
                          <div key={idx} className="p-3 bg-rose-50/20">
                            <div className="flex justify-between items-start gap-4">
                              <div className="min-w-0">
                                <span className="font-serif font-bold text-rose-900 block">{item.row.displayName || 'Unnamed Row'}</span>
                                <span className="text-[10px] text-ink-soft block font-mono">{item.row.email || 'No email'}</span>
                              </div>
                              <span className="text-[10px] font-mono text-rose-700 bg-rose-50 px-2 py-1 border border-rose-100 uppercase rounded-xs">
                                Row {idx + 1} Error
                              </span>
                            </div>
                            <p className="text-[11px] font-mono text-rose-800 mt-2 bg-white/75 p-2 border-l-2 border-rose-400">
                              {item.error}
                            </p>
                          </div>
                        ))}
                      </div>
                      
                      <p className="text-[10px] text-ink-soft leading-normal bg-amber-50 p-3 border border-[#D8D0BC]/60 italic font-sans rounded-sm">
                        * Note: Correct the errors in the downloaded failed rows CSV file and re-upload it directly to complete onboarding for those members.
                      </p>
                    </div>
                  )}

                  <button
                    onClick={handleResetBulk}
                    className="w-full bg-emerald-custom text-paper hover:bg-emerald-light py-2.5 font-mono text-xs uppercase tracking-wider font-bold border border-gold-custom cursor-pointer flex items-center justify-center space-x-2 transition-all"
                  >
                    <RotateCcw size={12} />
                    <span>Upload Another CSV Roster</span>
                  </button>
                </ScrollReveal>
              ) : csvFile ? (
                /* CSV Preview & Confirm View */
                <div className="bg-paper border border-border-custom p-8 space-y-6 shadow-3xs animate-fade-in">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="font-mono text-[10px] text-gold-dark uppercase tracking-widest block mb-0.5">
                        Central Registry Loader
                      </span>
                      <h2 className="font-serif text-lg font-bold text-emerald-custom uppercase tracking-tight">
                        Roster Preview & Verification
                      </h2>
                    </div>
                    <button
                      onClick={handleResetBulk}
                      className="text-ink-soft hover:text-rose-700 p-1 cursor-pointer transition-all"
                      title="Clear File"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>

                  {/* File Metadata */}
                  <div className="bg-[#FAF7F0] border border-[#D8D0BC] p-3 flex justify-between items-center text-xs font-sans rounded-sm">
                    <div className="flex items-center gap-2.5">
                      <FileSpreadsheet size={16} className="text-emerald-custom" />
                      <div>
                        <span className="font-bold text-ink">{csvFile.name}</span>
                        <span className="block text-[10px] text-ink-soft font-mono">{(csvFile.size / 1024).toFixed(1)} KB</span>
                      </div>
                    </div>
                    <span className="bg-emerald-100 text-[#1C5A43] font-mono text-[10px] font-bold px-2 py-1 border border-emerald-200 rounded-xs uppercase">
                      {previewRows.length} Row{previewRows.length !== 1 ? 's' : ''} Mapped
                    </span>
                  </div>

                  {bulkError && (
                    <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs font-sans rounded-xs flex items-start gap-2">
                      <AlertCircle size={16} className="shrink-0 mt-0.5" />
                      <span>{bulkError}</span>
                    </div>
                  )}

                  {/* Preview Rows Table */}
                  <div className="space-y-2">
                    <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider font-semibold">
                      Dossier Records Draft
                    </label>
                    <div className="border border-border-custom rounded-sm overflow-x-auto max-h-64 scrollbar-custom">
                      <table className="w-full text-left border-collapse text-xs font-sans min-w-[500px]">
                        <thead>
                          <tr className="bg-[#FAF7F0] border-b border-border-custom font-mono text-[9px] uppercase tracking-wider text-ink-soft">
                            <th className="p-3">Display Name</th>
                            <th className="p-3">Certified Email</th>
                            <th className="p-3">Member ID</th>
                            <th className="p-3">Bar Council No</th>
                            <th className="p-3">Accredited Chapter</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-border-custom text-ink">
                          {previewRows.slice(0, 10).map((row, idx) => (
                            <tr key={idx} className="hover:bg-[#FAF7F0]/30 transition-all">
                              <td className="p-3 font-medium font-serif">{row.displayName || <span className="text-rose-700 italic font-sans font-normal">Missing</span>}</td>
                              <td className="p-3 font-mono text-[11px]">{row.email || <span className="text-rose-700 italic font-sans font-normal">Missing</span>}</td>
                              <td className="p-3 font-mono text-ink-soft">{row.memberId || <span className="text-ink-faint italic font-sans">Auto-Generated</span>}</td>
                              <td className="p-3 font-mono font-medium text-[#1C5A43]">{row.barCouncilNo || <span className="text-rose-700 italic font-sans font-normal">Missing</span>}</td>
                              <td className="p-3 text-ink-soft text-[11px]">{row.chapter || <span className="text-rose-700 italic font-sans font-normal">Missing</span>}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    {previewRows.length > 10 && (
                      <p className="text-[10px] font-mono text-ink-faint text-right italic">
                        Showing first 10 rows of {previewRows.length} total rows...
                      </p>
                    )}
                  </div>

                  {/* Notice & Instructions */}
                  <div className="bg-amber-50 border border-amber-200/60 p-4 space-y-2 rounded-sm font-sans text-xs text-amber-900 leading-relaxed">
                    <span className="font-mono text-[10px] uppercase font-bold text-[#C9A227] flex items-center gap-1.5">
                      <ShieldAlert size={12} />
                      Secretariat Secure Enrollment Mandate
                    </span>
                    <p className="text-[11px]">
                      By clicking confirm below, you will generate cryptographic passwords, seed Firebase Auth records, and provision active-pending Firestore records for these <strong>{previewRows.length}</strong> candidates. High-volume email resets will be throttled safely to guarantee domain reputability.
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-3 pt-2">
                    <button
                      onClick={handleResetBulk}
                      disabled={bulkIsSubmitting}
                      className="flex-1 bg-paper hover:bg-[#FAF7F0] disabled:opacity-50 text-ink-soft py-3 font-mono text-xs uppercase tracking-wider font-bold border border-border-custom transition-all cursor-pointer rounded-sm flex items-center justify-center space-x-2"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleBulkSubmit}
                      disabled={bulkIsSubmitting}
                      className="flex-[2] bg-emerald-custom text-paper hover:bg-emerald-light disabled:opacity-50 py-3 font-mono text-xs uppercase tracking-widest font-bold transition-all cursor-pointer border border-gold-custom flex items-center justify-center space-x-2 rounded-sm"
                    >
                      {bulkIsSubmitting ? (
                        <>
                          <RefreshCw size={13} className="animate-spin" />
                          <span>Provisioning {previewRows.length} Dossiers...</span>
                        </>
                      ) : (
                        <>
                          <CheckCircle size={13} />
                          <span>Confirm & Sign Bulk Decree</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              ) : (
                /* Drag and Drop Zone */
                <div className="space-y-6">
                  <div
                    onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                    onDragLeave={() => setIsDragging(false)}
                    onDrop={(e) => { e.preventDefault(); setIsDragging(false); const file = e.dataTransfer.files[0]; if (file) handleFileChange(file); }}
                    className={`border-2 border-dashed rounded-sm p-12 text-center cursor-pointer transition-all ${
                      isDragging 
                        ? 'border-emerald-custom bg-emerald-custom/5' 
                        : 'border-[#D8D0BC] hover:border-emerald-custom/40 bg-[#FAF7F0]/20'
                    }`}
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={(e) => { const file = e.target.files?.[0]; if (file) handleFileChange(file); }}
                      accept=".csv"
                      className="hidden"
                    />
                    <UploadCloud size={44} className="mx-auto text-emerald-custom/80 mb-3" />
                    <span className="font-serif text-base font-bold text-emerald-custom block uppercase tracking-tight">
                      Upload Roster Spreadsheet
                    </span>
                    <p className="text-xs text-ink-soft mt-2 max-w-sm mx-auto leading-relaxed font-sans">
                      Drag and drop your certified <strong>.csv</strong> member database here, or <span className="text-emerald-custom font-semibold underline">browse local directory files</span>.
                    </p>
                    <div className="mt-5 flex justify-center gap-2">
                      <span className="inline-block text-[9px] font-mono uppercase bg-white border border-[#D8D0BC] text-gold-dark px-2.5 py-1 rounded-xs tracking-wider">
                        UTF-8 CSV
                      </span>
                      <span className="inline-block text-[9px] font-mono uppercase bg-white border border-[#D8D0BC] text-gold-dark px-2.5 py-1 rounded-xs tracking-wider">
                        Max 500 rows
                      </span>
                    </div>
                  </div>

                  {bulkError && (
                    <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs font-sans rounded-xs flex items-start gap-2">
                      <AlertCircle size={16} className="shrink-0 mt-0.5" />
                      <span>{bulkError}</span>
                    </div>
                  )}

                  {/* Format details & Templates */}
                  <div className="bg-white border border-border-custom p-6 space-y-4 rounded-sm font-sans">
                    <h3 className="font-serif text-sm font-bold text-ink uppercase tracking-tight flex items-center gap-2">
                      <FileSpreadsheet size={16} className="text-gold-custom" />
                      Expected CSV File Structure
                    </h3>
                    <p className="text-xs text-ink-soft leading-normal">
                      The secure loader parses the column headers dynamically. To avoid issues, we recommend structuring your spreadsheet with these exact headings:
                    </p>
                    <div className="grid grid-cols-2 gap-4 text-xs">
                      <div className="space-y-1 bg-[#FAF7F0]/50 p-2.5 border border-[#D8D0BC]/40">
                        <span className="font-mono text-[10px] font-bold text-emerald-custom uppercase block">displayName *</span>
                        <span className="text-[10px] text-ink-soft leading-tight block">Advocate's full name for public and certificate display.</span>
                      </div>
                      <div className="space-y-1 bg-[#FAF7F0]/50 p-2.5 border border-[#D8D0BC]/40">
                        <span className="font-mono text-[10px] font-bold text-emerald-custom uppercase block">email *</span>
                        <span className="text-[10px] text-ink-soft leading-tight block">Unique address where the set-password link is dispatched.</span>
                      </div>
                      <div className="space-y-1 bg-[#FAF7F0]/50 p-2.5 border border-[#D8D0BC]/40">
                        <span className="font-mono text-[10px] font-bold text-[#C9A227] uppercase block">memberId (Optional)</span>
                        <span className="text-[10px] text-ink-soft leading-tight block">Unique PLA reference ID. Left blank, the system will auto-assign one.</span>
                      </div>
                      <div className="space-y-1 bg-[#FAF7F0]/50 p-2.5 border border-[#D8D0BC]/40">
                        <span className="font-mono text-[10px] font-bold text-emerald-custom uppercase block">barCouncilNo *</span>
                        <span className="text-[10px] text-ink-soft leading-tight block">Certified enrollment reference (e.g. IHC-10251-ADV).</span>
                      </div>
                      <div className="col-span-2 space-y-1 bg-[#FAF7F0]/50 p-2.5 border border-[#D8D0BC]/40">
                        <span className="font-mono text-[10px] font-bold text-emerald-custom uppercase block">chapter *</span>
                        <span className="text-[10px] text-ink-soft leading-tight block">Accredited local bar: <em>Islamabad Capital Territory</em>, <em>Punjab Bar Council</em>, <em>Sindh Bar Council</em>, <em>KPK Bar Council</em>, or <em>Balochistan Bar Council</em>.</span>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-[#D8D0BC]/30 flex justify-end">
                      <button
                        onClick={downloadSampleCsv}
                        className="bg-[#FAF7F0] hover:bg-[#FAF7F0]/80 border border-[#D8D0BC] text-gold-dark px-4 py-2 text-xs font-mono uppercase tracking-wider cursor-pointer flex items-center gap-2 rounded-sm transition-all"
                      >
                        <Download size={12} />
                        <span>Download Sample CSV Template</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
