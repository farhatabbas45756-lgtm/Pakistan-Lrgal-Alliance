import React, { useState, useRef } from 'react';
import { ActivePage, UserState, AnnouncementItem } from '../types';
import ScrollReveal from './ScrollReveal';
import { 
  BellRing, 
  Calendar, 
  User, 
  MapPin, 
  FileText, 
  Award, 
  Vote, 
  Scale, 
  MessageSquare,
  Clock,
  Sparkles,
  Search,
  Filter
} from 'lucide-react';

interface PageAnnouncementsProps {
  onNavigate: (page: ActivePage) => void;
  userState: UserState;
  announcements: AnnouncementItem[];
}

type FilterCategory = 'All' | 'Upcoming Event' | 'Notice' | 'Publication' | 'Statement';

export default function PageAnnouncements({ onNavigate, userState, announcements }: PageAnnouncementsProps) {
  // Swipe gesture detection to navigate between Announcements and Dashboard
  const touchStartX = useRef<number | null>(null);
  const touchEndX = useRef<number | null>(null);

  const [activeCategoryTab, setActiveCategoryTab] = useState<FilterCategory>('All');
  const [searchQuery, setSearchQuery] = useState('');

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.targetTouches[0].clientX;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndX.current = e.targetTouches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (!touchStartX.current || !touchEndX.current) return;
    
    const distance = touchStartX.current - touchEndX.current;
    const minSwipeDistance = 75; // minimum 75px swipe

    // Swipe Right (drag finger left to right) -> Navigate back to Dashboard
    if (distance < -minSwipeDistance) {
      onNavigate('dashboard');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const getIcon = (ann: AnnouncementItem) => {
    const cat = ann.category || 'Notice';
    switch (cat) {
      case 'Upcoming Event':
        return <Calendar className="text-purple-700 shrink-0" size={20} />;
      case 'Publication':
        return <Award className="text-gold-dark shrink-0" size={20} />;
      case 'Statement':
        return <Scale className="text-blue-800 shrink-0" size={20} />;
      case 'Notice':
      default:
        return <FileText className="text-emerald-custom shrink-0" size={20} />;
    }
  };

  const getCategoryPill = (cat?: string) => {
    switch (cat) {
      case 'Upcoming Event':
        return (
          <span className="inline-block px-2.5 py-0.5 border text-[9px] uppercase font-mono tracking-wider bg-purple-50 text-purple-800 border-purple-200">
            Upcoming Event
          </span>
        );
      case 'Publication':
        return (
          <span className="inline-block px-2.5 py-0.5 border text-[9px] uppercase font-mono tracking-wider bg-amber-50 text-amber-800 border-[#D8D0BC]">
            Publication
          </span>
        );
      case 'Statement':
        return (
          <span className="inline-block px-2.5 py-0.5 border text-[9px] uppercase font-mono tracking-wider bg-blue-50 text-blue-800 border-blue-200">
            Statement
          </span>
        );
      case 'Notice':
      default:
        return (
          <span className="inline-block px-2.5 py-0.5 border text-[9px] uppercase font-mono tracking-wider bg-emerald-50 text-emerald-800 border-emerald-200">
            Notice
          </span>
        );
    }
  };

  // 1. Separate "Upcoming Event" category for the dedicated high-contrast top panel
  const allUpcomingEvents = announcements.filter(
    (ann) => ann.category === 'Upcoming Event'
  );

  // Filter & Search application
  const filteredAnnouncements = announcements.filter((ann) => {
    const matchesTab = activeCategoryTab === 'All' || (ann.category || 'Notice') === activeCategoryTab;
    const matchesSearch = searchQuery === '' || 
      ann.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      ann.body.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ann.chapter.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTab && matchesSearch;
  });

  return (
    <div 
      className="w-full flex-grow p-4 md:p-8" 
      id="pla-page-announcements"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Mobile visible fallback navigation tabs */}
      <div className="md:hidden mb-6 border-b border-border-custom pb-2 flex justify-center space-x-2">
        <button
          onClick={() => {
            onNavigate('dashboard');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="flex-1 text-center py-2 font-mono text-[10px] uppercase tracking-wider bg-paper border border-border-custom text-ink-soft hover:text-emerald-custom"
        >
          Workspace Dashboard
        </button>
        <button
          onClick={() => onNavigate('announcements')}
          className="flex-1 text-center py-2 font-mono text-[10px] uppercase tracking-wider bg-emerald-custom text-white font-bold"
        >
          Announcements ({announcements.length})
        </button>
      </div>

      <div className="max-w-4xl mx-auto space-y-8">
        
        {/* Bulletins Page Header */}
        <div className="border-b border-border-custom pb-4 flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4">
          <div>
            <span className="font-mono text-[10px] text-gold-dark uppercase tracking-widest block font-bold">
              PLA Official Registry
            </span>
            <h2 className="font-serif text-xl font-bold text-emerald-custom uppercase mt-1">
              Official Bulletins & Circulars
            </h2>
            <p className="text-xs text-ink-soft font-sans mt-0.5">
              Mandatory compliance advisories, scheduled sessions, and general council decrees.
            </p>
          </div>

          <div className="relative w-full sm:w-64 shrink-0">
            <span className="absolute left-2.5 top-2 text-ink-faint">
              <Search size={14} />
            </span>
            <input
              type="text"
              placeholder="Search circular registry..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-[#D8D0BC] pl-8 pr-3 py-1.5 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
            />
          </div>
        </div>

        {/* 2. DEDICATED "UPCOMING SESSIONS & FUTURE EVENTS" PANEL */}
        {allUpcomingEvents.length > 0 && searchQuery === '' && (
          <ScrollReveal className="bg-purple-50/40 border border-purple-200 p-6 md:p-8 space-y-5 shadow-3xs relative overflow-hidden">
            {/* Elegant watermark */}
            <div className="absolute right-4 -bottom-6 opacity-5 rotate-12 pointer-events-none select-none">
              <Calendar size={120} className="text-purple-950" />
            </div>

            <div className="flex items-center space-x-2 border-b border-purple-200/50 pb-3">
              <Sparkles size={16} className="text-purple-700 animate-pulse" />
              <h3 className="font-serif text-sm font-bold text-purple-950 uppercase tracking-wide">
                Upcoming Scheduled Sessions & Events
              </h3>
              <span className="bg-purple-700 text-white font-mono text-[8px] font-bold px-1.5 py-0.5 rounded-sm uppercase tracking-widest ml-auto">
                {allUpcomingEvents.length} Active
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {allUpcomingEvents.map((evt) => (
                <div 
                  key={evt.id}
                  className="bg-white border border-purple-100 p-4 space-y-3 shadow-3xs hover:border-purple-300 transition-colors"
                >
                  <div className="flex justify-between items-start gap-2">
                    <h4 className="font-serif text-xs sm:text-sm font-bold text-purple-950 line-clamp-1">
                      {evt.title}
                    </h4>
                    <span className="font-mono text-[8px] text-purple-600 bg-purple-50 border border-purple-100 px-1 py-0.5 shrink-0 uppercase">
                      ID: PLA-{evt.id}
                    </span>
                  </div>

                  <p className="text-[11px] sm:text-xs text-purple-900 font-sans leading-relaxed line-clamp-3">
                    {evt.body}
                  </p>

                  <div className="pt-2 border-t border-purple-50 space-y-1.5 font-sans text-[11px] text-purple-950">
                    <div className="flex items-center gap-2">
                      <Calendar size={12} className="text-purple-700 shrink-0" />
                      <span className="font-semibold">Date: {evt.eventDate || evt.date}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin size={12} className="text-purple-700 shrink-0" />
                      <span className="truncate">Venue: {evt.eventLocation || 'Central Secretariat'}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollReveal>
        )}

        {/* 3. TABS FILTER ROW */}
        <div className="flex flex-wrap items-center gap-1.5 border-b border-border-custom/50 pb-3">
          <span className="font-mono text-[9px] text-ink-faint uppercase tracking-wider mr-2 flex items-center gap-1 font-bold">
            <Filter size={11} /> Filter:
          </span>
          {([
            { label: 'All Bulletins', value: 'All' },
            { label: 'Upcoming Events', value: 'Upcoming Event' },
            { label: 'Notices', value: 'Notice' },
            { label: 'Publications', value: 'Publication' },
            { label: 'Statements', value: 'Statement' }
          ] as const).map((tab) => {
            const isActive = activeCategoryTab === tab.value;
            return (
              <button
                key={tab.value}
                onClick={() => {
                  setActiveCategoryTab(tab.value);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className={`px-3 py-1 text-[10px] font-mono uppercase tracking-wider border rounded-xs transition-all cursor-pointer ${
                  isActive
                    ? 'bg-emerald-custom text-white border-emerald-custom font-bold shadow-3xs'
                    : 'bg-white text-ink-soft border-[#D8D0BC] hover:border-emerald-custom'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* 4. VERTICAL FEED OF FILTERED CIRCULARS */}
        <div className="space-y-8">
          {filteredAnnouncements.length === 0 ? (
            <div className="text-center p-12 bg-white border border-dashed border-border-custom text-ink-soft space-y-2">
              <Clock className="mx-auto text-gold-dark" size={24} />
              <p className="font-serif text-sm font-semibold">No registry entries found</p>
              <p className="text-xs font-sans">No announcements match the selected criteria or search query.</p>
            </div>
          ) : (
            filteredAnnouncements.map((ann, idx) => (
              <ScrollReveal 
                key={ann.id} 
                delay={Math.min(idx * 80, 240)}
                className="bg-white border border-border-custom p-6 md:p-8 space-y-4 shadow-3xs"
              >
                {/* Announcement Top Header Row */}
                <div className="flex justify-between items-start flex-wrap gap-2 border-b border-border-custom/50 pb-3">
                  <div className="flex items-center space-x-3">
                    <span className="p-2 rounded bg-[#FAF7F0] border border-border-custom/40 shadow-2xs">
                      {getIcon(ann)}
                    </span>
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        {getCategoryPill(ann.category)}
                        <span className="block font-mono text-[9px] uppercase tracking-widest text-gold-dark">
                          Bulletin ID: PLA-{ann.id}
                        </span>
                      </div>
                      <h3 className="font-serif text-base sm:text-lg font-bold text-emerald-custom leading-tight mt-1.5">
                        {ann.title}
                      </h3>
                    </div>
                  </div>
                </div>

                {/* Announcement Full Body Text */}
                <p className="text-xs sm:text-sm text-ink-soft font-sans leading-relaxed whitespace-pre-line">
                  {ann.body}
                </p>

                {/* Show logistics for Event Category in general feed card */}
                {ann.category === 'Upcoming Event' && ann.eventDate && (
                  <div className="p-3 bg-purple-50/40 border border-purple-100 rounded-xs space-y-1 text-xs font-sans text-purple-950">
                    <div className="flex items-center gap-2">
                      <Calendar size={12} className="text-purple-700" />
                      <span className="font-medium">Event Scheduled: {ann.eventDate}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin size={12} className="text-purple-700" />
                      <span>Venue: {ann.eventLocation || 'Central Secretariat'}</span>
                    </div>
                  </div>
                )}

                {/* Announcement Meta Footer Row */}
                <div className="bg-[#FAF7F0] border border-border-custom/60 px-4 py-3 flex flex-wrap items-center justify-between gap-4 text-[10px] font-mono text-ink-faint">
                  <div className="flex items-center space-x-1.5">
                    <Calendar size={12} className="text-gold-dark shrink-0" />
                    <span>Posted: {ann.date}</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <User size={12} className="text-gold-dark shrink-0" />
                    <span>By: {ann.postedBy}</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <MapPin size={12} className="text-gold-dark shrink-0" />
                    <span>Chapter: {ann.chapter}</span>
                  </div>
                </div>

              </ScrollReveal>
            ))
          )}
        </div>

      </div>
    </div>
  );
}
