import React, { useState, useEffect } from 'react';
import { PLAMember, UserState } from '../types';
import { PLA_MEMBERS } from '../data';
import ScrollReveal from './ScrollReveal';
import { DesignationBadge } from './DesignationBadge';
import { 
  Search, 
  Filter, 
  SlidersHorizontal, 
  ShieldCheck, 
  UserPlus, 
  Trash2, 
  Edit3, 
  Info,
  CheckCircle,
  AlertTriangle,
  XCircle,
  Phone,
  Mail,
  Calendar,
  Lock,
  Unlock,
  Plus
} from 'lucide-react';

interface PageDirectoryProps {
  userState: UserState;
  onLogAction?: (actionType: 'MEMBER_ADD' | 'MEMBER_EDIT' | 'MEMBER_DELETE' | 'MEMBER_RESET', details: string) => void;
}

export default function PageDirectory({ userState, onLogAction }: PageDirectoryProps) {
  // Database State - initialized from localStorage if available, otherwise from PLA_MEMBERS data
  const [members, setMembers] = useState<PLAMember[]>(() => {
    const localData = localStorage.getItem('pla_members_database');
    if (localData) {
      try {
        return JSON.parse(localData);
      } catch (e) {
        console.error('Error loading members from localStorage', e);
      }
    }
    return PLA_MEMBERS;
  });

  // Admin simulation state - initialized from user's current isAdmin or false
  const [adminSimulation, setAdminSimulation] = useState<boolean>(() => {
    if (userState.isAdmin) return true;
    // Check if current user is Nabeel Saad Khan, Rehana Rehmet, or Ch Numan Ali, who are admins
    const adminNames = ['Nabeel Saad Khan', 'Rehana Rehmet', 'Ch Numan Ali'];
    return adminNames.includes(userState.name);
  });

  // UI Search and Filter States
  const [searchQuery, setSearchQuery] = useState('');
  const [chapterFilter, setChapterFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [sortBy, setSortBy] = useState<'serial' | 'name' | 'date'>('serial');

  // Modal / Form state for Add/Edit Member
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedMember, setSelectedMember] = useState<PLAMember | null>(null);

  // Form Fields State
  const [formName, setFormName] = useState('');
  const [formRole, setFormRole] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formChapter, setFormChapter] = useState('Lahore Chapter');
  const [formStatus, setFormStatus] = useState<'Active' | 'Suspended' | 'Under Review'>('Active');
  const [formIsAdmin, setFormIsAdmin] = useState(false);
  const [formDesignation, setFormDesignation] = useState<'Senior Advocate' | 'Junior Advocate' | 'Counsel'>('Counsel');

  // Save database changes to localStorage
  useEffect(() => {
    localStorage.setItem('pla_members_database', JSON.stringify(members));
  }, [members]);

  // Unique chapters and status list
  const chapters = ['All', 'Islamabad Federal', 'Lahore Chapter', 'Karachi Chapter', 'Peshawar Chapter', 'Quetta Chapter'];
  const statuses = ['All', 'Active', 'Suspended', 'Under Review'];

  // Handle opening modal for Add New
  const handleOpenAddModal = () => {
    setFormName('');
    setFormRole('');
    setFormEmail('');
    setFormPhone('');
    setFormChapter('Lahore Chapter');
    setFormStatus('Active');
    setFormIsAdmin(false);
    setFormDesignation('Counsel');
    setShowAddModal(true);
  };

  // Handle opening modal for Edit
  const handleOpenEditModal = (member: PLAMember) => {
    setSelectedMember(member);
    setFormName(member.name);
    setFormRole(member.role);
    setFormEmail(member.email);
    setFormPhone(member.phone);
    setFormChapter(member.chapter);
    setFormStatus(member.status);
    setFormIsAdmin(!!member.isAdmin);
    setFormDesignation(member.designation || 'Counsel');
    setShowEditModal(true);
  };

  // Add Member
  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formRole.trim()) {
      alert('Name and Role are required fields.');
      return;
    }

    const nextSerial = members.length > 0 ? Math.max(...members.map(m => m.serialNo)) + 1 : 1;
    const paddedNum = String(nextSerial).padStart(3, '0');
    const newMember: PLAMember = {
      id: `PLA-MEM-${paddedNum}`,
      serialNo: nextSerial,
      name: formName.trim(),
      role: formRole.trim(),
      email: formEmail.trim() || `${formName.toLowerCase().replace(/\s+/g, '.')}@pakistanlegalalliance.org`,
      phone: formPhone.trim() || '+92 300 0000000',
      chapter: formChapter,
      status: formStatus,
      dateJoined: new Date().toISOString().split('T')[0],
      isAdmin: formIsAdmin,
      designation: formDesignation,
    };

    setMembers([...members, newMember]);
    
    if (onLogAction) {
      onLogAction('MEMBER_ADD', `Added new certified advocate "${formName.trim()}" with designation: "${formRole.trim()}" assigned to Chapter: ${formChapter} (ID: ${newMember.id}).`);
    }

    setShowAddModal(false);
  };

  // Edit Member
  const handleEditMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMember) return;

    const updatedMembers = members.map(m => {
      if (m.id === selectedMember.id) {
        return {
          ...m,
          name: formName.trim(),
          role: formRole.trim(),
          email: formEmail.trim(),
          phone: formPhone.trim(),
          chapter: formChapter,
          status: formStatus,
          isAdmin: formIsAdmin,
          designation: formDesignation,
        };
      }
      return m;
    });

    setMembers(updatedMembers);

    if (onLogAction) {
      onLogAction('MEMBER_EDIT', `Modified registration records for advocate "${formName.trim()}" (ID: ${selectedMember.id}). Designation set to: "${formRole.trim()}", Status: ${formStatus}.`);
    }

    setShowEditModal(false);
    setSelectedMember(null);
  };

  // Delete Member
  const handleDeleteMember = (id: string, name: string) => {
    if (window.confirm(`Are you sure you want to revoke and delete ${name} from the central registry?`)) {
      const updatedMembers = members.filter(m => m.id !== id);
      setMembers(updatedMembers);

      if (onLogAction) {
        onLogAction('MEMBER_DELETE', `Revoked and deleted member "${name}" with registration ID: ${id} from central registry database.`);
      }
    }
  };

  // Reset database back to default PLA_MEMBERS list
  const handleResetDatabase = () => {
    if (window.confirm('Are you sure you want to restore the master PLA database to its initial 16 certified members? Any local additions or edits will be reset.')) {
      setMembers(PLA_MEMBERS);
      localStorage.setItem('pla_members_database', JSON.stringify(PLA_MEMBERS));

      if (onLogAction) {
        onLogAction('MEMBER_RESET', 'Wiped all custom member directories and restored the master registry database to founding 16 certified members.');
      }
    }
  };

  // Filter and Sort Members logic
  const filteredMembers = members.filter(member => {
    const matchesSearch = 
      member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      member.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
      member.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      member.id.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesChapter = chapterFilter === 'All' || member.chapter === chapterFilter;
    const matchesStatus = statusFilter === 'All' || member.status === statusFilter;

    return matchesSearch && matchesChapter && matchesStatus;
  });

  // Apply sorting
  const sortedMembers = [...filteredMembers].sort((a, b) => {
    if (sortBy === 'name') {
      return a.name.localeCompare(b.name);
    } else if (sortBy === 'date') {
      return b.dateJoined.localeCompare(a.dateJoined);
    } else {
      return a.serialNo - b.serialNo;
    }
  });

  // Status Badge UI helper
  const getStatusBadge = (status: 'Active' | 'Suspended' | 'Under Review') => {
    switch (status) {
      case 'Active':
        return (
          <span className="inline-flex items-center space-x-1 border border-[#1C5A43] text-[#1C5A43] text-[9px] font-mono uppercase px-2 py-0.5 bg-emerald-50/20">
            <CheckCircle size={10} />
            <span>Active</span>
          </span>
        );
      case 'Suspended':
        return (
          <span className="inline-flex items-center space-x-1 border border-[#8B2E2E] text-[#8B2E2E] text-[9px] font-mono uppercase px-2 py-0.5 bg-red-50/20">
            <XCircle size={10} />
            <span>Suspended</span>
          </span>
        );
      case 'Under Review':
        return (
          <span className="inline-flex items-center space-x-1 border border-[#C9A227] text-[#A9841A] text-[9px] font-mono uppercase px-2 py-0.5 bg-amber-50/20">
            <AlertTriangle size={10} />
            <span>Under Review</span>
          </span>
        );
    }
  };

  return (
    <div className="w-full flex-grow p-4 md:p-8" id="pla-page-directory">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Page Title & Information Banner */}
        <div className="border-b border-[#D8D0BC] pb-4 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
          <div>
            <span className="font-mono text-[10px] text-[#A9841A] uppercase tracking-widest block font-bold">
              Central Bar Association
            </span>
            <h2 className="font-serif text-xl font-bold text-[#0F3D2E] uppercase mt-1">
              Certified Advocate Directory
            </h2>
            <p className="text-xs text-[#4A4A46] font-sans mt-0.5">
              Secure national registrar list containing accredited Pakistan Legal Alliance advocates and executives.
            </p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={handleResetDatabase}
              className="px-3 py-1.5 border border-[#D8D0BC] text-[10px] font-mono uppercase tracking-wider hover:bg-red-50 hover:text-[#8B2E2E] transition-colors cursor-pointer"
            >
              Reset Master DB
            </button>
            {adminSimulation && (
              <button
                onClick={handleOpenAddModal}
                className="px-3 py-1.5 bg-[#0F3D2E] text-white hover:bg-[#155642] text-[10px] font-mono uppercase tracking-wider flex items-center space-x-1 transition-colors cursor-pointer"
              >
                <Plus size={12} />
                <span>Add Advocate</span>
              </button>
            )}
          </div>
        </div>

        {/* ADMIN WORKSPACE SECURITY BAR */}
        <ScrollReveal delay={50} className="border border-[#D8D0BC] bg-[#FAF7F0] p-6 space-y-4">
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 pb-4 border-b border-[#D8D0BC]/50">
            <div className="flex items-center space-x-3">
              <div className={`p-2 border rounded-full ${adminSimulation ? 'bg-[#1C5A43]/10 border-[#1C5A43] text-[#1C5A43]' : 'bg-[#FAF7F0] border-[#D8D0BC] text-[#8A8578]'}`}>
                <ShieldCheck size={20} />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <h3 className="font-serif text-sm font-bold text-[#1C1C1A] uppercase">
                    Administrative Access & Permissions Console
                  </h3>
                  <span className={`text-[8px] font-mono uppercase px-1.5 py-0.5 border ${adminSimulation ? 'border-[#1C5A43] text-[#1C5A43] bg-emerald-50' : 'border-[#8A8578] text-[#8A8578]'}`}>
                    {adminSimulation ? 'AUTHENTICATED' : 'READ ONLY'}
                  </span>
                </div>
                <p className="text-[11px] text-[#8A8578] font-sans">
                  The Pakistan Legal Alliance Secretariat mandates strict separation of permissions. Toggle the switch below to test elevated Admin actions.
                </p>
              </div>
            </div>
            
            {/* Simulation Switch */}
            <button
              onClick={() => setAdminSimulation(!adminSimulation)}
              className={`flex items-center space-x-2 px-4 py-2 border transition-all duration-200 uppercase font-mono text-[10px] tracking-wider cursor-pointer ${
                adminSimulation 
                  ? 'bg-[#1C5A43] text-white border-[#1C5A43] hover:bg-[#155642]' 
                  : 'bg-white text-[#1C1C1A] border-[#1C1C1A] hover:bg-[#1C1C1A] hover:text-[#FAF7F0]'
              }`}
            >
              {adminSimulation ? <Unlock size={12} /> : <Lock size={12} />}
              <span>{adminSimulation ? 'Deactivate Admin Mode' : 'Simulate Admin Role'}</span>
            </button>
          </div>

          {/* Detailed explanation of extra permissions granted to Admins */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 pt-2">
            <div className="p-3 border border-[#D8D0BC]/60 bg-white/50 space-y-1">
              <span className="font-mono text-[9px] text-[#A9841A] font-bold block">01 / DATABASE MUTABILITY</span>
              <p className="text-[11px] text-[#4A4A46] font-sans leading-relaxed">
                Admins have direct write-access to **Insert new advocates**, **Update registered profiles**, or **Revoke/Delete** invalid records from the master index.
              </p>
            </div>
            <div className="p-3 border border-[#D8D0BC]/60 bg-white/50 space-y-1">
              <span className="font-mono text-[9px] text-[#A9841A] font-bold block">02 / STATUS COMPLIANCE AUDIT</span>
              <p className="text-[11px] text-[#4A4A46] font-sans leading-relaxed">
                Authority to flag credentials as **Active**, **Suspended** (for ethics/licensing issues), or **Under Review** (pending continuing education audits).
              </p>
            </div>
            <div className="p-3 border border-[#D8D0BC]/60 bg-white/50 space-y-1">
              <span className="font-mono text-[9px] text-[#A9841A] font-bold block">03 / CHAPTER LEADERSHIP ASSIGNMENT</span>
              <p className="text-[11px] text-[#4A4A46] font-sans leading-relaxed">
                Permission to promote certified advocates to administrative seats (such as President, General Secretary, or Director) in local regional boards.
              </p>
            </div>
            <div className="p-3 border border-[#D8D0BC]/60 bg-[#F1ECDD]/40 space-y-1">
              <span className="font-mono text-[9px] text-[#8B2E2E] font-bold block">04 / SECRETARIAT COMPLIANCE</span>
              <p className="text-[11px] text-[#8B2E2E] font-sans leading-relaxed font-medium">
                Admin accounts bypass regional locks to override standards-adherence mandates, waive CLE compliance notices, or audit ethical disputes.
              </p>
            </div>
          </div>
        </ScrollReveal>

        {/* Search, Filter & Sort Controls */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 bg-white border border-[#D8D0BC] p-4 items-center">
          
          {/* Search box (takes col-span-5) */}
          <div className="lg:col-span-5 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8A8578]" size={16} />
            <input
              type="text"
              placeholder="Search by advocate name, title, email, registration id..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-[#D8D0BC] bg-transparent text-sm focus:outline-none focus:border-[#0F3D2E] font-sans text-[#1C1C1A]"
            />
          </div>

          {/* Filter Chapter (takes col-span-3) */}
          <div className="lg:col-span-3 flex items-center space-x-2">
            <Filter size={14} className="text-[#8A8578] shrink-0" />
            <select
              value={chapterFilter}
              onChange={(e) => setChapterFilter(e.target.value)}
              className="w-full p-2 border border-[#D8D0BC] bg-transparent text-xs font-mono text-[#1C1C1A] focus:outline-none focus:border-[#0F3D2E]"
            >
              {chapters.map(ch => (
                <option key={ch} value={ch} className="bg-white">{ch === 'All' ? 'All Chapters' : ch}</option>
              ))}
            </select>
          </div>

          {/* Filter Status (takes col-span-2) */}
          <div className="lg:col-span-2 flex items-center space-x-2">
            <SlidersHorizontal size={14} className="text-[#8A8578] shrink-0" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full p-2 border border-[#D8D0BC] bg-transparent text-xs font-mono text-[#1C1C1A] focus:outline-none focus:border-[#0F3D2E]"
            >
              {statuses.map(st => (
                <option key={st} value={st} className="bg-white">{st === 'All' ? 'All Statuses' : st}</option>
              ))}
            </select>
          </div>

          {/* Sort controls (takes col-span-2) */}
          <div className="lg:col-span-2">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full p-2 border border-[#D8D0BC] bg-transparent text-xs font-mono text-[#1C1C1A] focus:outline-none focus:border-[#0F3D2E]"
            >
              <option value="serial" className="bg-white">Sort by Serial</option>
              <option value="name" className="bg-white">Sort by Name</option>
              <option value="date" className="bg-white">Sort by Date Joined</option>
            </select>
          </div>

        </div>

        {/* Results Info Bar */}
        <div className="flex justify-between items-center text-xs text-[#8A8578] font-mono px-1">
          <span>SHOWING {sortedMembers.length} OF {members.length} PLA CERTIFIED ADVOCATES</span>
          {chapterFilter !== 'All' || statusFilter !== 'All' || searchQuery ? (
            <button 
              onClick={() => {
                setSearchQuery('');
                setChapterFilter('All');
                setStatusFilter('All');
              }}
              className="text-[#C9A227] hover:underline"
            >
              Clear Filters
            </button>
          ) : null}
        </div>

        {/* MASTER ADVOCATE REGISTRY LIST/GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sortedMembers.map((member, idx) => (
            <ScrollReveal 
              key={member.id} 
              delay={idx * 30}
              className="bg-white border border-[#D8D0BC] p-6 flex flex-col justify-between relative overflow-hidden group hover:border-[#0F3D2E] transition-all"
            >
              {/* Gold admin indicator border for admins */}
              {member.isAdmin && (
                <div className="absolute top-0 left-0 right-0 h-1 bg-[#C9A227]" title="Administrative Council Member" />
              )}

              <div className="space-y-4">
                {/* Header: ID and Serial No */}
                <div className="flex justify-between items-center border-b border-[#D8D0BC]/40 pb-2.5">
                  <span className="font-mono text-[10px] text-[#8A8578] font-bold">
                    {member.id}
                  </span>
                  <div className="flex items-center space-x-1.5">
                    <span className="font-mono text-[9px] bg-[#FAF7F0] border border-[#D8D0BC] px-1.5 text-[#8A8578]">
                      SR: {member.serialNo}
                    </span>
                    {member.isAdmin && (
                      <span className="font-mono text-[8px] bg-[#C9A227]/10 border border-[#C9A227] px-1.5 text-[#A9841A] font-bold">
                        ADMIN
                      </span>
                    )}
                  </div>
                </div>

                {/* Profile detail */}
                <div>
                  <h3 className="font-serif text-base font-bold text-[#1C1C1A] uppercase leading-tight tracking-tight group-hover:text-[#0F3D2E] transition-colors">
                    {member.name}
                  </h3>
                  <p className="text-xs font-mono text-[#A9841A] mt-1 leading-normal font-semibold">
                    {member.role}
                  </p>
                  {member.designation && (
                    <div className="mt-2">
                      <DesignationBadge designation={member.designation} size="sm" />
                    </div>
                  )}
                </div>

                {/* Chapter & Contact Cards */}
                <div className="space-y-1.5 text-[11px] text-[#4A4A46] font-sans border-t border-b border-[#D8D0BC]/20 py-3">
                  <div className="flex items-center space-x-2">
                    <span className="text-[#8A8578] font-mono text-[9px] w-14 shrink-0 uppercase">Chapter:</span>
                    <span className="font-medium text-[#1C1C1A]">{member.chapter}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Mail size={12} className="text-[#8A8578] shrink-0" />
                    <span className="truncate" title={member.email}>{member.email}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Phone size={12} className="text-[#8A8578] shrink-0" />
                    <span>{member.phone}</span>
                  </div>
                </div>
              </div>

              {/* Card Footer: Status and Admin actions */}
              <div className="flex justify-between items-center pt-4 mt-4 border-t border-[#D8D0BC]/40">
                <div className="flex items-center space-x-1 text-[10px] font-mono text-[#8A8578]">
                  <Calendar size={11} />
                  <span>Joined: {member.dateJoined}</span>
                </div>

                <div className="flex items-center space-x-2">
                  {getStatusBadge(member.status)}
                  
                  {/* ADMIN CONTROLS IN PLACE */}
                  {adminSimulation && (
                    <div className="flex items-center space-x-1 border-l border-[#D8D0BC] pl-2 ml-1">
                      <button
                        onClick={() => handleOpenEditModal(member)}
                        className="p-1 text-[#A9841A] hover:bg-[#FAF7F0] border border-transparent hover:border-[#D8D0BC] transition-colors cursor-pointer"
                        title="Edit credentials"
                      >
                        <Edit3 size={12} />
                      </button>
                      <button
                        onClick={() => handleDeleteMember(member.id, member.name)}
                        className="p-1 text-[#8B2E2E] hover:bg-red-50 border border-transparent hover:border-red-200 transition-colors cursor-pointer"
                        title="Revoke and delete member"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                  )}
                </div>
              </div>

            </ScrollReveal>
          ))}
        </div>

        {/* Empty Search State */}
        {sortedMembers.length === 0 && (
          <div className="text-center py-16 border border-[#D8D0BC] bg-white space-y-4">
            <Info size={40} className="mx-auto text-[#A9841A]" />
            <div className="space-y-1">
              <h3 className="font-serif text-lg font-bold text-[#1C1C1A] uppercase">
                No Certified Advocates Found
              </h3>
              <p className="text-xs text-[#8A8578] font-sans max-w-md mx-auto leading-relaxed">
                No member matched your search query "{searchQuery}" in chapter "{chapterFilter}" with status "{statusFilter}". Please verify names or clear active filters.
              </p>
            </div>
            <button
              onClick={() => {
                setSearchQuery('');
                setChapterFilter('All');
                setStatusFilter('All');
              }}
              className="px-4 py-2 border border-[#1C1C1A] font-mono text-xs uppercase tracking-wider hover:bg-[#1C1C1A] hover:text-[#FAF7F0] transition-all cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        )}

      </div>

      {/* ================= ADD ADVOCATE MODAL ================= */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/45 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white border border-[#D8D0BC] shadow-2xl p-6 md:p-8 space-y-6">
            <div className="border-b border-[#D8D0BC] pb-3 flex justify-between items-center">
              <div>
                <span className="font-mono text-[9px] text-[#A9841A] uppercase tracking-widest block font-bold">Secretariat Action</span>
                <h3 className="font-serif text-lg font-bold text-[#0F3D2E] uppercase">Register New Advocate</h3>
              </div>
              <button 
                onClick={() => setShowAddModal(false)}
                className="text-[#8A8578] hover:text-[#1C1C1A] font-mono text-xs border border-[#D8D0BC] px-2 py-1 cursor-pointer"
              >
                Close
              </button>
            </div>

            <form onSubmit={handleAddMember} className="space-y-4">
              <div className="grid grid-cols-1 gap-4">
                
                {/* Full Name */}
                <div className="space-y-1">
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-[#1C1C1A]">Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Nabeel Saad Khan"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="w-full p-2 border border-[#D8D0BC] focus:outline-none focus:border-[#0F3D2E] text-sm font-sans"
                  />
                </div>

                {/* Society Role */}
                <div className="space-y-1">
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-[#1C1C1A]">Official Society Role *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Head Of Constitution And Policy"
                    value={formRole}
                    onChange={(e) => setFormRole(e.target.value)}
                    className="w-full p-2 border border-[#D8D0BC] focus:outline-none focus:border-[#0F3D2E] text-sm font-sans"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Email */}
                  <div className="space-y-1">
                    <label className="block text-[10px] font-mono uppercase tracking-wider text-[#1C1C1A]">Official Email</label>
                    <input
                      type="email"
                      placeholder="Leave blank for auto-generate"
                      value={formEmail}
                      onChange={(e) => setFormEmail(e.target.value)}
                      className="w-full p-2 border border-[#D8D0BC] focus:outline-none focus:border-[#0F3D2E] text-sm font-sans"
                    />
                  </div>

                  {/* Phone */}
                  <div className="space-y-1">
                    <label className="block text-[10px] font-mono uppercase tracking-wider text-[#1C1C1A]">Contact Phone</label>
                    <input
                      type="text"
                      placeholder="+92 300 1234567"
                      value={formPhone}
                      onChange={(e) => setFormPhone(e.target.value)}
                      className="w-full p-2 border border-[#D8D0BC] focus:outline-none focus:border-[#0F3D2E] text-sm font-sans"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Chapter */}
                  <div className="space-y-1">
                    <label className="block text-[10px] font-mono uppercase tracking-wider text-[#1C1C1A]">Regional Chapter</label>
                    <select
                      value={formChapter}
                      onChange={(e) => setFormChapter(e.target.value)}
                      className="w-full p-2 border border-[#D8D0BC] focus:outline-none focus:border-[#0F3D2E] text-sm font-mono"
                    >
                      {chapters.filter(ch => ch !== 'All').map(ch => (
                        <option key={ch} value={ch}>{ch}</option>
                      ))}
                    </select>
                  </div>

                  {/* Status */}
                  <div className="space-y-1">
                    <label className="block text-[10px] font-mono uppercase tracking-wider text-[#1C1C1A]">Accreditation Status</label>
                    <select
                      value={formStatus}
                      onChange={(e) => setFormStatus(e.target.value as any)}
                      className="w-full p-2 border border-[#D8D0BC] focus:outline-none focus:border-[#0F3D2E] text-sm font-mono"
                    >
                      <option value="Active">Active</option>
                      <option value="Suspended">Suspended</option>
                      <option value="Under Review">Under Review</option>
                    </select>
                  </div>
                </div>

                {/* Designation */}
                <div className="space-y-1">
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-[#1C1C1A]">Member Designation *</label>
                  <select
                    value={formDesignation}
                    onChange={(e) => setFormDesignation(e.target.value as any)}
                    className="w-full p-2 border border-[#D8D0BC] focus:outline-none focus:border-[#0F3D2E] text-sm font-mono"
                  >
                    <option value="Senior Advocate">Senior Advocate</option>
                    <option value="Junior Advocate">Junior Advocate</option>
                    <option value="Counsel">Counsel</option>
                  </select>
                </div>

                {/* Admin Flag */}
                <div className="flex items-center space-x-2 pt-2">
                  <input
                    type="checkbox"
                    id="add-isAdmin"
                    checked={formIsAdmin}
                    onChange={(e) => setFormIsAdmin(e.target.checked)}
                    className="w-4 h-4 text-[#0F3D2E] focus:ring-0 border-[#D8D0BC] rounded-xs cursor-pointer"
                  />
                  <label htmlFor="add-isAdmin" className="text-xs font-mono uppercase text-[#1C1C1A] cursor-pointer">
                    Grant elevated administrative access credentials
                  </label>
                </div>

              </div>

              <div className="border-t border-[#D8D0BC] pt-4 mt-6 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 border border-[#D8D0BC] text-xs font-mono uppercase tracking-wider hover:bg-[#FAF7F0] transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#0F3D2E] text-white hover:bg-[#155642] text-xs font-mono uppercase tracking-wider transition-colors cursor-pointer"
                >
                  Confirm Registration
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= EDIT ADVOCATE MODAL ================= */}
      {showEditModal && selectedMember && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/45 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white border border-[#D8D0BC] shadow-2xl p-6 md:p-8 space-y-6">
            <div className="border-b border-[#D8D0BC] pb-3 flex justify-between items-center">
              <div>
                <span className="font-mono text-[9px] text-[#A9841A] uppercase tracking-widest block font-bold">Secretariat Record Audit</span>
                <h3 className="font-serif text-lg font-bold text-[#0F3D2E] uppercase">Edit Registered Credentials</h3>
              </div>
              <button 
                onClick={() => setShowEditModal(false)}
                className="text-[#8A8578] hover:text-[#1C1C1A] font-mono text-xs border border-[#D8D0BC] px-2 py-1 cursor-pointer"
              >
                Close
              </button>
            </div>

            <form onSubmit={handleEditMember} className="space-y-4">
              <div className="bg-[#FAF7F0] border border-[#D8D0BC]/60 p-3 text-[10px] font-mono text-[#8A8578]">
                AUDITING REGISTRATION ID: {selectedMember.id} · ORIGINAL SR: {selectedMember.serialNo}
              </div>

              <div className="grid grid-cols-1 gap-4">
                
                {/* Full Name */}
                <div className="space-y-1">
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-[#1C1C1A]">Full Name</label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="w-full p-2 border border-[#D8D0BC] focus:outline-none focus:border-[#0F3D2E] text-sm font-sans"
                  />
                </div>

                {/* Society Role */}
                <div className="space-y-1">
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-[#1C1C1A]">Official Society Role</label>
                  <input
                    type="text"
                    required
                    value={formRole}
                    onChange={(e) => setFormRole(e.target.value)}
                    className="w-full p-2 border border-[#D8D0BC] focus:outline-none focus:border-[#0F3D2E] text-sm font-sans"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Email */}
                  <div className="space-y-1">
                    <label className="block text-[10px] font-mono uppercase tracking-wider text-[#1C1C1A]">Official Email</label>
                    <input
                      type="email"
                      required
                      value={formEmail}
                      onChange={(e) => setFormEmail(e.target.value)}
                      className="w-full p-2 border border-[#D8D0BC] focus:outline-none focus:border-[#0F3D2E] text-sm font-sans"
                    />
                  </div>

                  {/* Phone */}
                  <div className="space-y-1">
                    <label className="block text-[10px] font-mono uppercase tracking-wider text-[#1C1C1A]">Contact Phone</label>
                    <input
                      type="text"
                      required
                      value={formPhone}
                      onChange={(e) => setFormPhone(e.target.value)}
                      className="w-full p-2 border border-[#D8D0BC] focus:outline-none focus:border-[#0F3D2E] text-sm font-sans"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Chapter */}
                  <div className="space-y-1">
                    <label className="block text-[10px] font-mono uppercase tracking-wider text-[#1C1C1A]">Regional Chapter</label>
                    <select
                      value={formChapter}
                      onChange={(e) => setFormChapter(e.target.value)}
                      className="w-full p-2 border border-[#D8D0BC] focus:outline-none focus:border-[#0F3D2E] text-sm font-mono"
                    >
                      {chapters.filter(ch => ch !== 'All').map(ch => (
                        <option key={ch} value={ch}>{ch}</option>
                      ))}
                    </select>
                  </div>

                  {/* Status */}
                  <div className="space-y-1">
                    <label className="block text-[10px] font-mono uppercase tracking-wider text-[#1C1C1A]">Accreditation Status</label>
                    <select
                      value={formStatus}
                      onChange={(e) => setFormStatus(e.target.value as any)}
                      className="w-full p-2 border border-[#D8D0BC] focus:outline-none focus:border-[#0F3D2E] text-sm font-mono"
                    >
                      <option value="Active">Active</option>
                      <option value="Suspended">Suspended</option>
                      <option value="Under Review">Under Review</option>
                    </select>
                  </div>
                </div>

                {/* Designation */}
                <div className="space-y-1">
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-[#1C1C1A]">Member Designation *</label>
                  <select
                    value={formDesignation}
                    onChange={(e) => setFormDesignation(e.target.value as any)}
                    className="w-full p-2 border border-[#D8D0BC] focus:outline-none focus:border-[#0F3D2E] text-sm font-mono"
                  >
                    <option value="Senior Advocate">Senior Advocate</option>
                    <option value="Junior Advocate">Junior Advocate</option>
                    <option value="Counsel">Counsel</option>
                  </select>
                </div>

                {/* Admin Flag */}
                <div className="flex items-center space-x-2 pt-2">
                  <input
                    type="checkbox"
                    id="edit-isAdmin"
                    checked={formIsAdmin}
                    onChange={(e) => setFormIsAdmin(e.target.checked)}
                    className="w-4 h-4 text-[#0F3D2E] focus:ring-0 border-[#D8D0BC] rounded-xs cursor-pointer"
                  />
                  <label htmlFor="edit-isAdmin" className="text-xs font-mono uppercase text-[#1C1C1A] cursor-pointer">
                    Grant elevated administrative access credentials
                  </label>
                </div>

              </div>

              <div className="border-t border-[#D8D0BC] pt-4 mt-6 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="px-4 py-2 border border-[#D8D0BC] text-xs font-mono uppercase tracking-wider hover:bg-[#FAF7F0] transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#0F3D2E] text-white hover:bg-[#155642] text-xs font-mono uppercase tracking-wider transition-colors cursor-pointer"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
