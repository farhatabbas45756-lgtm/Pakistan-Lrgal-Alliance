import React, { useState, useEffect } from 'react';
import { ActivePage, UserState } from '../types';
import PLASeal from './PLASeal';
import ScrollReveal from './ScrollReveal';
import { Shield, Eye, EyeOff, CheckCircle, ArrowRight } from 'lucide-react';
import { confirmPasswordReset, signInWithEmailAndPassword } from 'firebase/auth';
import { doc, updateDoc } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';

interface PageResetPasswordProps {
  onNavigate: (page: ActivePage) => void;
  onSignIn: (name: string, email: string, memberId: string, isAdmin?: boolean, token?: string) => void;
}

export default function PageResetPassword({ onNavigate, onSignIn }: PageResetPasswordProps) {
  const [email, setEmail] = useState('');
  const [oobCode, setOobCode] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Read email/oobCode from URL query or hash params
  useEffect(() => {
    const handleUrlParsing = () => {
      // Check query parameters
      const urlParams = new URLSearchParams(window.location.search);
      const queryEmail = urlParams.get('email');
      const queryCode = urlParams.get('oobCode');

      // Check hash parameters (common in single-page apps)
      const hash = window.location.hash;
      const hashParams = new URLSearchParams(hash.substring(hash.indexOf('?')));
      const hashEmail = hashParams.get('email');
      const hashUid = hashParams.get('uid');
      const hashCode = hashParams.get('code') || hashParams.get('oobCode');

      const finalEmail = queryEmail || hashEmail || '';
      const finalCode = queryCode || hashCode || hashUid || '';

      if (finalEmail) setEmail(finalEmail);
      if (finalCode) setOobCode(finalCode);
    };

    handleUrlParsing();
    window.addEventListener('hashchange', handleUrlParsing);
    return () => window.removeEventListener('hashchange', handleUrlParsing);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      if (oobCode && !oobCode.startsWith('sandbox_code')) {
        // Real Firebase Auth Password reset
        await confirmPasswordReset(auth, oobCode, password);

        // Instantly sign the user in with their new password to get their UID
        if (email) {
          const userCredential = await signInWithEmailAndPassword(auth, email, password);
          const user = userCredential.user;
          const idToken = await user.getIdToken();

          // Invoke secure server-side activation state transition only
          const activateResponse = await fetch('/api/activateMember', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${idToken}`
            }
          });
          const activateData = await activateResponse.json();
          if (!activateResponse.ok) {
            throw new Error(activateData.error || 'Server rejected credential activation handshake.');
          }

          // Trigger state sign-in
          const displayName = activateData.displayName || user.displayName || email.split('@')[0].toUpperCase();
          const memberId = activateData.memberId || 'PLA-' + Math.floor(100000 + Math.random() * 900000);
          
          onSignIn(displayName, email, memberId, false, idToken);
          setIsSuccess(true);
          
          setTimeout(() => {
            onNavigate('dashboard');
          }, 2000);
          return;
        }
      }

      // Sandbox Fallback
      // If we are in local sandbox mode, update the local registry
      const localData = localStorage.getItem('pla_members_database');
      if (localData) {
        try {
          const membersList = JSON.parse(localData);
          const matchedIndex = membersList.findIndex((m: any) => m.email.toLowerCase() === email.toLowerCase());
          if (matchedIndex !== -1) {
            membersList[matchedIndex].status = 'Active';
            localStorage.setItem('pla_members_database', JSON.stringify(membersList));
          }
        } catch (e) {
          console.error('Error updating local member status:', e);
        }
      }

      setIsSuccess(true);
      setTimeout(() => {
        // Log them into the dashboard directly
        const cleanName = email.split('@')[0].replace('.', ' ').toUpperCase();
        onSignIn(cleanName, email, 'PLA-2026-ACTIVE', false);
        onNavigate('dashboard');
      }, 2000);

    } catch (err: any) {
      console.error('Password reset failure:', err);
      setError(err.message || 'Failed to complete password reset. The link may have expired.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="w-full min-h-[calc(100vh-140px)] bg-paper flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8" id="pla-page-reset-password">
      <div className="w-full max-w-md bg-paper border border-border-custom p-8 shadow-sm flex flex-col justify-between min-h-[480px]">
        
        <div className="space-y-6">
          {/* Header Seal */}
          <div className="flex flex-col items-center text-center space-y-3">
            <PLASeal size="sm" />
            <div>
              <h2 className="font-serif text-lg font-bold text-emerald-custom tracking-tight uppercase">
                Establish Secure Password
              </h2>
              <span className="block text-[8px] font-mono tracking-widest text-gold-dark uppercase mt-0.5">
                Pakistan Legal Alliance
              </span>
            </div>
            <div className="w-12 h-px bg-gold-custom mt-2" />
          </div>

          {isSuccess ? (
            <ScrollReveal className="space-y-4 text-center py-6">
              <CheckCircle size={48} className="text-emerald-custom mx-auto" />
              <h3 className="font-serif text-base font-bold text-emerald-custom">
                Credentials Active
              </h3>
              <p className="text-xs text-ink-soft font-sans leading-relaxed">
                Your secure password has been registered and verified by the Secretariat. Your account is now active.
              </p>
              <p className="text-[10px] font-mono text-gold-dark uppercase tracking-widest animate-pulse">
                Initiating secure dashboard connection...
              </p>
            </ScrollReveal>
          ) : (
            <ScrollReveal className="space-y-4">
              <div className="p-3 bg-[#FAF7F0] border border-[#D8D0BC] rounded-xs text-xs font-sans text-ink-soft">
                <span className="font-semibold text-emerald-custom block">Account Activation:</span>
                Establishing credentials for <strong>{email || 'Advocate Registry'}</strong>.
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Password field */}
                <div>
                  <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1 font-semibold">
                    New Secure Password *
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-paper border border-border-custom px-3 py-2 pl-9 pr-9 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
                      placeholder="••••••••••••"
                    />
                    <Shield className="absolute left-3 top-2.5 text-ink-faint" size={12} />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-2 text-ink-faint hover:text-ink cursor-pointer"
                    >
                      {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                    </button>
                  </div>
                </div>

                {/* Confirm Password field */}
                <div>
                  <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1 font-semibold">
                    Confirm Password *
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full bg-paper border border-border-custom px-3 py-2 pl-9 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
                      placeholder="••••••••••••"
                    />
                    <Shield className="absolute left-3 top-2.5 text-ink-faint" size={12} />
                  </div>
                </div>

                {error && (
                  <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-800 text-xs font-sans rounded-xs">
                    {error}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-emerald-custom text-paper hover:bg-emerald-light disabled:opacity-50 py-2.5 font-mono text-xs uppercase tracking-widest font-bold transition-all border border-gold-custom cursor-pointer flex items-center justify-center space-x-2"
                >
                  <span>{isSubmitting ? 'Registering Security Key...' : 'Activate Account'}</span>
                  <ArrowRight size={12} />
                </button>
              </form>
            </ScrollReveal>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-border-custom/50 pt-4 text-center mt-6">
          <span className="font-mono text-[8px] text-ink-faint uppercase tracking-wider block">
            PLA CENTRAL REGISTRY SECURITY · ISLAMABAD
          </span>
        </div>

      </div>
    </div>
  );
}
