import React, { useRef } from 'react';
import { ActivePage, UserState, AnnouncementItem, PLAMember } from '../types';
import { CASE_REFERRALS, PLA_MEMBERS } from '../data';
import ScrollReveal from './ScrollReveal';
import { DesignationBadge } from './DesignationBadge';
import { 
  ShieldCheck, 
  FileSpreadsheet, 
  GraduationCap, 
  BellRing, 
  ChevronRight, 
  Clock, 
  MessageSquare,
  AlertCircle 
} from 'lucide-react';

interface PageDashboardProps {
  onNavigate: (page: ActivePage) => void;
  userState: UserState;
  announcements: AnnouncementItem[];
}

export default function PageDashboard({ onNavigate, userState, announcements }: PageDashboardProps) {
  // Load members to find specific roles or designations
  const [members] = React.useState<PLAMember[]>(() => {
    const localData = localStorage.getItem('pla_members_database');
    if (localData) {
      try {
        return JSON.parse(localData);
      } catch (e) {
        console.error('Error loading members from localStorage', e);
      }
    }
    return PLA_MEMBERS;
  });

  const matchedMember = members.find(
    m => m.name.toLowerCase() === userState.name.toLowerCase() || 
         m.email.toLowerCase() === userState.email.toLowerCase() ||
         m.id.toLowerCase() === userState.memberId.toLowerCase()
  );
  const designation = matchedMember ? matchedMember.role : (userState.isAdmin ? 'Central Secretariat Administrator' : 'Accredited Advocate');

  // Swipe gesture detection to navigate between Dashboard and Announcements
  const touchStartX = useRef<number | null>(null);
  const touchEndX = useRef<number | null>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.targetTouches[0].clientX;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndX.current = e.targetTouches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (!touchStartX.current || !touchEndX.current) return;
    
    const distance = touchStartX.current - touchEndX.current;
    const minSwipeDistance = 75; // minimum 75px swipe

    // Swipe Left (drag finger right to left) -> Navigate to Announcements
    if (distance > minSwipeDistance) {
      onNavigate('announcements');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const statCards = [
    {
      title: 'Membership Status',
      value: 'Accredited',
      desc: 'Active · Exp. Dec 2026',
      badge: <div className="w-3 h-3 bg-[#1C5A43] rounded-full"></div>,
      color: 'border-[#D8D0BC] bg-transparent text-[#0F3D2E]',
      valueClass: 'text-2xl font-serif text-[#0F3D2E] tracking-tight font-bold',
    },
    {
      title: 'Open Referrals',
      value: '2 Assigned',
      desc: '3 Under Review',
      badge: <span className="text-[10px] text-[#1C5A43] uppercase tracking-tighter font-mono font-bold">+2 Today</span>,
      color: 'border-[#D8D0BC] bg-transparent text-[#1C1C1A]',
      valueClass: 'text-2xl sm:text-3xl font-serif text-[#1C1C1A] font-bold',
    },
    {
      title: 'CLE Credits',
      value: '12 / 15 Hrs',
      desc: 'Deadline August 15',
      badge: <span className="text-[10px] text-[#8A8578] uppercase font-mono font-medium">Goal: 15.0</span>,
      color: 'border-[#D8D0BC] bg-transparent text-[#1C1C1A]',
      valueClass: 'text-2xl sm:text-3xl font-serif text-[#1C1C1A] font-bold',
    },
    {
      title: 'Pending Notices',
      value: '05 Notices',
      desc: 'Mandatory Secretariat review',
      badge: <span className="text-[10px] text-[#8B2E2E] uppercase tracking-widest font-mono font-bold">Urgent</span>,
      color: 'border-[#D8D0BC] bg-[#F1ECDD] text-[#8B2E2E]',
      valueClass: 'text-2xl sm:text-3xl font-serif text-[#8B2E2E] font-bold',
    },
  ];

  // Get first 3 announcements for the teaser panel
  const recentAnnouncements = announcements.slice(0, 3);

  const getStatusClass = (status: 'Pending Review' | 'Active Assignment' | 'Resolved') => {
    switch (status) {
      case 'Pending Review':
        return 'border-[#C9A227] text-[#A9841A]';
      case 'Active Assignment':
      case 'Resolved':
      default:
        return 'border-[#1C5A43] text-[#1C5A43]';
    }
  };

  return (
    <div 
      className="w-full flex-grow p-4 md:p-8" 
      id="pla-page-dashboard"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Mobile visible fallback navigation tabs */}
      <div className="md:hidden mb-6 border-b border-[#D8D0BC] pb-2 flex justify-center space-x-2">
        <button
          onClick={() => onNavigate('dashboard')}
          className="flex-1 text-center py-2 font-mono text-[10px] uppercase tracking-wider bg-[#0F3D2E] text-white font-bold"
        >
          Workspace Dashboard
        </button>
        <button
          onClick={() => {
            onNavigate('announcements');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="flex-1 text-center py-2 font-mono text-[10px] uppercase tracking-wider bg-transparent border border-[#D8D0BC] text-[#4A4A46] hover:text-[#0F3D2E]"
        >
          Announcements (5)
        </button>
      </div>

      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Welcome Banner */}
        <div className="bg-[#FAF7F0] border border-[#D8D0BC] p-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <span className="font-mono text-[10px] text-[#A9841A] uppercase tracking-widest block font-bold">
              Central Bar Portal
            </span>
            <h2 className="font-serif text-xl font-bold text-[#0F3D2E] mt-1 uppercase">
              Welcome back, {userState.name}
            </h2>
            <div className="flex flex-wrap items-center gap-2 mt-1.5">
              <span className="inline-block px-1.5 py-0.5 bg-emerald-100 border border-emerald-300 text-[#1C5A43] text-[8px] uppercase tracking-wider font-mono font-bold rounded-xs">
                Society Role
              </span>
              <span className="text-xs text-[#0F3D2E] font-sans font-semibold">
                {designation}
              </span>
              {matchedMember?.designation && (
                <DesignationBadge designation={matchedMember.designation} size="sm" />
              )}
            </div>
            <p className="text-[11px] text-[#4A4A46] font-sans mt-1">
              Secure console active. Your digital bar card is certified with PLA Secretariat.
            </p>
          </div>
          <div className="font-mono text-[10px] bg-transparent border border-[#D8D0BC] px-3 py-1.5 text-[#4A4A46] uppercase shrink-0">
            MEMBER ID: {userState.memberId}
          </div>
        </div>

        {/* 1. Stat Cards Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {statCards.map((stat, idx) => (
            <ScrollReveal 
              key={idx} 
              delay={idx * 50} 
              className={`border p-5 flex flex-col justify-between h-32 ${stat.color}`}
            >
              <div className="flex justify-between items-start">
                <span className="font-mono text-[10px] text-[#8A8578] uppercase tracking-widest">
                  {stat.title}
                </span>
              </div>
              <div className="flex items-end justify-between mt-2">
                <span className={stat.valueClass}>
                  {stat.value}
                </span>
                {stat.badge}
              </div>
            </ScrollReveal>
          ))}
        </div>

        {/* 2. Grid for Referrals and News/Bulletins in 2:1 format (col-span-2 & col-span-1) */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          
          {/* Left: Open Referrals Data Table (takes col-span-2) */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-baseline justify-between border-b border-[#1C1C1A] pb-2">
              <h3 className="text-sm uppercase tracking-widest font-bold font-sans text-[#1C1C1A]">
                Open Referrals Registry
              </h3>
              <span className="text-[10px] text-[#8A8578] font-mono">
                Updated 14:02 PKT
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead className="border-b border-[#D8D0BC] text-[10px] uppercase tracking-widest text-[#8A8578] font-mono">
                  <tr>
                    <th className="py-3 font-normal">Case Ref.</th>
                    <th className="py-3 font-normal">District</th>
                    <th className="py-3 font-normal text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="text-sm divide-y divide-[#D8D0BC]/50">
                  {CASE_REFERRALS.map((ref, idx) => (
                    <tr key={idx} className="hover:bg-[#FAF7F0]/40 transition-colors">
                      <td className="py-4 font-mono text-xs text-[#1C1C1A]">
                        {ref.ref}
                      </td>
                      <td className="py-4 text-[#4A4A46] font-sans">
                        {ref.district}
                      </td>
                      <td className="py-4 text-right">
                        <span className={`inline-block px-2 py-0.5 border text-[10px] uppercase font-mono tracking-wider ${getStatusClass(ref.status)}`}>
                          {ref.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="mt-6 border-t border-[#D8D0BC]/50 pt-4 flex items-start space-x-2 text-[10px] text-[#8A8578]">
              <AlertCircle size={14} className="text-[#A9841A] shrink-0 mt-0.5" />
              <p className="font-sans leading-relaxed">
                Referral matching algorithms operate under Chapter IV Guidelines of the Central Admissions board. If you wish to decline a matched district case, file a waiver amicus within 72 hours.
              </p>
            </div>
          </div>

          {/* Right: Recent Bulletins list (takes col-span-1) */}
          <div className="space-y-4">
            <div className="flex items-baseline justify-between border-b border-[#1C1C1A] pb-2">
              <h3 className="text-sm uppercase tracking-widest font-bold font-sans text-[#1C1C1A]">
                Recent Bulletins
              </h3>
              <button
                onClick={() => {
                  onNavigate('announcements');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="text-[10px] text-[#C9A227] font-mono hover:text-[#0F3D2E] transition-colors"
              >
                View All
              </button>
            </div>

            <div className="space-y-4">
              {recentAnnouncements.map((ann, idx) => (
                <div 
                  key={ann.id} 
                  onClick={() => {
                    onNavigate('announcements');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="group cursor-pointer border border-[#D8D0BC] p-4 bg-white relative overflow-hidden transition-all hover:-translate-y-0.5 hover:shadow-xs"
                >
                  <div className="text-[9px] font-mono text-[#C9A227] mb-1 uppercase tracking-wider flex items-center gap-2">
                    <span>{ann.chapter}</span>
                    <span>•</span>
                    <span className="font-semibold text-[#1C5A43]">{ann.category || 'Notice'}</span>
                  </div>
                  <h4 className="font-serif text-sm font-bold leading-tight mb-2 text-[#1C1C1A] group-hover:text-[#0F3D2E] transition-colors line-clamp-1">
                    {ann.title}
                  </h4>
                  <p className="text-[11px] text-[#4A4A46] font-sans line-clamp-2 mt-1 leading-relaxed">
                    {ann.body}
                  </p>
                  
                  {/* Absolute watermark decor for first item */}
                  {idx === 0 && (
                    <div className="absolute -right-4 -bottom-4 opacity-10 rotate-12 pointer-events-none">
                      <div className="w-16 h-16 border-2 border-[#1C1C1A] rounded-full flex items-center justify-center">
                        <span className="font-serif text-xs font-bold text-[#1C1C1A]">PLA</span>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* 3. PLA Certified Member Designations Directory Block */}
        <ScrollReveal delay={150} className="bg-paper border border-[#D8D0BC] p-6 space-y-6 shadow-3xs">
          <div className="border-b border-[#D8D0BC] pb-3 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
            <div>
              <h3 className="text-sm uppercase tracking-widest font-bold font-sans text-[#1C1C1A] flex items-center gap-2">
                <ShieldCheck size={18} className="text-[#C9A227]" />
                Certified Member & Officer Designations
              </h3>
              <p className="text-[11px] text-[#8A8578] font-sans mt-0.5">
                Official designations and academic society leadership for certified Pakistan Legal Alliance advocates.
              </p>
            </div>
            
            {/* Quick Filter */}
            <div className="relative w-full sm:w-64">
              <input
                type="text"
                placeholder="Search designations or officers..."
                id="designations-search"
                onChange={(e) => {
                  const val = e.target.value.toLowerCase();
                  const cards = document.querySelectorAll('.designation-card');
                  cards.forEach(card => {
                    const text = card.textContent?.toLowerCase() || '';
                    if (text.includes(val)) {
                      (card as HTMLElement).style.display = '';
                    } else {
                      (card as HTMLElement).style.display = 'none';
                    }
                  });
                }}
                className="w-full bg-white border border-[#D8D0BC] px-3 py-1.5 font-sans text-xs focus:outline-none focus:border-gold-custom text-[#1C1C1A]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-h-[350px] overflow-y-auto pr-1">
            {members.map((member) => (
              <div 
                key={member.id} 
                className="designation-card bg-[#FAF7F0] border border-[#D8D0BC]/60 p-4 transition-all hover:border-[#C9A227]/40 hover:bg-[#FAF7F0]/60 flex flex-col justify-between shadow-3xs"
              >
                <div>
                  <div className="flex justify-between items-start">
                    <span className="font-mono text-[8px] text-[#8A8578] uppercase tracking-wider">
                      PLA-{member.id}
                    </span>
                    <span className={`px-1.5 py-0.5 border text-[7px] font-mono uppercase tracking-wider font-bold ${
                      member.status === 'Active' 
                        ? 'bg-emerald-50 text-[#1C5A43] border-emerald-200' 
                        : member.status === 'Suspended'
                        ? 'bg-rose-50 text-[#8B2E2E] border-rose-200'
                        : 'bg-amber-50 text-[#A9841A] border-[#D8D0BC]'
                    }`}>
                      {member.status}
                    </span>
                  </div>
                  <h4 className="font-serif text-sm font-bold text-[#1C1C1A] mt-1.5 leading-tight">
                    {member.name}
                  </h4>
                  <p className="text-xs text-[#0F3D2E] font-sans font-semibold mt-1 leading-normal italic">
                    {member.role || 'Certified Legal Advocate'}
                  </p>
                </div>

                <div className="mt-3 pt-2.5 border-t border-[#D8D0BC]/40 flex justify-between items-center text-[9px] font-mono text-[#8A8578] uppercase">
                  <span>{member.chapter}</span>
                  <span className="text-[8px] bg-white border border-[#D8D0BC]/30 px-1.5 py-0.5">
                    JOINED {member.dateJoined.split('-')[0]}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </ScrollReveal>

      </div>
    </div>
  );
}
