import React, { useState } from 'react';
import { UserState, AdminActionLog } from '../types';
import ScrollReveal from './ScrollReveal';
import { jsPDF } from 'jspdf';
import { 
  History, 
  Search, 
  Filter, 
  Trash2, 
  User, 
  Clock, 
  AlertCircle,
  FileText,
  Users,
  ShieldAlert,
  Info,
  Download
} from 'lucide-react';

interface PageAdminLogsProps {
  userState: UserState;
  actionLogs: AdminActionLog[];
  onClearLogs: () => void;
}

export default function PageAdminLogs({
  userState,
  actionLogs,
  onClearLogs,
}: PageAdminLogsProps) {
  
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('ALL');

  // Filter logs logic
  const filteredLogs = actionLogs.filter(log => {
    const matchesSearch = 
      log.details.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.adminName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.actionType.toLowerCase().includes(searchQuery.toLowerCase());
      
    if (filterType === 'ALL') return matchesSearch;
    if (filterType === 'MEMBERS') {
      return matchesSearch && log.actionType.startsWith('MEMBER');
    }
    if (filterType === 'ANNOUNCEMENTS') {
      return matchesSearch && log.actionType.startsWith('ANNOUNCEMENT');
    }
    return matchesSearch;
  });

  // Export to PDF compliance report generator
  const handleExportPDF = () => {
    const doc = new jsPDF('p', 'mm', 'a4');
    
    // Header overlay for each page
    const drawHeader = (doc: any) => {
      // Emerald Green top header border
      doc.setFillColor(15, 61, 46); 
      doc.rect(0, 0, 210, 8, 'F');
      
      // Thin custom gold line
      doc.setFillColor(201, 162, 39); 
      doc.rect(0, 8, 210, 1.5, 'F');

      // PLA Secretariat Letterhead branding
      doc.setTextColor(15, 61, 46);
      doc.setFont('times', 'bold');
      doc.setFontSize(16);
      doc.text('PAKISTAN LEGAL ALLIANCE', 15, 20);

      doc.setTextColor(169, 132, 26);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.text('CENTRAL BAR ASSOCIATION & REGISTRY SECRETARIAT', 15, 24.5);

      // Ledger Title Block
      doc.setTextColor(28, 28, 26);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(11);
      doc.text('OFFICIAL COMPLIANCE AUDIT LEDGER', 15, 33);

      // Details Subtitle
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(110, 110, 100);
      const activeFilterLabel = filterType === 'ALL' ? 'All System Events' : filterType === 'MEMBERS' ? 'Member Directory Events' : 'Bulletin Board Events';
      doc.text(`Telemetry Scope: ${activeFilterLabel} (${filteredLogs.length} Records)`, 15, 37.5);

      // High-resolution metadata block (Right aligned)
      doc.setTextColor(110, 110, 100);
      doc.setFontSize(8.5);
      doc.setFont('courier', 'normal');
      
      const ptime = new Date().toISOString().replace('T', ' ').substring(0, 19);
      doc.text(`Printed: ${ptime} PKT`, 195, 20, { align: 'right' });
      
      const adminLabel = userState.name || 'Administrative Console';
      doc.text(`Operator: ${adminLabel}`, 195, 24.5, { align: 'right' });

      const serialKey = `PLA-SEC-AUD-${Math.floor(100000 + Math.random() * 900000)}`;
      doc.text(`Ledger ID: ${serialKey}`, 195, 33, { align: 'right' });

      // Clean rule divider
      doc.setDrawColor(216, 208, 188);
      doc.setLineWidth(0.3);
      doc.line(15, 41, 195, 41);
    };

    // Footer overlay for each page
    const drawFooter = (doc: any, pageNum: number, totalPages: number) => {
      // Horizontal separation line
      doc.setDrawColor(216, 208, 188);
      doc.setLineWidth(0.3);
      doc.line(15, 275, 195, 275);

      // Left-aligned secure watermark
      doc.setTextColor(140, 140, 130);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7);
      doc.text('CONFIDENTIAL • SYSTEM AUDIT JOURNAL • SECURITY STANDARDS COMPLIANCE', 15, 281);

      // Right-aligned page indicators
      doc.setFont('courier', 'normal');
      doc.setFontSize(8);
      doc.text(`Page ${pageNum} of ${totalPages}`, 195, 281, { align: 'right' });
    };

    // Table Header draw function
    const drawTableHeader = (doc: any, y: number) => {
      // Elegant warm grey bar
      doc.setFillColor(242, 240, 233);
      doc.rect(15, y, 180, 7, 'F');
      
      doc.setDrawColor(216, 208, 188);
      doc.line(15, y, 195, y);
      doc.line(15, y + 7, 195, y + 7);

      doc.setTextColor(15, 61, 46);
      doc.setFont('courier', 'bold');
      doc.setFontSize(7.5);
      
      doc.text('TIMESTAMP', 17, y + 5);
      doc.text('ADMINISTRATOR', 54, y + 5);
      doc.text('EVENT CATEGORY', 84, y + 5);
      doc.text('AUDIT TELEMETRY DETAILS', 116, y + 5);
      doc.text('SIGNATURE', 182, y + 5);
    };

    let currentY = 46;
    drawTableHeader(doc, currentY);
    currentY += 7;

    filteredLogs.forEach((log, idx) => {
      const detailLines: string[] = doc.splitTextToSize(log.details, 62);
      // Min 10mm height, add extra based on detail lines wrapping
      const rowHeight = Math.max(10, detailLines.length * 4 + 4);

      // Page overflow check
      if (currentY + rowHeight > 265) {
        doc.addPage();
        currentY = 46;
        drawTableHeader(doc, currentY);
        currentY += 7;
      }

      // Zebra striping
      if (idx % 2 === 0) {
        doc.setFillColor(250, 249, 245);
        doc.rect(15, currentY, 180, rowHeight, 'F');
      }

      // Border between rows
      doc.setDrawColor(230, 225, 215);
      doc.setLineWidth(0.15);
      doc.line(15, currentY, 195, currentY);

      // Draw Timestamp Column
      doc.setFont('courier', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(80, 80, 80);
      doc.text(log.timestamp || '', 17, currentY + 5.5);

      // Draw Operator Name
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(15, 61, 46);
      doc.text(log.adminName || 'System', 54, currentY + 5.5);

      // Draw Category Code
      doc.setFont('courier', 'bold');
      doc.setFontSize(7);
      doc.setTextColor(169, 132, 26);
      doc.text(log.actionType || 'EVENT', 84, currentY + 5.5);

      // Draw Wrapped Telemetry details
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(28, 28, 26);
      detailLines.forEach((line, lineIdx) => {
        doc.text(line, 116, currentY + 5.5 + (lineIdx * 3.8));
      });

      // Draw Crypographic Event Signature key
      doc.setFont('courier', 'normal');
      doc.setFontSize(7);
      doc.setTextColor(110, 110, 100);
      const signatureKey = (log.id || 'pla-sig').substring(0, 8).toUpperCase();
      doc.text(signatureKey, 182, currentY + 5.5);

      currentY += rowHeight;
    });

    // Draw final table bottom bar
    doc.setDrawColor(216, 208, 188);
    doc.setLineWidth(0.3);
    doc.line(15, currentY, 195, currentY);

    // Sign-off certification segment
    if (currentY + 35 > 265) {
      doc.addPage();
      currentY = 46;
    }

    currentY += 8;
    doc.setFillColor(250, 249, 245);
    doc.setDrawColor(216, 208, 188);
    doc.rect(15, currentY, 180, 25, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(15, 61, 46);
    doc.text('OFFICIAL REGISTRY COMPLIANCE CERTIFICATION', 20, currentY + 6);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(80, 80, 75);
    doc.text('This ledger certifies that all actions recorded are authentic administrative events parsed directly from secure cryptographic databases.', 20, currentY + 11);
    doc.text('No post-event database manual edits have occurred inside this compliant journal log.', 20, currentY + 15);

    // Official signature placeholder lines
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.text('SIGNATURE / AUDIT STAMP', 20, currentY + 21);

    doc.line(110, currentY + 20, 185, currentY + 20);
    doc.setFont('courier', 'normal');
    doc.setFontSize(6.5);
    doc.text('PLA SECRETARIAT COMPLIANCE SEAL DECREE', 110, currentY + 23.5);

    // Render Headers and Footers on every page retrospectively
    const totalPages = doc.getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      doc.setPage(i);
      drawHeader(doc);
      drawFooter(doc, i, totalPages);
    }

    // Trigger local PDF download
    const currentLocalDateStr = new Date().toISOString().slice(0, 10);
    doc.save(`PLA_Audit_Ledger_${currentLocalDateStr}.pdf`);
  };

  const getLogBadge = (type: AdminActionLog['actionType']) => {
    switch (type) {
      case 'MEMBER_ADD':
        return {
          label: 'Member Added',
          color: 'bg-emerald-50 text-emerald-700 border-emerald-200',
          icon: <Users size={12} className="text-emerald-700" />
        };
      case 'MEMBER_EDIT':
        return {
          label: 'Member Modified',
          color: 'bg-amber-50 text-amber-700 border-amber-200',
          icon: <Users size={12} className="text-amber-700" />
        };
      case 'MEMBER_DELETE':
        return {
          label: 'Member Revoked',
          color: 'bg-rose-50 text-rose-700 border-rose-200',
          icon: <Users size={12} className="text-rose-700" />
        };
      case 'MEMBER_RESET':
        return {
          label: 'Directory Restored',
          color: 'bg-blue-50 text-blue-700 border-blue-200',
          icon: <ShieldAlert size={12} className="text-blue-700" />
        };
      case 'ANNOUNCEMENT_PUBLISH':
        return {
          label: 'Bulletin Published',
          color: 'bg-emerald-50 text-[#1C5A43] border-emerald-200',
          icon: <FileText size={12} className="text-[#1C5A43]" />
        };
      case 'ANNOUNCEMENT_DELETE':
        return {
          label: 'Bulletin Revoked',
          color: 'bg-rose-50 text-[#8B2E2E] border-rose-200',
          icon: <FileText size={12} className="text-[#8B2E2E]" />
        };
      case 'ANNOUNCEMENT_RESET':
        return {
          label: 'Bulletins Restored',
          color: 'bg-[#FAF7F0] text-gold-dark border-[#D8D0BC]',
          icon: <History size={12} className="text-gold-dark" />
        };
      default:
        return {
          label: 'System Event',
          color: 'bg-gray-50 text-gray-700 border-gray-200',
          icon: <Info size={12} className="text-gray-700" />
        };
    }
  };

  return (
    <div className="w-full flex-grow p-4 md:p-8" id="pla-admin-logs-page">
      <div className="max-w-6xl mx-auto space-y-8">
        
        {/* Header Block */}
        <div className="border-b border-border-custom pb-4 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
          <div>
            <span className="font-mono text-[10px] text-gold-dark uppercase tracking-widest block font-bold">
              Secure Ledger Suite
            </span>
            <h2 className="font-serif text-xl font-bold text-emerald-custom uppercase mt-1">
              PLA Central Bar Audit Logs
            </h2>
            <p className="text-xs text-ink-soft font-sans mt-0.5">
              Cryptographically timestamped action logs tracking administrative modifications to the registry database.
            </p>
          </div>
          
          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={handleExportPDF}
              disabled={filteredLogs.length === 0}
              className="flex items-center gap-1.5 px-3 py-1.5 font-mono text-[9px] uppercase tracking-wider bg-emerald-custom text-white border border-emerald-custom hover:bg-emerald-light disabled:opacity-40 transition-colors shadow-2xs shrink-0 cursor-pointer rounded-xs"
            >
              <Download size={10} />
              <span>Export PDF Report</span>
            </button>

            <button
              type="button"
              onClick={onClearLogs}
              className="flex items-center gap-1.5 px-3 py-1.5 font-mono text-[9px] uppercase tracking-wider bg-paper border border-border-custom hover:border-red-200 hover:text-red-700 transition-colors shadow-2xs shrink-0 cursor-pointer rounded-xs"
            >
              <Trash2 size={10} />
              <span>Purge Local Audit Logs</span>
            </button>
          </div>
        </div>

        {/* Audit Search & Filter Sub-Bar */}
        <div className="bg-paper border border-border-custom p-4 flex flex-col md:flex-row gap-4 items-center justify-between shadow-3xs">
          
          {/* Search Box */}
          <div className="relative w-full md:w-80">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-faint" size={14} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by admin name or details..."
              className="w-full bg-white border border-[#D8D0BC] pl-9 pr-4 py-1.5 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
            />
          </div>

          {/* Filter Categories */}
          <div className="flex flex-wrap gap-2 w-full md:w-auto justify-end">
            <button
              onClick={() => setFilterType('ALL')}
              className={`px-3 py-1.5 font-mono text-[9px] uppercase tracking-wider border transition-all cursor-pointer ${
                filterType === 'ALL'
                  ? 'bg-emerald-custom border-emerald-custom text-white font-bold'
                  : 'bg-white border-[#D8D0BC] text-ink-soft hover:border-gold-custom'
              }`}
            >
              All Events
            </button>
            <button
              onClick={() => setFilterType('MEMBERS')}
              className={`px-3 py-1.5 font-mono text-[9px] uppercase tracking-wider border transition-all cursor-pointer ${
                filterType === 'MEMBERS'
                  ? 'bg-emerald-custom border-emerald-custom text-white font-bold'
                  : 'bg-white border-[#D8D0BC] text-ink-soft hover:border-gold-custom'
              }`}
            >
              Member Directory Events
            </button>
            <button
              onClick={() => setFilterType('ANNOUNCEMENTS')}
              className={`px-3 py-1.5 font-mono text-[9px] uppercase tracking-wider border transition-all cursor-pointer ${
                filterType === 'ANNOUNCEMENTS'
                  ? 'bg-emerald-custom border-emerald-custom text-white font-bold'
                  : 'bg-white border-[#D8D0BC] text-ink-soft hover:border-gold-custom'
              }`}
            >
              Bulletin Events
            </button>
          </div>
        </div>

        {/* Chronological Audit Table / Timeline */}
        <div className="bg-paper border border-border-custom shadow-3xs overflow-hidden">
          {filteredLogs.length === 0 ? (
            <div className="text-center p-16 text-ink-soft space-y-2">
              <AlertCircle className="mx-auto text-gold-dark" size={28} />
              <p className="font-serif text-sm font-semibold">No audit matches found</p>
              <p className="text-xs font-sans">Modify your search filter or perform directory/bulletin edits to generate log telemetry.</p>
            </div>
          ) : (
            <div className="divide-y divide-border-custom">
              {filteredLogs.map((log, index) => {
                const badge = getLogBadge(log.actionType);
                return (
                  <ScrollReveal 
                    key={log.id}
                    delay={Math.min(index * 40, 200)}
                    className="p-5 hover:bg-[#FAF7F0]/35 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4"
                  >
                    
                    {/* Log Details */}
                    <div className="space-y-2 flex-grow max-w-4xl">
                      <div className="flex flex-wrap items-center gap-2">
                        {/* Event Category Tag */}
                        <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 border text-[9px] font-mono uppercase tracking-wider rounded-xs ${badge.color}`}>
                          {badge.icon}
                          <span>{badge.label}</span>
                        </span>
                        
                        {/* Unique Log ID Watermark */}
                        <span className="font-mono text-[8px] text-ink-faint uppercase">
                          Sig: {log.id}
                        </span>
                      </div>

                      <p className="font-sans text-xs text-ink leading-relaxed font-medium">
                        {log.details}
                      </p>
                    </div>

                    {/* Metadata & Timestamp Column */}
                    <div className="flex md:flex-col items-start md:items-end justify-between md:justify-center gap-2 shrink-0 border-t md:border-t-0 border-border-custom/50 pt-2.5 md:pt-0">
                      
                      {/* Operator Name */}
                      <span className="flex items-center gap-1.5 text-[10px] font-sans font-bold text-emerald-custom uppercase">
                        <User size={12} className="text-gold-dark" />
                        <span>{log.adminName}</span>
                      </span>

                      {/* Precise Timestamp */}
                      <span className="flex items-center gap-1.5 text-[9px] font-mono text-ink-soft">
                        <Clock size={11} className="text-ink-faint" />
                        <span>{log.timestamp} PKT</span>
                      </span>

                    </div>

                  </ScrollReveal>
                );
              })}
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
