import React from 'react';
import { ActivePage } from '../types';
import ThreeEmblem from './ThreeEmblem';
import ScrollReveal from './ScrollReveal';
import { ChevronRight, FileText, ArrowUpRight } from 'lucide-react';

interface PageHomeProps {
  onNavigate: (page: ActivePage) => void;
}

export default function PageHome({ onNavigate }: PageHomeProps) {
  const stats = [
    { label: 'Registered Members', value: '14,200+' },
    { label: 'District Chapters', value: '27' },
    { label: 'Founded', value: 'April 2026' },
    { label: 'Pro Bono Cases Handled', value: '6,400' },
  ];

  const articles = [
    {
      num: 'Art. 01',
      title: 'Professional Standards',
      desc: 'Developing and enforcing the mandatory code of advocacy ethics, disciplinary procedures, and continuing legal professional accreditation guidelines.',
    },
    {
      num: 'Art. 02',
      title: 'Access to Justice',
      desc: 'Funding and managing nationwide pro bono networks, legal aid clinics in remote regions, and promoting representation rights for disenfranchised citizens.',
    },
    {
      num: 'Art. 03',
      title: 'Policy & Advocacy',
      desc: 'Formulating independent legislative advisory reviews, constitutional amicus briefs, and acting as a non-partisan voice for judicial independence.',
    },
    {
      num: 'Art. 04',
      title: 'Research & Publications',
      desc: 'Publishing peer-reviewed legal journals, the official PLA Gazette, and compiling technical law reviews to assist judicial research.',
    },
  ];

  return (
    <div className="w-full" id="pla-page-home">
      {/* 1. Dark Emerald Hero Section */}
      <section className="w-full bg-gradient-to-b from-emerald-custom to-[#0a271e] text-paper relative overflow-hidden py-16 md:py-24 border-b border-gold-custom/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            
            {/* Left Column: Hero Copy */}
            <div className="flex flex-col space-y-6">
              <span className="font-mono text-xs text-gold-custom uppercase tracking-widest inline-block border-l-2 border-gold-custom pl-3">
                National Bar & Legal Society
              </span>
              <h1 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white leading-[1.15]">
                Advancing the rule of law, <br />
                <span className="text-gold-light">one advocate at a time.</span>
              </h1>
              <p className="text-sm md:text-base text-paper-dim/80 font-sans leading-relaxed max-w-xl">
                Uniting advocates, jurists, and legal scholars across Pakistan. We uphold professional integrity, safeguard judicial autonomy, and champion procedural access to justice for all citizens.
              </p>
              <div className="flex flex-wrap gap-4 pt-4">
                <button
                  onClick={() => {
                    onNavigate('about');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="bg-gold-custom text-[#07241B] hover:bg-gold-light px-6 py-3 font-mono text-xs uppercase tracking-widest font-semibold transition-all cursor-pointer border border-gold-custom"
                >
                  About the Alliance
                </button>
                <button
                  onClick={() => {
                    onNavigate('recruitment');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="bg-transparent text-paper hover:text-white border border-paper/40 hover:border-gold-custom px-6 py-3 font-mono text-xs uppercase tracking-widest transition-all cursor-pointer"
                >
                  Careers at PLA
                </button>
              </div>
            </div>

            {/* Right Column: Three.js Rotating 3D Emblem Container */}
            <div className="flex justify-center lg:justify-end items-center relative min-h-[300px] sm:min-h-[350px]">
              {/* Outer fade effect layer */}
              <div className="absolute inset-0 bg-radial from-transparent to-emerald-custom/40 pointer-events-none z-10" />
              <ThreeEmblem />
            </div>

          </div>
        </div>
      </section>

      {/* 2. Stat Strip Section */}
      <section className="w-full bg-[#FAF7F0] border-b border-border-custom py-6 px-4 sm:px-6 md:px-8 relative z-20">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center md:text-left divide-y md:divide-y-0 md:divide-x divide-border-custom/50">
            {stats.map((stat, idx) => (
              <div key={idx} className={`pt-4 md:pt-0 ${idx > 0 ? 'md:pl-6' : ''}`}>
                <span className="block font-serif text-2xl md:text-3xl font-bold text-emerald-custom">
                  {stat.value}
                </span>
                <span className="block font-mono text-[10px] uppercase tracking-wider text-ink-soft mt-1">
                  {stat.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. Areas of the Alliance Section */}
      <section className="w-full bg-paper py-16 md:py-24 border-b border-border-custom px-4 sm:px-6 md:px-8 relative z-20">
        <div className="max-w-7xl mx-auto">
          <div className="mb-12">
            <span className="font-mono text-xs text-gold-dark uppercase tracking-widest block mb-2">
              Statutory Framework
            </span>
            <h2 className="font-serif text-2xl md:text-3xl font-bold text-emerald-custom tracking-tight">
              Practices & Areas of the Alliance
            </h2>
            <div className="w-16 h-1 bg-gold-custom mt-3" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-border-custom">
            {articles.map((art, idx) => (
              <ScrollReveal key={idx} delay={idx * 100} className="bg-paper p-8 flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-center mb-6">
                    <span className="font-mono text-xs text-gold-dark font-medium border border-gold-custom/50 px-2 py-0.5 tracking-wider bg-gold-light/5">
                      {art.num}
                    </span>
                    <span className="text-[10px] font-mono tracking-widest text-ink-faint uppercase">
                      PLA-SEC
                    </span>
                  </div>
                  <h3 className="font-serif text-lg font-bold text-ink mb-3 tracking-tight">
                    {art.title}
                  </h3>
                  <p className="text-xs text-ink-soft font-sans leading-relaxed">
                    {art.desc}
                  </p>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* 4. "From the Gazette" Section */}
      <section className="w-full bg-paper-dim/30 py-16 md:py-24 border-b border-border-custom px-4 sm:px-6 md:px-8 relative z-20">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            
            {/* Split Intro Left Card */}
            <div className="lg:col-span-1 flex flex-col justify-between">
              <div>
                <span className="font-mono text-xs text-gold-dark uppercase tracking-widest block mb-2">
                  Legal Annals
                </span>
                <h2 className="font-serif text-2xl md:text-3xl font-bold text-emerald-custom tracking-tight leading-tight">
                  From the Gazette & Bulletins
                </h2>
                <p className="text-xs text-ink-soft font-sans leading-relaxed mt-4">
                  Review our legal treatises, official bar briefs, regulatory advisories, and administrative circulars published regularly by the Secretariat's research boards.
                </p>
              </div>
              <div className="mt-8">
                <button
                  onClick={() => {
                    onNavigate('news-gazette');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="inline-flex items-center space-x-2 font-mono text-xs text-gold-dark uppercase tracking-widest hover:text-emerald-custom transition-colors cursor-pointer group"
                >
                  <span>View All Postings</span>
                  <ChevronRight size={14} className="transform group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>

            {/* Split Gazette News Items Right */}
            <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* News Card 1 */}
              <ScrollReveal delay={100} className="bg-paper border border-border-custom p-6 flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <span className="bg-emerald-custom/5 text-emerald-custom border border-emerald-custom/20 font-mono text-[9px] uppercase tracking-wider px-2 py-0.5">
                      Notice
                    </span>
                    <span className="text-[10px] font-mono text-ink-faint">
                      2026-07-15
                    </span>
                  </div>
                  <h3 className="font-serif text-base font-bold text-ink mb-2 line-clamp-2 hover:text-emerald-custom transition-colors">
                    Annual General Meeting 2026: Official Call to Order
                  </h3>
                  <p className="text-xs text-ink-soft line-clamp-3 leading-relaxed font-sans mb-4">
                    Official notice of the Annual General Meeting of the Pakistan Legal Alliance, scheduled for September 12, 2026, in Lahore, Punjab.
                  </p>
                </div>
                <button
                  onClick={() => {
                    onNavigate('news-gazette');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="font-mono text-[10px] uppercase tracking-widest text-gold-dark hover:text-emerald-custom flex items-center mt-2 cursor-pointer"
                >
                  <FileText size={12} className="mr-1" /> Read Full Agenda
                </button>
              </ScrollReveal>

              {/* News Card 2 */}
              <ScrollReveal delay={200} className="bg-paper border border-border-custom p-6 flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <span className="bg-gold-custom/5 text-gold-dark border border-gold-custom/20 font-mono text-[9px] uppercase tracking-wider px-2 py-0.5">
                      Publication
                    </span>
                    <span className="text-[10px] font-mono text-ink-faint">
                      2026-07-01
                    </span>
                  </div>
                  <h3 className="font-serif text-base font-bold text-ink mb-2 line-clamp-2 hover:text-emerald-custom transition-colors">
                    PLA Law Review Publication (Vol. 28, Issue 1)
                  </h3>
                  <p className="text-xs text-ink-soft line-clamp-3 leading-relaxed font-sans mb-4">
                    Featuring peer-reviewed treatises on the evolving constitutional frameworks of provincial autonomy and legislative delegation in South Asia.
                  </p>
                </div>
                <button
                  onClick={() => {
                    onNavigate('news-gazette');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="font-mono text-[10px] uppercase tracking-widest text-gold-dark hover:text-emerald-custom flex items-center mt-2 cursor-pointer"
                >
                  <FileText size={12} className="mr-1" /> View Treatise PDF
                </button>
              </ScrollReveal>

            </div>
          </div>
        </div>
      </section>

      {/* 5. Dark CTA Band */}
      <section className="w-full bg-emerald-custom text-paper py-16 border-b border-gold-custom/20 px-4 sm:px-6 md:px-8 relative z-20">
        <div className="max-w-4xl mx-auto text-center flex flex-col items-center space-y-6">
          <div className="w-12 h-[1px] bg-gold-custom" />
          <h2 className="font-serif text-2xl md:text-3xl font-bold tracking-tight text-white">
            Join the Pakistan Legal Alliance
          </h2>
          <p className="text-xs md:text-sm text-paper-dim/85 leading-relaxed max-w-2xl font-sans">
            Accredit your credentials, gain regional bar counsel affiliation, participate in state policy drafts, and join a network of over 14,000 professional advocates nationwide.
          </p>
          <button
            onClick={() => {
              onNavigate('login');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="mt-4 bg-gold-custom text-[#07241B] hover:bg-gold-light px-8 py-3.5 font-mono text-xs uppercase tracking-widest font-bold transition-all cursor-pointer border border-gold-custom flex items-center space-x-2"
          >
            <span>Apply for Membership</span>
            <ArrowUpRight size={14} />
          </button>
        </div>
      </section>
    </div>
  );
}
