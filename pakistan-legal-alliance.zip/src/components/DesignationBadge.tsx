import React from 'react';
import { Award, Briefcase, User } from 'lucide-react';

interface DesignationBadgeProps {
  designation?: 'Senior Advocate' | 'Junior Advocate' | 'Counsel' | string;
  size?: 'sm' | 'md' | 'lg';
}

export function DesignationBadge({ designation, size = 'sm' }: DesignationBadgeProps) {
  const norm = designation?.trim();
  if (!norm) return null;

  let styles = 'border-slate-300 text-slate-700 bg-slate-50/50';
  let Icon = User;

  if (norm === 'Senior Advocate') {
    styles = 'border-[#C9A227] text-[#A9841A] bg-amber-50/50';
    Icon = Award;
  } else if (norm === 'Junior Advocate') {
    styles = 'border-[#1C5A43] text-[#1C5A43] bg-emerald-50/50';
    Icon = Briefcase;
  } else if (norm === 'Counsel') {
    styles = 'border-stone-400 text-stone-700 bg-stone-50/50';
    Icon = User;
  }

  const paddingClass = 
    size === 'sm' 
      ? 'px-1.5 py-0.5 text-[9px]' 
      : size === 'md'
      ? 'px-2 py-0.5 text-[10px]'
      : 'px-2.5 py-1 text-xs';
      
  const iconSize = size === 'sm' ? 10 : size === 'md' ? 11 : 13;

  return (
    <span 
      className={`inline-flex items-center gap-1.5 border font-mono uppercase tracking-wider font-bold rounded-xs transition-colors ${paddingClass} ${styles}`}
      title={`Designation: ${norm}`}
    >
      <Icon size={iconSize} className="shrink-0" />
      <span>{norm}</span>
    </span>
  );
}
