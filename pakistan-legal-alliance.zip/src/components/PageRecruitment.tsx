import React, { useState, useRef } from 'react';
import ScrollReveal from './ScrollReveal';
import { JOB_POSTINGS } from '../data';
import { JobPosting } from '../types';
import { Landmark, Briefcase, FileUp, CheckCircle, ArrowDown, MapPin, ClipboardList } from 'lucide-react';

export default function PageRecruitment() {
  const formRef = useRef<HTMLDivElement>(null);
  
  // State for application form
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    position: '',
    enrolmentNumber: '',
    coverNote: '',
  });
  const [cvFileName, setCvFileName] = useState('');
  const [faxNumber, setFaxNumber] = useState(''); // honeypot
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleApplyClick = (jobTitle: string) => {
    setFormData((prev) => ({ ...prev, position: jobTitle }));
    if (formRef.current) {
      formRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setCvFileName(e.target.files[0].name);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);
    
    try {
      const response = await fetch('/api/submitRecruitment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-firebase-appcheck': 'sandbox_test_token'
        },
        body: JSON.stringify({
          fullName: formData.fullName,
          email: formData.email,
          position: formData.position,
          enrolmentNumber: formData.enrolmentNumber,
          coverNote: formData.coverNote,
          cvFileName: cvFileName || 'Uploaded Dossier.pdf',
          faxNumber: faxNumber
        })
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to submit application dossier.');
      }
      setIsSubmitted(true);
    } catch (err: any) {
      console.error('Error submitting application:', err);
      setError(err.message || 'Failed to submit application dossier. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setFormData({
      fullName: '',
      email: '',
      position: '',
      enrolmentNumber: '',
      coverNote: '',
    });
    setCvFileName('');
    setFaxNumber('');
    setIsSubmitted(false);
    setError(null);
  };

  return (
    <div className="w-full" id="pla-page-recruitment">
      {/* 1. Hero Section on Dark Emerald */}
      <section className="w-full bg-gradient-to-b from-emerald-custom to-[#0a271e] text-paper relative py-16 md:py-20 border-b border-gold-custom/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 relative z-10 text-center md:text-left">
          <span className="font-mono text-xs text-gold-custom uppercase tracking-widest inline-block border-l-2 border-gold-custom pl-3 mb-4">
            Institutional Growth & Careers
          </span>
          <h1 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white leading-tight">
            Build the institutions <br />
            <span className="text-gold-light">that build justice.</span>
          </h1>
          <p className="text-xs md:text-sm text-paper-dim/80 max-w-xl font-sans mt-4 leading-relaxed">
            The Pakistan Legal Alliance recruits scholars, practitioners, and organizers to lead regional committees, coordinate legal clinics, and direct continuing education.
          </p>
        </div>
      </section>

      {/* 2. Job Openings Feed */}
      <section className="w-full bg-paper py-16 md:py-24 border-b border-border-custom px-4 sm:px-6 md:px-8 relative z-20">
        <div className="max-w-4xl mx-auto">
          <div className="mb-12">
            <span className="font-mono text-xs text-gold-dark uppercase tracking-widest block mb-2">
              Chapter III: Vacancies
            </span>
            <h2 className="font-serif text-2xl md:text-3xl font-bold text-emerald-custom tracking-tight">
              Open Institutional Appointments
            </h2>
            <div className="w-12 h-0.5 bg-gold-custom mt-3" />
          </div>

          <div className="space-y-6">
            {JOB_POSTINGS.map((job) => (
              <ScrollReveal 
                key={job.id} 
                className="bg-[#FAF7F0] border border-border-custom p-6 md:p-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-6"
              >
                <div>
                  <div className="flex flex-wrap items-center gap-2 mb-3">
                    <span className="font-mono text-[9px] text-ink-faint tracking-wider mr-2 uppercase">
                      REF: {job.refNumber}
                    </span>
                    <span className={`font-mono text-[9px] uppercase tracking-wider px-2 py-0.5 border ${
                      job.status === 'Open'
                        ? 'bg-emerald-custom/5 text-emerald-custom border-emerald-custom/20'
                        : 'bg-red-700/5 text-red-900 border-red-700/20'
                    }`}>
                      {job.status}
                    </span>
                    <span className="bg-paper border border-border-custom font-mono text-[9px] text-ink-soft uppercase px-2 py-0.5">
                      {job.employmentType}
                    </span>
                  </div>

                  <h3 className="font-serif text-lg font-bold text-ink mb-2">
                    {job.title}
                  </h3>

                  <div className="flex items-center text-xs text-ink-soft font-sans">
                    <MapPin size={12} className="text-gold-dark mr-1" />
                    <span>{job.location}</span>
                  </div>
                </div>

                <button
                  onClick={() => handleApplyClick(job.title)}
                  className="w-full md:w-auto bg-emerald-custom text-paper hover:bg-emerald-light px-5 py-2.5 font-mono text-xs uppercase tracking-wider transition-all cursor-pointer border border-gold-custom text-center"
                >
                  Apply For Role
                </button>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* 3. Recruitment Application Form */}
      <section ref={formRef} className="w-full bg-paper-dim/40 py-16 md:py-24 border-b border-border-custom px-4 sm:px-6 md:px-8 relative z-20">
        <div className="max-w-xl mx-auto">
          {isSubmitted ? (
            <ScrollReveal className="bg-paper border border-gold-custom p-8 text-center flex flex-col items-center space-y-4">
              <CheckCircle size={48} className="text-emerald-custom animate-bounce" />
              <h3 className="font-serif text-xl font-bold text-emerald-custom">
                Application Received Successfully
              </h3>
              <p className="text-xs text-ink-soft font-sans leading-relaxed">
                Thank you for applying to the Pakistan Legal Alliance. Your credentials and file reference have been registered inside our Central Registry. A representative from the Secretariat's Human Resources board will contact you following a formal audit.
              </p>
              <div className="font-mono text-[10px] text-gold-dark uppercase tracking-widest bg-[#FAF7F0] border border-border-custom p-3 w-full">
                Submission Reference: PLA-APP-{Math.floor(100000 + Math.random() * 900000)}
              </div>
              <button
                onClick={resetForm}
                className="mt-4 text-xs font-mono uppercase tracking-wider text-emerald-custom hover:text-gold-custom transition-colors cursor-pointer"
              >
                Apply for another position
              </button>
            </ScrollReveal>
          ) : (
            <div className="bg-paper border border-border-custom p-8">
              <div className="flex items-center space-x-3 mb-6">
                <ClipboardList className="text-gold-dark shrink-0" size={20} />
                <h3 className="font-serif text-lg font-bold text-emerald-custom tracking-tight">
                  Secretariat Application Form
                </h3>
              </div>

              <form onSubmit={handleSubmit} className="space-y-5">
                {/* Honeypot field for anti-spam protection */}
                <div style={{ display: 'none' }} aria-hidden="true">
                  <input
                    type="text"
                    name="faxNumber"
                    value={faxNumber}
                    onChange={(e) => setFaxNumber(e.target.value)}
                    tabIndex={-1}
                    autoComplete="off"
                    placeholder="Do not fill this field"
                  />
                </div>

                {/* Full Name */}
                <div>
                  <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1.5 font-semibold">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.fullName}
                    onChange={(e) => setFormData((prev) => ({ ...prev, fullName: e.target.value }))}
                    className="w-full bg-paper border border-border-custom px-3 py-2 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
                    placeholder="e.g. Barrister Kamran Shah"
                  />
                </div>

                {/* Email */}
                <div>
                  <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1.5 font-semibold">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
                    className="w-full bg-paper border border-border-custom px-3 py-2 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
                    placeholder="name@organization.org"
                  />
                </div>

                {/* Dropdown for role selection */}
                <div>
                  <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1.5 font-semibold">
                    Desired Appointment *
                  </label>
                  <select
                    required
                    value={formData.position}
                    onChange={(e) => setFormData((prev) => ({ ...prev, position: e.target.value }))}
                    className="w-full bg-paper border border-border-custom px-3 py-2 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
                  >
                    <option value="" disabled>Select from open vacancies</option>
                    {JOB_POSTINGS.map((job) => (
                      <option key={job.id} value={job.title}>
                        {job.title} ({job.location})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Bar Enrolment Number */}
                <div>
                  <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1.5 font-semibold">
                    Bar Council Enrolment Number (Optional)
                  </label>
                  <input
                    type="text"
                    value={formData.enrolmentNumber}
                    onChange={(e) => setFormData((prev) => ({ ...prev, enrolmentNumber: e.target.value }))}
                    className="w-full bg-paper border border-border-custom px-3 py-2 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
                    placeholder="e.g. PBC-90421-ADV"
                  />
                </div>

                {/* Cover Note */}
                <div>
                  <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1.5 font-semibold">
                    Cover Note / Brief Statement of Purpose *
                  </label>
                  <textarea
                    required
                    rows={4}
                    value={formData.coverNote}
                    onChange={(e) => setFormData((prev) => ({ ...prev, coverNote: e.target.value }))}
                    className="w-full bg-paper border border-border-custom p-3 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
                    placeholder="Outline your research expertise, litigation experience, and motivation for joining the Secretariat..."
                  />
                </div>

                {/* CV File Upload */}
                <div>
                  <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1.5 font-semibold">
                    Upload CV / Dossier (PDF only) *
                  </label>
                  <div className="border border-dashed border-border-custom hover:border-gold-custom transition-all bg-paper/50 p-4 text-center relative cursor-pointer group">
                    <input
                      type="file"
                      required={!cvFileName}
                      accept=".pdf"
                      onChange={handleFileChange}
                      className="absolute inset-0 opacity-0 w-full h-full cursor-pointer z-10"
                    />
                    <div className="flex flex-col items-center justify-center space-y-2 pointer-events-none">
                      <FileUp size={24} className="text-gold-dark group-hover:scale-110 transition-transform" />
                      <span className="text-xs text-ink font-sans">
                        {cvFileName ? cvFileName : 'Drag and drop or click to select PDF'}
                      </span>
                      <span className="text-[9px] font-mono text-ink-faint">
                        MAXIMUM SIZE: 10MB · SINGLE DOCUMENT ONLY
                      </span>
                    </div>
                  </div>
                </div>

                {/* Error Notice */}
                {error && (
                  <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs font-sans rounded-xs">
                    {error}
                  </div>
                )}

                {/* Submit button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-emerald-custom text-paper hover:bg-emerald-light disabled:opacity-50 px-6 py-3 font-mono text-xs uppercase tracking-widest font-bold transition-all cursor-pointer border border-gold-custom"
                >
                  {isSubmitting ? 'Registering Application...' : 'Submit Credentials'}
                </button>

                <p className="text-[10px] font-mono text-ink-faint text-center">
                  * Notice: Your application dossier is securely processed and logged in the Central Secretariat's database.
                </p>
              </form>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
