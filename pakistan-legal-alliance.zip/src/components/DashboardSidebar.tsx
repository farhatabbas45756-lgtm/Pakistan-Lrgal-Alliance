import React from 'react';
import { ActivePage, UserState } from '../types';
import PLASeal from './PLASeal';
import { 
  LayoutDashboard, 
  Bell, 
  Users, 
  Briefcase, 
  BookOpen, 
  Settings, 
  LogOut, 
  FileSpreadsheet, 
  History,
  UserPlus,
  X 
} from 'lucide-react';

interface DashboardSidebarProps {
  activePage: ActivePage;
  onNavigate: (page: ActivePage) => void;
  userState: UserState;
  onSignOut: () => void;
  isOpen: boolean;
  onClose: () => void;
}

export default function DashboardSidebar({
  activePage,
  onNavigate,
  userState,
  onSignOut,
  isOpen,
  onClose,
}: DashboardSidebarProps) {
  
  const handleLinkClick = (page: ActivePage) => {
    onNavigate(page);
    onClose(); // close mobile drawer
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const menuGroups = [
    {
      title: 'Overview',
      items: [
        { 
          label: 'Dashboard', 
          icon: <LayoutDashboard size={16} />, 
          page: 'dashboard' as ActivePage,
          badge: null 
        },
        { 
          label: 'Announcements', 
          icon: <Bell size={16} />, 
          page: 'announcements' as ActivePage,
          badge: '5' // 5 sample announcements
        },
      ],
    },
    ...((userState.isAdmin || (userState.email && [
      'thread.fia@gmail.com',
      'n.saad.khan@barcounsel.pk',
      'r.rehmet@barcounsel.pk',
      'c.numan.ali@barcounsel.pk'
    ].includes(userState.email.toLowerCase()))) ? [
      {
        title: 'Administrative Tools',
        items: [
          { 
            label: 'Provision New Member', 
            icon: <UserPlus size={16} className="text-[#C9A227]" />, 
            page: 'admin' as ActivePage,
          },
          { 
            label: 'Manage Member Database', 
            icon: <Users size={16} className="text-[#C9A227]" />, 
            page: 'directory' as ActivePage,
          },
          { 
            label: 'Announcements Management', 
            icon: <Bell size={16} className="text-[#C9A227]" />, 
            page: 'announcements-publishing' as ActivePage,
          },
          { 
            label: 'System Audit Logs', 
            icon: <History size={16} className="text-[#C9A227]" />, 
            page: 'admin-logs' as ActivePage,
          },
        ],
      }
    ] : []),
    {
      title: 'Directory & Services',
      items: [
        { 
          label: 'Member Directory', 
          icon: <Users size={16} />, 
          page: 'directory' as ActivePage,
        },
        { 
          label: 'Case Referrals', 
          icon: <FileSpreadsheet size={16} />, 
          onClick: () => alert('Referrals Console is locked to active assignments. Submit new disputes via standard Secretariat Intake.'),
        },
        { 
          label: 'Recruitment board', 
          icon: <Briefcase size={16} />, 
          page: 'recruitment' as ActivePage,
        },
        { 
          label: 'PLA Law Gazette', 
          icon: <BookOpen size={16} />, 
          page: 'news-gazette' as ActivePage,
        },
      ],
    },
    {
      title: 'Account Control',
      items: [
        { 
          label: 'Settings', 
          icon: <Settings size={16} />, 
          onClick: () => alert('Profile and credentials management is locked. Submit change requests to: registrar@pakistanlegalalliance.org'),
        },
      ],
    },
  ];

  const sidebarContent = (
    <div className="h-full flex flex-col justify-between bg-[#0F3D2E] text-[#FAF7F0] border-r border-[#D8D0BC]/20">
      
      <div className="flex-1 flex flex-col overflow-y-auto">
        {/* Header with Sophisticated Dark Seal structure and close button for mobile */}
        <div className="p-6 flex items-center justify-between border-b border-[#D8D0BC]/10">
          <button 
            onClick={() => handleLinkClick('home')} 
            className="flex items-center gap-3 text-left group cursor-pointer"
          >
            <div className="w-12 h-12 rounded-full border border-[#C9A227] flex items-center justify-center shrink-0">
              <div className="w-10 h-10 rounded-full border border-[#C9A227]/40 flex items-center justify-center text-[#C9A227] font-serif text-base font-bold">
                PLA
              </div>
            </div>
            <div>
              <h1 className="text-[#FAF7F0] text-xs font-serif font-bold tracking-wide leading-tight group-hover:text-[#C9A227] transition-colors uppercase">
                Pakistan Legal
              </h1>
              <h1 className="text-[#C9A227] text-[10px] font-serif tracking-wider leading-none uppercase mt-0.5">
                Alliance
              </h1>
            </div>
          </button>
          
          <button 
            onClick={onClose} 
            className="md:hidden p-1.5 text-[#FAF7F0]/70 hover:text-[#C9A227] transition-colors cursor-pointer"
            aria-label="Close sidebar"
          >
            <X size={18} />
          </button>
        </div>

        {/* Grouped Links */}
        <nav className="flex-1 p-4 space-y-6 mt-4">
          {menuGroups.map((group, groupIdx) => (
            <section key={groupIdx}>
              <p className="text-[10px] text-[#D8D0BC]/50 uppercase tracking-widest mb-3 px-3 font-mono">
                {group.title}
              </p>
              <div className="space-y-1">
                {group.items.map((item, itemIdx) => {
                  const isLinkActive = item.page && activePage === item.page;
                  
                  const handleClick = () => {
                    if (item.page) {
                      handleLinkClick(item.page);
                    } else if (item.onClick) {
                      item.onClick();
                    }
                  };

                  return (
                    <button
                      key={itemIdx}
                      onClick={handleClick}
                      className={`w-full flex items-center justify-between px-3 py-2 text-xs font-sans transition-colors rounded-sm cursor-pointer ${
                        isLinkActive
                          ? 'bg-[#FAF7F0]/10 text-[#C9A227] font-medium'
                          : 'text-[#FAF7F0]/70 hover:text-white hover:bg-[#FAF7F0]/5'
                      }`}
                    >
                      <div className="flex items-center space-x-2.5">
                        <span className={isLinkActive ? 'text-[#C9A227]' : 'text-[#FAF7F0]/50'}>
                          {item.icon}
                        </span>
                        <span>{item.label}</span>
                      </div>
                      
                      {item.badge && (
                        <span className="bg-[#C9A227] text-[#0F3D2E] text-[9px] font-bold px-1.5 py-0.5">
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </section>
          ))}
        </nav>
      </div>

      {/* Footer Profile Box & Sign Out */}
      <div className="border-t border-[#D8D0BC]/10 bg-[#0A2B20]">
        <div className="p-4 flex items-center justify-between gap-3 border-b border-[#D8D0BC]/5">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-8 h-8 bg-[#C9A227]/20 border border-[#C9A227] rounded-sm flex items-center justify-center text-[#C9A227] font-serif text-xs font-bold shrink-0">
              {userState.name ? userState.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase() : 'JD'}
            </div>
            <div className="min-w-0">
              <p className="text-[#FAF7F0] text-xs font-medium truncate">{userState.name || 'John Doe'}</p>
              <p className="text-[#D8D0BC]/50 text-[9px] font-mono truncate">{userState.memberId || 'ID: PLA-999'}</p>
            </div>
          </div>
        </div>
        <div className="p-3">
          <button
            onClick={onSignOut}
            className="w-full bg-[#FAF7F0]/5 hover:bg-red-950/40 text-[#D8D0BC]/70 hover:text-red-400 py-1.5 font-mono text-[9px] uppercase tracking-widest transition-all cursor-pointer flex items-center justify-center space-x-1.5 border border-[#D8D0BC]/10 hover:border-red-500/20"
          >
            <LogOut size={10} />
            <span>Sign Out Workspace</span>
          </button>
        </div>
      </div>

    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar (>= md) */}
      <aside className="hidden md:block w-64 h-screen fixed top-0 left-0 z-30" id="pla-desktop-sidebar">
        {sidebarContent}
      </aside>

      {/* Mobile Sliding Drawer (< md) */}
      {isOpen && (
        <div className="md:hidden fixed inset-0 z-50 flex" id="pla-mobile-sidebar-drawer">
          {/* Dim overlay backdrop */}
          <div 
            className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity duration-300"
            onClick={onClose}
          />
          
          {/* Drawer content panel */}
          <div className="relative w-64 max-w-xs h-full z-10 animate-slide-in-left">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
}
