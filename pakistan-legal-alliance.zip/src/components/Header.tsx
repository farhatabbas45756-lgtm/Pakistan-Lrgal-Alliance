import React, { useState } from 'react';
import { ActivePage, UserState } from '../types';
import PLASeal from './PLASeal';
import { Menu, X, Landmark, User, LayoutDashboard, LogOut } from 'lucide-react';

interface HeaderProps {
  activePage: ActivePage;
  onNavigate: (page: ActivePage) => void;
  userState: UserState;
  onSignOut: () => void;
}

export default function Header({ activePage, onNavigate, userState, onSignOut }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: { label: string; page: ActivePage }[] = [
    { label: 'Home', page: 'home' },
    { label: 'About', page: 'about' },
    { label: 'Practice Areas', page: 'practice-areas' },
    { label: 'Gazette', page: 'news-gazette' },
    { label: 'Careers', page: 'recruitment' },
    { label: 'Contact', page: 'contact' },
  ];

  const handleLinkClick = (page: ActivePage) => {
    onNavigate(page);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="w-full relative z-40 bg-paper" id="pla-public-header">
      {/* 1. Thin Dark Utility Bar Above Main Header */}
      <div className="w-full bg-[#07241B] text-paper/90 border-b border-emerald-light/30 py-2 px-4 sm:px-6 md:px-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center text-[11px] font-mono tracking-wider">
          <div className="flex items-center space-x-2 text-gold-light/90">
            <Landmark size={12} className="text-gold-custom shrink-0" />
            <span>PLA SECRETARIAT: ISLAMABAD · KARACHI · LAHORE · PESHAWAR · QUETTA</span>
          </div>
          <div className="flex items-center space-x-4 mt-1 sm:mt-0">
            <button 
              onClick={() => handleLinkClick('recruitment')} 
              className="hover:text-gold-custom transition-colors cursor-pointer uppercase"
            >
              Careers
            </button>
            <span className="text-emerald-light">|</span>
            {userState.isAuthenticated ? (
              <div className="flex items-center space-x-3">
                <button 
                  onClick={() => handleLinkClick('dashboard')} 
                  className="hover:text-gold-custom transition-colors cursor-pointer flex items-center space-x-1 uppercase text-gold-custom"
                >
                  <LayoutDashboard size={11} />
                  <span>Dashboard ({userState.name})</span>
                </button>
                <span className="text-emerald-light">|</span>
                <button 
                  onClick={onSignOut} 
                  className="hover:text-red-400 transition-colors cursor-pointer flex items-center space-x-1 uppercase"
                >
                  <LogOut size={11} />
                  <span>Sign Out</span>
                </button>
              </div>
            ) : (
              <button 
                onClick={() => handleLinkClick('login')} 
                className="hover:text-gold-custom transition-colors cursor-pointer flex items-center space-x-1 uppercase text-gold-light"
              >
                <User size={11} />
                <span>Member Login</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 2. Main Header */}
      <div className="w-full border-b border-border-custom bg-paper py-4 px-4 sm:px-6 md:px-8">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          {/* Logo Brand Group */}
          <button 
            onClick={() => handleLinkClick('home')} 
            className="flex items-center space-x-3 text-left group cursor-pointer"
            id="pla-header-logo-button"
          >
            <PLASeal size="md" />
            <div>
              <span className="block font-serif text-lg sm:text-xl font-bold text-emerald-custom tracking-tight leading-tight group-hover:text-emerald-light transition-colors">
                PAKISTAN LEGAL ALLIANCE
              </span>
              <span className="block text-[10px] sm:text-[11px] font-mono tracking-widest text-ink-soft uppercase">
                National Bar Association & Law Society
              </span>
            </div>
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-7">
            {navItems.map((item) => {
              const isActive = activePage === item.page;
              return (
                <button
                  key={item.page}
                  onClick={() => handleLinkClick(item.page)}
                  className={`font-mono text-xs uppercase tracking-widest transition-colors py-1 relative cursor-pointer ${
                    isActive 
                      ? 'text-emerald-custom font-semibold' 
                      : 'text-ink-soft hover:text-emerald-custom'
                  }`}
                >
                  {item.label}
                  {isActive && (
                    <span className="absolute -bottom-1 left-0 right-0 h-[2px] bg-gold-custom" />
                  )}
                </button>
              );
            })}
            
            {userState.isAuthenticated ? (
              <button
                onClick={() => handleLinkClick('dashboard')}
                className="bg-emerald-custom text-paper border border-gold-custom px-4 py-2 font-mono text-xs uppercase tracking-wider hover:bg-emerald-light hover:text-white transition-all cursor-pointer"
              >
                Member Portal
              </button>
            ) : (
              <button
                onClick={() => handleLinkClick('login')}
                className="bg-transparent text-emerald-custom border border-emerald-custom px-4 py-2 font-mono text-xs uppercase tracking-wider hover:bg-emerald-custom hover:text-paper transition-all cursor-pointer"
              >
                Join PLA / Login
              </button>
            )}
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-emerald-custom hover:text-gold-custom transition-colors cursor-pointer"
            aria-label="Toggle Navigation Menu"
            id="pla-mobile-nav-toggle"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* 3. Mobile Navigation Overlay */}
      {mobileMenuOpen && (
        <div className="lg:hidden absolute top-full left-0 right-0 bg-paper border-b border-border-custom shadow-xl py-6 px-6 z-50 animate-fade-in-down" id="pla-mobile-menu">
          <div className="flex flex-col space-y-4">
            {navItems.map((item) => {
              const isActive = activePage === item.page;
              return (
                <button
                  key={item.page}
                  onClick={() => handleLinkClick(item.page)}
                  className={`font-mono text-xs uppercase tracking-widest text-left py-2 border-b border-border-custom/30 ${
                    isActive 
                      ? 'text-emerald-custom font-bold' 
                      : 'text-ink-soft hover:text-emerald-custom'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
            {userState.isAuthenticated ? (
              <div className="flex flex-col space-y-2 pt-2">
                <button
                  onClick={() => handleLinkClick('dashboard')}
                  className="bg-emerald-custom text-paper border border-gold-custom py-2.5 text-center font-mono text-xs uppercase tracking-wider"
                >
                  Dashboard
                </button>
                <button
                  onClick={onSignOut}
                  className="bg-transparent text-danger-custom border border-danger-custom/50 py-2.5 text-center font-mono text-xs uppercase tracking-wider"
                >
                  Sign Out
                </button>
              </div>
            ) : (
              <button
                onClick={() => handleLinkClick('login')}
                className="bg-emerald-custom text-paper border border-gold-custom py-2.5 text-center font-mono text-xs uppercase tracking-wider"
              >
                Join PLA / Login
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
