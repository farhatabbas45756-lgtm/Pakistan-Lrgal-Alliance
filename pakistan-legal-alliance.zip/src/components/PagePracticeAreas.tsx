import React from 'react';
import { ActivePage } from '../types';
import ScrollReveal from './ScrollReveal';
import { AREAS_DATA } from '../data';
import { ChevronRight, Landmark, Scale, HelpCircle } from 'lucide-react';

interface PagePracticeAreasProps {
  onNavigate: (page: ActivePage) => void;
}

export default function PagePracticeAreas({ onNavigate }: PagePracticeAreasProps) {
  const handleConsultClick = () => {
    onNavigate('contact');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="w-full" id="pla-page-practice-areas">
      {/* 1. Hero Section on Dark Emerald */}
      <section className="w-full bg-gradient-to-b from-emerald-custom to-[#0a271e] text-paper relative py-16 md:py-20 border-b border-gold-custom/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 relative z-10 text-center md:text-left">
          <span className="font-mono text-xs text-gold-custom uppercase tracking-widest inline-block border-l-2 border-gold-custom pl-3 mb-4">
            Practice Jurisdictions
          </span>
          <h1 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white leading-tight">
            Where the Alliance is active.
          </h1>
          <p className="text-xs md:text-sm text-paper-dim/80 max-w-xl font-sans mt-4 leading-relaxed">
            Our members offer accredited legal counsel, statutory representations, and public interest litigation across eight primary judicial practice sectors.
          </p>
        </div>
      </section>

      {/* 2. Primary 8-Grid Section */}
      <section className="w-full bg-paper py-16 md:py-24 border-b border-border-custom px-4 sm:px-6 md:px-8 relative z-20">
        <div className="max-w-7xl mx-auto">
          <div className="mb-12">
            <span className="font-mono text-xs text-gold-dark uppercase tracking-widest block mb-2">
              Statutory Chapters
            </span>
            <h2 className="font-serif text-2xl md:text-3xl font-bold text-emerald-custom tracking-tight">
              Approved Advisory Jurisdictions
            </h2>
            <div className="w-12 h-0.5 bg-gold-custom mt-3" />
          </div>

          {/* Hairline grid of 8 cards, flat edges, no rounded corners or shadows */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-border-custom border border-border-custom">
            {AREAS_DATA.map((area, idx) => (
              <ScrollReveal 
                key={idx} 
                delay={idx * 50} 
                className="bg-paper p-6 min-h-[250px] flex flex-col justify-between"
              >
                <div>
                  <span className="block font-mono text-xs text-gold-dark font-medium border border-gold-custom/30 w-fit px-2 py-0.5 mb-5 bg-gold-light/5">
                    {area.num}
                  </span>
                  <h3 className="font-serif text-base font-bold text-ink mb-2">
                    {area.title}
                  </h3>
                  <p className="text-xs text-ink-soft leading-relaxed font-sans mb-6">
                    {area.desc}
                  </p>
                </div>
                
                <button
                  onClick={handleConsultClick}
                  className="font-mono text-[10px] uppercase tracking-widest text-gold-dark hover:text-emerald-custom transition-colors flex items-center w-fit cursor-pointer border-t border-border-custom/30 pt-3"
                >
                  <span>Consult a member</span>
                  <ChevronRight size={12} className="ml-0.5" />
                </button>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* 3. Closing CTA: Need an advocate? */}
      <section className="w-full bg-paper-dim py-16 border-b border-border-custom px-4 sm:px-6 md:px-8 relative z-20">
        <div className="max-w-4xl mx-auto text-center flex flex-col items-center space-y-6">
          <HelpCircle className="text-emerald-custom" size={32} />
          <h2 className="font-serif text-2xl font-bold tracking-tight text-emerald-custom">
            Seeking a Certified Referral Advocate?
          </h2>
          <p className="text-xs md:text-sm text-ink-soft leading-relaxed max-w-xl font-sans">
            If you require specialized representation before the district, high, or supreme court benches, the PLA Secretariat provides a formal referral request system to match your civil or corporate concern with verified counsel.
          </p>
          <button
            onClick={handleConsultClick}
            className="bg-emerald-custom text-paper hover:bg-emerald-light px-8 py-3.5 font-mono text-xs uppercase tracking-widest font-bold transition-all cursor-pointer border border-gold-custom"
          >
            Submit Referral Request
          </button>
        </div>
      </section>
    </div>
  );
}
