import React, { useState } from 'react';
import plaLogoImg from '../assets/images/pla_logo_1784787217382.jpg';

interface PLASealProps {
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  className?: string;
  dark?: boolean;
}

export default function PLASeal({ size = 'md', className = '', dark = false }: PLASealProps) {
  const [imgError, setImgError] = useState(false);

  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-11 h-11',
    lg: 'w-16 h-16',
    xl: 'w-24 h-24',
    '2xl': 'w-36 h-36',
  };

  const ringColor = dark ? 'stroke-gold-dark' : 'stroke-gold-custom';
  const textColor = dark ? 'fill-gold-dark' : 'fill-gold-custom';

  return (
    <div className={`inline-block relative shrink-0 rounded-full overflow-hidden ${sizeClasses[size]} ${className}`} id="pla-seal-container">
      {!imgError ? (
        <img
          src={plaLogoImg}
          alt="Pakistan Legal Alliance (PLA) Official Logo"
          referrerPolicy="no-referrer"
          onError={() => setImgError(true)}
          className="w-full h-full object-cover rounded-full shadow-xs ring-1 ring-gold-custom/30"
        />
      ) : (
        <svg viewBox="0 0 100 100" className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          {/* Outer Ring */}
          <circle 
            cx="50" 
            cy="50" 
            r="46" 
            fill="none" 
            className={ringColor} 
            strokeWidth="1.5" 
          />
          {/* Inner Ring */}
          <circle 
            cx="50" 
            cy="50" 
            r="40" 
            fill="none" 
            className={ringColor} 
            strokeWidth="0.75" 
            strokeDasharray="1.5 1.5" 
          />
          {/* Central Monogram */}
          <text 
            x="50" 
            y="57" 
            fontFamily="Fraunces, Georgia, serif" 
            fontSize="24" 
            fontWeight="700" 
            className={textColor} 
            textAnchor="middle" 
            letterSpacing="0.5"
          >
            PLA
          </text>
        </svg>
      )}
    </div>
  );
}

