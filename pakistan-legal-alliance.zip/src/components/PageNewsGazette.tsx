import React, { useState } from 'react';
import ScrollReveal from './ScrollReveal';
import { GAZETTE_ITEMS } from '../data';
import { GazetteItem } from '../types';
import { BookOpen, AlertCircle, FileText, Calendar, Search, Filter } from 'lucide-react';

export default function PageNewsGazette() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedItem, setSelectedItem] = useState<GazetteItem | null>(null);

  const categories = ['All', 'Notice', 'Publication', 'Statement'];

  const filteredItems = GAZETTE_ITEMS.filter((item) => {
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          item.summary.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getPillColor = (cat: 'Notice' | 'Publication' | 'Statement') => {
    switch (cat) {
      case 'Notice':
        return 'bg-emerald-custom/5 text-emerald-custom border-emerald-custom/20';
      case 'Publication':
        return 'bg-gold-custom/10 text-gold-dark border-gold-custom/20';
      case 'Statement':
        return 'bg-amber-700/5 text-amber-900 border-amber-700/20';
    }
  };

  return (
    <div className="w-full" id="pla-page-news-gazette">
      {/* 1. Hero Section on Dark Emerald */}
      <section className="w-full bg-gradient-to-b from-emerald-custom to-[#0a271e] text-paper relative py-16 md:py-20 border-b border-gold-custom/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 relative z-10 text-center md:text-left">
          <span className="font-mono text-xs text-gold-custom uppercase tracking-widest inline-block border-l-2 border-gold-custom pl-3 mb-4">
            Official Announcements & Annals
          </span>
          <h1 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white leading-tight">
            The PLA Gazette
          </h1>
          <p className="text-xs md:text-sm text-paper-dim/80 max-w-xl font-sans mt-4 leading-relaxed">
            Access official decrees, national law treatises, circulars, regional chapter polls, and constitutional stances published by the PLA Secretariat.
          </p>
        </div>
      </section>

      {/* 2. Main Gazette Feed Section */}
      <section className="w-full bg-paper py-16 px-4 sm:px-6 md:px-8 relative z-20">
        <div className="max-w-7xl mx-auto">
          
          {/* Filtering and Searching Bar */}
          <div className="flex flex-col md:flex-row justify-between items-stretch md:items-center gap-4 mb-10 border-b border-border-custom pb-6">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-mono text-[10px] text-ink-faint uppercase tracking-wider mr-2 flex items-center">
                <Filter size={12} className="mr-1" /> Filter:
              </span>
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => {
                    setSelectedCategory(cat);
                    setSelectedItem(null);
                  }}
                  className={`px-3 py-1 font-mono text-[10px] uppercase tracking-wider border transition-all cursor-pointer ${
                    selectedCategory === cat
                      ? 'bg-emerald-custom text-paper border-emerald-custom'
                      : 'bg-paper text-ink-soft border-border-custom hover:border-gold-custom'
                  }`}
                >
                  {cat}s
                </button>
              ))}
            </div>

            <div className="relative w-full md:w-80">
              <input
                type="text"
                placeholder="Search the Gazette..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-paper border border-border-custom px-4 py-2 pl-9 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
              />
              <Search className="absolute left-3 top-2.5 text-ink-faint" size={14} />
            </div>
          </div>

          {/* Dual Column Layout: Left Grid, Right Reader Panel (If Item Selected) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Grid column */}
            <div className={`grid grid-cols-1 md:grid-cols-2 gap-6 ${selectedItem ? 'lg:col-span-7' : 'lg:col-span-12'}`}>
              {filteredItems.map((item, idx) => (
                <ScrollReveal 
                  key={item.id} 
                  delay={idx * 50} 
                  className={`p-6 border transition-all bg-paper flex flex-col justify-between ${
                    selectedItem?.id === item.id 
                      ? 'border-gold-custom shadow-sm bg-paper-dim/10' 
                      : 'border-border-custom'
                  }`}
                >
                  <div>
                    <div className="flex justify-between items-center mb-4">
                      <span className={`border font-mono text-[9px] uppercase tracking-wider px-2 py-0.5 ${getPillColor(item.category)}`}>
                        {item.category}
                      </span>
                      <span className="text-[10px] font-mono text-ink-faint flex items-center">
                        <Calendar size={10} className="mr-1" /> {item.date}
                      </span>
                    </div>
                    
                    <h3 className="font-serif text-base font-bold text-ink mb-3 line-clamp-2">
                      {item.title}
                    </h3>
                    
                    <p className="text-xs text-ink-soft leading-relaxed font-sans line-clamp-3 mb-6">
                      {item.summary}
                    </p>
                  </div>

                  <div className="border-t border-border-custom/50 pt-4 flex items-center justify-between">
                    <span className="text-[9px] font-mono text-ink-faint tracking-wider">
                      REF-{item.id}
                    </span>
                    <button
                      onClick={() => setSelectedItem(item)}
                      className="font-mono text-[10px] uppercase tracking-widest text-gold-dark hover:text-emerald-custom cursor-pointer font-semibold flex items-center"
                    >
                      <FileText size={11} className="mr-1" /> Access Full Text
                    </button>
                  </div>
                </ScrollReveal>
              ))}

              {filteredItems.length === 0 && (
                <div className="col-span-full py-16 text-center border border-dashed border-border-custom bg-paper-dim/10">
                  <AlertCircle size={24} className="mx-auto text-ink-faint mb-2" />
                  <p className="font-mono text-xs text-ink-soft">No official records found matching query.</p>
                </div>
              )}
            </div>

            {/* Selected Document Details Reader Box */}
            {selectedItem && (
              <div className="lg:col-span-5 bg-paper-dim/40 border border-gold-custom/50 p-6 sticky top-6">
                <div className="flex justify-between items-center border-b border-border-custom pb-4 mb-4">
                  <span className="font-mono text-[10px] uppercase tracking-widest text-gold-dark font-bold">
                    Official Document Reader
                  </span>
                  <button
                    onClick={() => setSelectedItem(null)}
                    className="text-ink-soft hover:text-red-700 font-mono text-xs cursor-pointer uppercase tracking-wider"
                  >
                    Close
                  </button>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between items-center text-[10px] font-mono text-ink-faint">
                    <span>DOCUMENT REF: PLA-{selectedItem.id}</span>
                    <span>ISSUED: {selectedItem.date}</span>
                  </div>

                  <span className={`inline-block border font-mono text-[9px] uppercase tracking-wider px-2.5 py-0.5 ${getPillColor(selectedItem.category)}`}>
                    {selectedItem.category}
                  </span>

                  <h3 className="font-serif text-lg font-bold text-emerald-custom leading-snug">
                    {selectedItem.title}
                  </h3>

                  <div className="h-px bg-border-custom" />

                  <p className="text-xs text-ink font-sans leading-relaxed">
                    <strong>Summary Statement:</strong> {selectedItem.summary}
                  </p>

                  <div className="border border-border-custom bg-paper p-4">
                    <span className="block font-mono text-[9px] text-gold-dark uppercase tracking-widest mb-1 font-semibold">
                      Security & Attestation Note
                    </span>
                    <p className="text-[10px] text-ink-soft font-sans leading-relaxed">
                      This constitutes an official publication of the Pakistan Legal Alliance. Subscribed members can access direct legal brief attachments and certifications under full seal from the central database in the Member Portal.
                    </p>
                  </div>

                  <div className="pt-2 flex justify-between">
                    <span className="text-[9px] font-mono text-ink-faint uppercase">
                      PLA Central Registry
                    </span>
                    <span className="text-[9px] font-mono text-gold-dark uppercase font-semibold">
                      Certified PDF available in Portal
                    </span>
                  </div>
                </div>
              </div>
            )}

          </div>

        </div>
      </section>
    </div>
  );
}
