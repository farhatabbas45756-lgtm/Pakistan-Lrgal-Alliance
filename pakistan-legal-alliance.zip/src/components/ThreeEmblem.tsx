import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import plaLogoImg from '../assets/images/pla_logo_1784787217382.jpg';

export default function ThreeEmblem() {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [reducedMotion, setReducedMotion] = useState(false);

  useEffect(() => {
    // Check for prefers-reduced-motion
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReducedMotion(mediaQuery.matches);
    
    const handler = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mediaQuery.addEventListener('change', handler);
    return () => mediaQuery.removeEventListener('change', handler);
  }, []);

  useEffect(() => {
    if (reducedMotion || !canvasRef.current || !containerRef.current) return;

    const container = containerRef.current;
    const canvas = canvasRef.current;

    // 1. Create Scene, Camera, and Renderer
    const scene = new THREE.Scene();
    
    const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 100);
    camera.position.z = 8;

    const renderer = new THREE.WebGLRenderer({
      canvas: canvas,
      alpha: true,
      antialias: true,
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // 2. Create the 3D geometries
    // Main gold wireframe Icosahedron
    const icosahedronGeo = new THREE.IcosahedronGeometry(1.6, 1);
    const goldWireframeMat = new THREE.MeshBasicMaterial({
      color: 0xC9A227, // gold/brass
      wireframe: true,
      transparent: true,
      opacity: 0.85,
    });
    const icosahedron = new THREE.Mesh(icosahedronGeo, goldWireframeMat);
    scene.add(icosahedron);

    // Dynamic inner solid point / small solid core
    const coreGeo = new THREE.IcosahedronGeometry(0.3, 0);
    const coreMat = new THREE.MeshBasicMaterial({
      color: 0xE4CD82,
      wireframe: true,
      transparent: true,
      opacity: 0.6,
    });
    const core = new THREE.Mesh(coreGeo, coreMat);
    scene.add(core);

    // Torus Ring 1 (Horizontal tilt)
    const torusGeo1 = new THREE.TorusGeometry(2.3, 0.02, 8, 64);
    const torusMat1 = new THREE.MeshBasicMaterial({
      color: 0xA9841A,
      wireframe: true,
      transparent: true,
      opacity: 0.6,
    });
    const torus1 = new THREE.Mesh(torusGeo1, torusMat1);
    torus1.rotation.x = Math.PI / 4;
    scene.add(torus1);

    // Torus Ring 2 (Vertical tilt)
    const torusGeo2 = new THREE.TorusGeometry(2.5, 0.015, 8, 64);
    const torusMat2 = new THREE.MeshBasicMaterial({
      color: 0xE4CD82,
      wireframe: true,
      transparent: true,
      opacity: 0.4,
    });
    const torus2 = new THREE.Mesh(torusGeo2, torusMat2);
    torus2.rotation.y = Math.PI / 3;
    scene.add(torus2);

    // Drifting particle points (gold/white stars)
    const particleCount = 45;
    const particleGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const speeds = new Float32Array(particleCount);

    for (let i = 0; i < particleCount; i++) {
      // Random coordinates in a shell around the emblem
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);
      const distance = 2.2 + Math.random() * 1.5;

      positions[i * 3] = distance * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = distance * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = distance * Math.cos(phi);

      speeds[i] = 0.005 + Math.random() * 0.01;
    }

    particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const particleMat = new THREE.PointsMaterial({
      color: 0xE4CD82,
      size: 0.04,
      transparent: true,
      opacity: 0.8,
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);

    // 3. Resize Observer to size canvas based on container size
    const resizeObserver = new ResizeObserver((entries) => {
      if (!entries || entries.length === 0) return;
      const { width, height } = entries[0].contentRect;
      
      const w = width || 300;
      const h = height || 300;
      
      renderer.setSize(w, h);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    });
    
    resizeObserver.observe(container);

    // 4. Animation loop
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      const elapsedTime = clock.getElapsedTime();

      // Soft rotations
      icosahedron.rotation.y = elapsedTime * 0.15;
      icosahedron.rotation.x = elapsedTime * 0.08;

      core.rotation.y = -elapsedTime * 0.25;

      torus1.rotation.z = elapsedTime * 0.1;
      torus1.rotation.y = Math.sin(elapsedTime * 0.05) * 0.3;

      torus2.rotation.z = -elapsedTime * 0.08;
      torus2.rotation.x = Math.cos(elapsedTime * 0.04) * 0.2;

      // Animate particles
      const positionsAttr = particles.geometry.attributes.position as THREE.BufferAttribute;
      const arr = positionsAttr.array as Float32Array;
      for (let i = 0; i < particleCount; i++) {
        // slowly drift
        arr[i * 3 + 1] += speeds[i] * 0.2; // float up
        // Wrap around if they go too high
        if (arr[i * 3 + 1] > 3.5) {
          arr[i * 3 + 1] = -3.5;
        }
      }
      positionsAttr.needsUpdate = true;

      renderer.render(scene, camera);
    };

    animate();

    // 5. Cleanup
    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      
      // Dispose resources
      icosahedronGeo.dispose();
      goldWireframeMat.dispose();
      coreGeo.dispose();
      coreMat.dispose();
      torusGeo1.dispose();
      torusMat1.dispose();
      torusGeo2.dispose();
      torusMat2.dispose();
      particleGeo.dispose();
      particleMat.dispose();
      renderer.dispose();
    };
  }, [reducedMotion]);

  if (reducedMotion) {
    // Elegant fallback: Gold/brass radial gradient glowing or static vector representation
    return (
      <div 
        id="pla-emblem-static-fallback" 
        className="w-full h-full max-w-[320px] max-h-[320px] aspect-square mx-auto flex items-center justify-center relative"
      >
        <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-gold-custom/10 via-gold-custom/5 to-transparent blur-2xl" />
        <img
          src={plaLogoImg}
          alt="Pakistan Legal Alliance Logo"
          referrerPolicy="no-referrer"
          className="w-48 h-48 rounded-full object-cover shadow-xl ring-2 ring-gold-custom/50"
        />
      </div>
    );
  }

  return (
    <div 
      ref={containerRef} 
      className="w-full h-full min-h-[280px] max-h-[360px] md:min-h-[320px] aspect-square flex items-center justify-center relative overflow-hidden"
    >
      <div className="absolute inset-0 bg-radial from-gold-custom/5 via-transparent to-transparent pointer-events-none" />
      <canvas 
        ref={canvasRef} 
        className="w-full h-full pointer-events-none filter drop-shadow-[0_0_12px_rgba(201,162,39,0.15)]"
      />
      {/* Central Official Seal Badge */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-28 h-28 md:w-32 md:h-32 rounded-full p-1 bg-gradient-to-tr from-gold-dark via-gold-custom to-gold-light shadow-2xl ring-2 ring-gold-custom/40 animate-pulse-slow">
          <img
            src={plaLogoImg}
            alt="Pakistan Legal Alliance Official Emblem"
            referrerPolicy="no-referrer"
            className="w-full h-full rounded-full object-cover shadow-inner"
          />
        </div>
      </div>
    </div>
  );
}
