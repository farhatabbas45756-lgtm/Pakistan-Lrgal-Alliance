import React, { useState } from 'react';
import { ActivePage } from '../types';
import PLASeal from './PLASeal';
import ScrollReveal from './ScrollReveal';
import { Mail, ArrowRight, ArrowLeft, CheckCircle } from 'lucide-react';
import { sendPasswordResetEmail } from 'firebase/auth';
import { auth } from '../lib/firebase';

interface PageForgotPasswordProps {
  onNavigate: (page: ActivePage) => void;
}

export default function PageForgotPassword({ onNavigate }: PageForgotPasswordProps) {
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setIsSubmitting(true);
    setError(null);

    try {
      // Dispatch real Firebase password reset email directly to user's inbox (e.g. thread.fia@gmail.com)
      await sendPasswordResetEmail(auth, email.trim().toLowerCase());

      // Send log to server-side audit logs
      try {
        await fetch('/api/requestPasswordReset', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-firebase-appcheck': 'sandbox_test_token'
          },
          body: JSON.stringify({ email: email.trim().toLowerCase() }),
        });
      } catch (logErr) {
        console.warn('Server audit log recording bypassed:', logErr);
      }

      setIsSubmitted(true);
    } catch (err: any) {
      console.error('Password reset dispatch error:', err);
      setError(err.message || 'An unexpected error occurred. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="w-full min-h-[calc(100vh-140px)] bg-paper flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8" id="pla-page-forgot-password">
      <div className="w-full max-w-md bg-paper border border-border-custom p-8 shadow-sm flex flex-col justify-between min-h-[450px]">
        
        <div className="space-y-6">
          {/* Header Seal */}
          <div className="flex flex-col items-center text-center space-y-3">
            <PLASeal size="sm" />
            <div>
              <h2 className="font-serif text-lg font-bold text-emerald-custom tracking-tight uppercase">
                Reset Advocate Credentials
              </h2>
              <span className="block text-[8px] font-mono tracking-widest text-gold-dark uppercase mt-0.5">
                Pakistan Legal Alliance
              </span>
            </div>
            <div className="w-12 h-px bg-gold-custom mt-2" />
          </div>

          {isSubmitted ? (
            <ScrollReveal className="space-y-5 text-center py-4">
              <CheckCircle size={44} className="text-emerald-custom mx-auto" />
              <h3 className="font-serif text-base font-bold text-emerald-custom">
                Dispatch Successful
              </h3>
              <p className="text-xs text-ink-soft font-sans leading-relaxed text-left">
                An official security transmission has been sent to your registered email address with instructions to establish a secure password.
              </p>

              <button
                onClick={() => onNavigate('login')}
                className="inline-flex items-center space-x-1.5 text-xs font-mono uppercase tracking-wider text-emerald-custom hover:text-gold-custom transition-colors cursor-pointer"
              >
                <ArrowLeft size={12} />
                <span>Return to Sign In</span>
              </button>
            </ScrollReveal>
          ) : (
            <ScrollReveal className="space-y-4">
              <p className="text-xs text-ink-soft font-sans leading-normal text-center">
                Submit your certified bar registry email address. If an active dossier matches, we will dispatch an auth-event reset code.
              </p>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1 font-semibold">
                    Registered Email Address *
                  </label>
                  <div className="relative">
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-paper border border-border-custom px-3 py-2 pl-9 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
                      placeholder="e.g. s.alvi@barcounsel.pk"
                    />
                    <Mail className="absolute left-3 top-2.5 text-ink-faint" size={12} />
                  </div>
                </div>

                {error && (
                  <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-800 text-xs font-sans rounded-xs">
                    {error}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-emerald-custom text-paper hover:bg-emerald-light disabled:opacity-50 py-2.5 font-mono text-xs uppercase tracking-widest font-bold transition-all border border-gold-custom cursor-pointer flex items-center justify-center space-x-2"
                >
                  <span>{isSubmitting ? 'Verifying Dossier...' : 'Request Reset Link'}</span>
                  <ArrowRight size={12} />
                </button>
              </form>

              <div className="text-center pt-2">
                <button
                  onClick={() => onNavigate('login')}
                  className="inline-flex items-center space-x-1.5 text-xs font-mono uppercase tracking-wider text-ink-soft hover:text-emerald-custom transition-colors cursor-pointer"
                >
                  <ArrowLeft size={12} />
                  <span>Return to Sign In</span>
                </button>
              </div>
            </ScrollReveal>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-border-custom/50 pt-4 text-center mt-6">
          <span className="font-mono text-[8px] text-ink-faint uppercase tracking-wider block">
            PLA CENTRAL REGISTRY SECURITY · ISLAMABAD
          </span>
        </div>

      </div>
    </div>
  );
}
