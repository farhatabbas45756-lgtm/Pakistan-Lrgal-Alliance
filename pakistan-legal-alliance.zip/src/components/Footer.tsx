import React from 'react';
import { ActivePage } from '../types';
import PLASeal from './PLASeal';
import { Mail, Phone, MapPin, ExternalLink } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: ActivePage) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  const handleLinkClick = (page: ActivePage) => {
    onNavigate(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="w-full bg-[#07241B] text-paper border-t border-emerald-light/40 relative z-30" id="pla-public-footer">
      {/* Upper footer grid */}
      <div className="max-w-7xl mx-auto py-12 md:py-16 px-4 sm:px-6 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12">
          {/* Column 1: About Blurb */}
          <div className="flex flex-col space-y-4">
            <div className="flex items-center space-x-3">
              <PLASeal size="sm" />
              <span className="font-serif text-lg font-bold tracking-tight text-white">
                PLA
              </span>
            </div>
            <p className="text-xs text-paper-dim/80 font-sans leading-relaxed">
              The Pakistan Legal Alliance (PLA) is the premier national bar association and law society, establishing code of conduct parameters, advancing justice reforms, and mentoring practitioners since April 2026.
            </p>
            <p className="text-[10px] font-mono tracking-wider text-gold-light/60 uppercase">
              ESTD. April 2026 · REGISTRATION NO. 410-PK
            </p>
          </div>

          {/* Column 2: Directory Links */}
          <div>
            <h4 className="font-mono text-xs uppercase tracking-wider text-gold-custom font-semibold mb-4 border-b border-emerald-light/30 pb-2">
              Directory & Resources
            </h4>
            <ul className="space-y-2.5 text-xs text-paper-dim/80">
              <li>
                <button onClick={() => handleLinkClick('practice-areas')} className="hover:text-gold-light transition-colors hover:underline cursor-pointer">
                  Practice Advisory Areas
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('news-gazette')} className="hover:text-gold-light transition-colors hover:underline cursor-pointer">
                  PLA Law Gazette & Publications
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('about')} className="hover:text-gold-light transition-colors hover:underline cursor-pointer">
                  Central & Chapter Councils
                </button>
              </li>
              <li>
                <span className="text-paper-dim/40 cursor-not-allowed flex items-center">
                  Supreme Court Bar Association <ExternalLink size={10} className="ml-1" />
                </span>
              </li>
            </ul>
          </div>

          {/* Column 3: Members Links */}
          <div>
            <h4 className="font-mono text-xs uppercase tracking-wider text-gold-custom font-semibold mb-4 border-b border-emerald-light/30 pb-2">
              Member Services
            </h4>
            <ul className="space-y-2.5 text-xs text-paper-dim/80">
              <li>
                <button onClick={() => handleLinkClick('login')} className="hover:text-gold-light transition-colors hover:underline cursor-pointer">
                  Access Member Portal
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('login')} className="hover:text-gold-light transition-colors hover:underline cursor-pointer">
                  Apply for PLA Membership
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('recruitment')} className="hover:text-gold-light transition-colors hover:underline cursor-pointer">
                  Institutional Careers
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('contact')} className="hover:text-gold-light transition-colors hover:underline cursor-pointer">
                  Regional Legal Aid Clinics
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Contact Info */}
          <div className="flex flex-col space-y-3">
            <h4 className="font-mono text-xs uppercase tracking-wider text-gold-custom font-semibold border-b border-emerald-light/30 pb-2">
              Secretariat Contact
            </h4>
            <div className="flex items-start space-x-2 text-xs text-paper-dim/80">
              <MapPin size={14} className="text-gold-custom mt-0.5 shrink-0" />
              <span>Main Head Office, Lahore, Punjab, Pakistan</span>
            </div>
            <div className="flex items-center space-x-2 text-xs text-paper-dim/80">
              <Mail size={14} className="text-gold-custom shrink-0" />
              <a href="mailto:plapakistanlegalalliance@gmail.com" className="hover:text-gold-light hover:underline">
                plapakistanlegalalliance@gmail.com
              </a>
            </div>
            <div className="flex items-start space-x-2 text-xs text-paper-dim/80">
              <Phone size={14} className="text-gold-custom shrink-0 mt-0.5" />
              <div className="flex flex-col space-y-1">
                <a href="tel:03184804872" className="hover:text-gold-light hover:underline">
                  Founder & CEO: 0318-4804872
                </a>
                <a href="tel:03419995007" className="hover:text-gold-light hover:underline">
                  President: 03419995007
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Lower footer rule & trademark */}
        <div className="mt-12 pt-8 border-t border-emerald-light/30 flex flex-col md:flex-row justify-between items-center text-[10px] font-mono tracking-widest text-paper-dim/50 uppercase">
          <div>
            © {new Date().getFullYear()} PAKISTAN LEGAL ALLIANCE. ALL RIGHTS RESERVED.
          </div>
          <div className="mt-2 md:mt-0">
            ADVANCING THE RULE OF LAW · JUSTICE THROUGH ADVOCACY
          </div>
        </div>
      </div>
    </footer>
  );
}
