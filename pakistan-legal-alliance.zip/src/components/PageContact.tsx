import React, { useState } from 'react';
import ScrollReveal from './ScrollReveal';
import { Mail, Phone, MapPin, CheckCircle, Clock, Globe } from 'lucide-react';

export default function PageContact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });
  const [faxNumber, setFaxNumber] = useState(''); // honeypot
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    try {
      const response = await fetch('/api/submitContact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-firebase-appcheck': 'sandbox_test_token'
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          subject: formData.subject,
          message: formData.message,
          faxNumber: faxNumber
        })
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to submit the contact message.');
      }
      setIsSubmitted(true);
    } catch (err: any) {
      console.error('Error sending message:', err);
      setError(err.message || 'Failed to submit the contact message. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setFormData({ name: '', email: '', subject: '', message: '' });
    setFaxNumber('');
    setIsSubmitted(false);
    setError(null);
  };

  return (
    <div className="w-full" id="pla-page-contact">
      {/* 1. Hero Section on Dark Emerald */}
      <section className="w-full bg-gradient-to-b from-emerald-custom to-[#0a271e] text-paper relative py-16 md:py-20 border-b border-gold-custom/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 relative z-10 text-center md:text-left">
          <span className="font-mono text-xs text-gold-custom uppercase tracking-widest inline-block border-l-2 border-gold-custom pl-3 mb-4">
            Inquiries & Correspondence
          </span>
          <h1 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white leading-tight">
            Contact the Secretariat.
          </h1>
          <p className="text-xs md:text-sm text-paper-dim/80 max-w-xl font-sans mt-4 leading-relaxed">
            Reach our administrative offices in Lahore, Punjab for statutory registries, disciplinary boards, continuing education audits, or public relations.
          </p>
        </div>
      </section>

      {/* 2. Main Contact Grid (Split Layout) */}
      <section className="w-full bg-paper py-16 md:py-24 border-b border-border-custom px-4 sm:px-6 md:px-8 relative z-20">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-start">
            
            {/* Left Column: Form Card */}
            <div>
              {isSubmitted ? (
                <ScrollReveal className="bg-[#FAF7F0] border border-gold-custom p-8 text-center flex flex-col items-center space-y-4">
                  <CheckCircle size={44} className="text-emerald-custom" />
                  <h3 className="font-serif text-xl font-bold text-emerald-custom">
                    Message Dispatched Successfully
                  </h3>
                  <p className="text-xs text-ink-soft font-sans leading-relaxed">
                    Thank you. Your dispatch has been logged in the Secretariat's incoming records. A correspondence clerk from the Central Council will reply to your registered email address as soon as possible.
                  </p>
                  <button
                    onClick={resetForm}
                    className="mt-2 text-xs font-mono uppercase tracking-wider text-emerald-custom hover:text-gold-custom transition-colors cursor-pointer"
                  >
                    Submit another inquiry
                  </button>
                </ScrollReveal>
              ) : (
                <div className="bg-paper border border-border-custom p-8">
                  <span className="font-mono text-xs text-gold-dark uppercase tracking-widest block mb-1">
                    Correspondence Registry
                  </span>
                  <h2 className="font-serif text-xl font-bold text-emerald-custom mb-6 tracking-tight">
                    Submit a Formal Inquiry
                  </h2>

                  <form onSubmit={handleSubmit} className="space-y-5">
                    {/* Honeypot field for anti-spam protection */}
                    <div style={{ display: 'none' }} aria-hidden="true">
                      <input
                        type="text"
                        name="faxNumber"
                        value={faxNumber}
                        onChange={(e) => setFaxNumber(e.target.value)}
                        tabIndex={-1}
                        autoComplete="off"
                        placeholder="Do not fill this field"
                      />
                    </div>

                    {/* Name */}
                    <div>
                      <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1.5 font-semibold">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                        className="w-full bg-paper border border-border-custom px-3 py-2 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
                        placeholder="e.g. Advocate Hamza Niazi"
                      />
                    </div>

                    {/* Email */}
                    <div>
                      <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1.5 font-semibold">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
                        className="w-full bg-paper border border-border-custom px-3 py-2 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
                        placeholder="hamza@firm.pk"
                      />
                    </div>

                    {/* Subject dropdown */}
                    <div>
                      <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1.5 font-semibold">
                        Subject of Inquiry *
                      </label>
                      <select
                        required
                        value={formData.subject}
                        onChange={(e) => setFormData((prev) => ({ ...prev, subject: e.target.value }))}
                        className="w-full bg-paper border border-border-custom px-3 py-2 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
                      >
                        <option value="" disabled>Select a department</option>
                        <option value="standards">Bar Council Accreditations & Standards</option>
                        <option value="cle">Continuing Legal Education (CLE) Audits</option>
                        <option value="probono">Pro Bono & Legal Aid Partnerships</option>
                        <option value="publications">Publications & Gazette Submissions</option>
                        <option value="disciplinary">Disciplinary Board Inquiries</option>
                        <option value="general">General Secretariat Correspondence</option>
                      </select>
                    </div>

                    {/* Message */}
                    <div>
                      <label className="block font-mono text-[10px] text-ink-soft uppercase tracking-wider mb-1.5 font-semibold">
                        Inquiry Narrative *
                      </label>
                      <textarea
                        required
                        rows={5}
                        value={formData.message}
                        onChange={(e) => setFormData((prev) => ({ ...prev, message: e.target.value }))}
                        className="w-full bg-paper border border-border-custom p-3 font-sans text-xs focus:outline-none focus:border-gold-custom text-ink"
                        placeholder="Describe your inquiry with references or case citations where relevant..."
                      />
                    </div>

                    {/* Error Notice */}
                    {error && (
                      <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs font-sans rounded-xs">
                        {error}
                      </div>
                    )}

                    {/* Submit Button */}
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-emerald-custom text-paper hover:bg-emerald-light disabled:opacity-50 px-6 py-3 font-mono text-xs uppercase tracking-widest font-bold transition-all cursor-pointer border border-gold-custom"
                    >
                      {isSubmitting ? 'Dispatching Message...' : 'Register Formal Dispatch'}
                    </button>
                  </form>
                </div>
              )}
            </div>

            {/* Right Column: Office Details */}
            <div className="flex flex-col space-y-8">
              
              {/* Primary Address */}
              <div>
                <span className="font-mono text-xs text-gold-dark uppercase tracking-widest block mb-2">
                  Headquarters
                </span>
                <h3 className="font-serif text-lg font-bold text-emerald-custom mb-4">
                  The Central Secretariat
                </h3>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3 text-xs text-ink-soft">
                    <MapPin className="text-gold-dark mt-0.5 shrink-0" size={16} />
                    <div>
                      <p className="font-medium text-ink">Pakistan Legal Alliance (PLA)</p>
                      <p>Main Head Office,</p>
                      <p>Lahore, Punjab, Pakistan</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3 text-xs text-ink-soft">
                    <Mail className="text-gold-dark shrink-0" size={16} />
                    <a href="mailto:plapakistanlegalalliance@gmail.com" className="hover:text-gold-dark hover:underline text-ink">
                      plapakistanlegalalliance@gmail.com
                    </a>
                  </div>

                  <div className="flex items-start space-x-3 text-xs text-ink-soft">
                    <Phone className="text-gold-dark shrink-0 mt-0.5" size={16} />
                    <div className="flex flex-col space-y-1">
                      <p className="font-medium text-ink">Official Contact Lines:</p>
                      <a href="tel:03184804872" className="hover:text-gold-dark hover:underline text-ink">
                        Founder & CEO: 0318-4804872
                      </a>
                      <a href="tel:03419995007" className="hover:text-gold-dark hover:underline text-ink">
                        President: 03419995007
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3 text-xs text-ink-soft">
                    <Clock className="text-gold-dark mt-0.5 shrink-0" size={16} />
                    <div>
                      <p className="font-medium text-ink">Operating Hours</p>
                      <p>Monday – Friday: 9:00 AM – 5:00 PM (PKT)</p>
                      <p className="text-[10px] text-ink-faint">Closed on national and judicial holidays.</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Chapter Offices note */}
              <div className="bg-[#FAF7F0] border border-border-custom p-6">
                <div className="flex items-center space-x-2 mb-3">
                  <Globe className="text-emerald-custom" size={16} />
                  <h4 className="font-serif text-sm font-bold text-ink">
                    Regional Chapter Offices
                  </h4>
                </div>
                <p className="text-xs text-ink-soft leading-relaxed font-sans mb-3">
                  In addition to the Lahore Head Office, members can submit applications and attend CLE lectures at our certified regional branch offices:
                </p>
                <ul className="grid grid-cols-2 gap-2 text-[10px] font-mono text-gold-dark uppercase tracking-wide">
                  <li>· Lahore Chapter (Ferozepur Rd)</li>
                  <li>· Karachi Chapter (South Court)</li>
                  <li>· Peshawar Chapter (High Court Rd)</li>
                  <li>· Quetta Chapter (Cantt Area)</li>
                </ul>
              </div>

            </div>

          </div>
        </div>
      </section>
    </div>
  );
}
