export type ActivePage =
  | 'home'
  | 'about'
  | 'practice-areas'
  | 'news-gazette'
  | 'recruitment'
  | 'contact'
  | 'login'
  | 'forgot-password'
  | 'reset-password'
  | 'dashboard'
  | 'announcements'
  | 'directory'
  | 'announcements-publishing'
  | 'admin-logs'
  | 'admin';

export interface PLAMember {
  id: string;
  serialNo: number;
  name: string;
  role: string;
  email: string;
  phone: string;
  chapter: string;
  status: 'Active' | 'Suspended' | 'Under Review';
  dateJoined: string;
  isAdmin?: boolean;
  designation?: 'Senior Advocate' | 'Junior Advocate' | 'Counsel';
}

export interface JobPosting {
  id: string;
  title: string;
  status: 'Open' | 'Closing Soon';
  location: string;
  employmentType: string;
  refNumber: string;
}

export interface GazetteItem {
  id: string;
  category: 'Notice' | 'Publication' | 'Statement';
  title: string;
  summary: string;
  date: string;
}

export interface CaseReferral {
  ref: string;
  district: string;
  status: 'Pending Review' | 'Active Assignment' | 'Resolved';
}

export interface AnnouncementItem {
  id: string;
  title: string;
  body: string;
  date: string;
  postedBy: string;
  chapter: string;
  category?: 'Upcoming Event' | 'Notice' | 'Publication' | 'Statement';
  eventDate?: string;
  eventLocation?: string;
}

export interface UserState {
  isAuthenticated: boolean;
  name: string;
  memberId: string;
  email: string;
  isAdmin?: boolean;
  token?: string;
}

export interface AdminActionLog {
  id: string;
  timestamp: string;
  adminName: string;
  actionType: 'MEMBER_ADD' | 'MEMBER_EDIT' | 'MEMBER_DELETE' | 'MEMBER_RESET' | 'ANNOUNCEMENT_PUBLISH' | 'ANNOUNCEMENT_DELETE' | 'ANNOUNCEMENT_RESET';
  details: string;
}

