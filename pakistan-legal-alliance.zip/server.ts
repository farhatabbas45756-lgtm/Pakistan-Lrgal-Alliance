import express from 'express';
import path from 'path';
import crypto from 'crypto';
import { createServer as createViteServer } from 'vite';
import { initializeApp } from 'firebase-admin/app';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { getAuth } from 'firebase-admin/auth';
import { getAppCheck } from 'firebase-admin/app-check';
import firebaseConfig from './firebase-applet-config.json' with { type: 'json' };

// Secretariat Admin Allow-List
const SECRETARIAT_ADMINS = [
  { name: "Farhat Abbas",       designation: "Media Director",   email: "thread.fia@gmail.com" },
  { name: "ADV Ehtasham Khan",  designation: "Founder & CEO",     email: "plapakistanlegalalliance@gmail.com" },
  { name: "Nabeel Saad Khan",   designation: "President",        email: "nabeel.saad@pakistanlegalalliance.org" },
  { name: "Shams",              designation: "TODO — fill in",    email: "TODO — fill in" },
  { name: "Rehana Watto",       designation: "TODO — fill in",    email: "TODO — fill in" },
];

const isSecretariatAdmin = (email: string): boolean => {
  if (!email || email.trim() === '' || email.toLowerCase().includes('todo')) return false;
  return SECRETARIAT_ADMINS.some(admin => admin.email.toLowerCase() === email.trim().toLowerCase());
};

// Initialize Firebase Admin SDK
let isAdminInitialized = false;
let dbAdmin: any = null;
let authAdmin: any = null;
let appCheckAdmin: any = null;

try {
  // If running in Google Cloud or with ADC, initialize default app
  initializeApp({
    projectId: firebaseConfig.projectId,
  });
  
  // Connect to custom Firestore database if specified
  const customDbId = firebaseConfig.firestoreDatabaseId;
  dbAdmin = customDbId && customDbId !== '(default)'
    ? getFirestore(undefined, customDbId)
    : getFirestore();

  authAdmin = getAuth();
  appCheckAdmin = getAppCheck();
  isAdminInitialized = true;
  console.log('Firebase Admin SDK initialized successfully with Project ID:', firebaseConfig.projectId);
} catch (error) {
  console.error('Firebase Admin SDK failed to initialize automatically. Initializing in sandbox mode:', error);
}

// Helper: Sync Active Members to limited public Directory Profile collection
async function syncToDirectory(uid: string, data: any) {
  if (!isAdminInitialized || !dbAdmin) return;
  try {
    const directoryRef = dbAdmin.collection('memberDirectory').doc(uid);
    if (data && data.status === 'active') {
      await directoryRef.set({
        displayName: data.displayName || '',
        chapter: data.chapter || '',
        designation: data.designation || 'Counsel',
        role: data.role || 'member',
        createdAt: data.createdAt || FieldValue.serverTimestamp()
      });
      console.log(`[DIRECTORY SYNC] Synced active member ${uid} to public directory`);
    } else {
      await directoryRef.delete().catch(() => {});
      console.log(`[DIRECTORY SYNC] Removed inactive member ${uid} from public directory`);
    }
  } catch (err) {
    console.error('[DIRECTORY SYNC ERROR]', err);
  }
}

// Helper: Persistent Rate Limiting
async function checkRateLimit(source: string, limitCount: number = 5, windowMs: number = 3 * 60 * 1000) {
  if (!isAdminInitialized || !dbAdmin) return true; // bypass if offline/sandbox
  try {
    const cleanSource = source.replace(/[@.]/g, '_');
    const docRef = dbAdmin.collection('rateLimits').doc(cleanSource);
    const snap = await docRef.get();
    const now = Date.now();
    
    let requests: number[] = [];
    if (snap.exists) {
      const data = snap.data();
      requests = (data.timestamps || []).filter((t: number) => now - t < windowMs);
    }
    
    if (requests.length >= limitCount) {
      return false;
    }
    
    requests.push(now);
    await docRef.set({ timestamps: requests });
    return true;
  } catch (err) {
    console.error('[RATE LIMIT CHECK ERROR]', err);
    return true; // fail-open in case of database glitches
  }
}

// Middleware: Require App Check Token
async function requireAppCheck(req: any, res: any, next: any) {
  if (!isAdminInitialized || !appCheckAdmin) {
    return next();
  }
  const token = req.headers['x-firebase-appcheck'];
  
  // Sandbox bypass in development and local previews
  if (token === 'sandbox_test_token' || process.env.NODE_ENV !== 'production') {
    return next();
  }
  
  if (!token) {
    return res.status(401).json({ error: 'Unauthorized. Missing Firebase App Check token.' });
  }
  try {
    await appCheckAdmin.verifyToken(token as string);
    next();
  } catch (err: any) {
    console.error('[APP CHECK VERIFICATION FAILED]', err);
    return res.status(401).json({ error: 'Unauthorized. Invalid Firebase App Check token.' });
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Body parser middleware
  app.use(express.json());

  // API endpoints
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      firebaseAdminActive: isAdminInitialized,
      projectId: firebaseConfig.projectId,
    });
  });

  // Helper: Server-Side Authoritative Audit Logging
  async function writeAuditLog(adminName: string, actionType: string, details: string) {
    if (!isAdminInitialized || !dbAdmin) return;
    try {
      const logRef = dbAdmin.collection('auditLog').doc();
      await logRef.set({
        id: `LOG-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`,
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
        adminName,
        actionType,
        details,
        createdAt: FieldValue.serverTimestamp()
      });
      console.log(`[AUDIT LOG] ${actionType}: ${details}`);
    } catch (err) {
      console.error('[AUDIT LOG ERROR]', err);
    }
  }

  // Admin Create Member Endpoint
  app.post('/api/createMember', async (req, res) => {
    const { name, email, barCouncilNo, chapter, memberId, designation } = req.body;

    if (!name || !email || !barCouncilNo || !chapter) {
      return res.status(400).json({ error: 'Missing required member registration fields.' });
    }

    let adminName = 'System Secretariat';

    // 1. Enforce admin checks server-side if Firebase is active
    if (isAdminInitialized) {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Unauthorized. Authorization header is missing.' });
      }
      const idToken = authHeader.split('Bearer ')[1];
      try {
        const decodedToken = await authAdmin.verifyIdToken(idToken);
        if (decodedToken.admin !== true) {
          return res.status(403).json({ error: 'Forbidden. Administrator custom claims required.' });
        }
        adminName = decodedToken.email || decodedToken.name || adminName;
      } catch (error: any) {
        return res.status(401).json({ error: `Unauthorized. Invalid ID Token: ${error.message}` });
      }
    }

    // Generated details
    const finalMemberId = memberId || `PLA-${Math.floor(100000 + Math.random() * 900000)}`;
    const randomPassword = Math.random().toString(36).slice(-12) + 'PLA2026!';

    try {
      if (isAdminInitialized) {
        // 1. Create the user in Firebase Auth with a random password nobody is told
        const userRecord = await authAdmin.createUser({
          email,
          password: randomPassword,
          displayName: name,
        });

        const isAdminUser = isSecretariatAdmin(email);
        const role = isAdminUser ? 'admin' : 'member';

        // 2. Write corresponding members/{uid} doc with status: 'pending' and correct role
        const memberRef = dbAdmin.collection('members').doc(userRecord.uid);
        const memberData = {
          displayName: name,
          email: email.toLowerCase(),
          memberId: finalMemberId,
          barCouncilNo,
          chapter,
          status: 'pending',
          designation: designation || 'Counsel',
          role: role,
          createdAt: FieldValue.serverTimestamp(),
        };
        await memberRef.set(memberData);

        // 3. Sync to limited public directory (since status is pending, this will remove/deny direct placement)
        await syncToDirectory(userRecord.uid, memberData);

        // 4. Set custom user claims if they are in the SECRETARIAT_ADMINS list
        if (isAdminUser) {
          await authAdmin.setCustomUserClaims(userRecord.uid, { admin: true });
          console.log(`[SECURE DECREE] Automatically granted admin custom claims to newly created user: ${email}`);
        }

        // 5. Generate Password Reset Link
        const actionCodeSettings = {
          url: `${req.protocol}://${req.get('host')}/?email=${encodeURIComponent(email)}`,
          handleCodeInApp: true,
        };
        const resetLink = await authAdmin.generatePasswordResetLink(email, actionCodeSettings);

        // Server Audit Log
        await writeAuditLog(adminName, 'MEMBER_ADD', `Successfully enrolled advocate: ${name} (${email}) as pending with ID: ${finalMemberId}`);

        console.log(`[SECURE DECREE] Created pending member/admin: ${name} (${email}). Password Reset Link: ${resetLink}`);

        return res.status(200).json({
          success: true,
          uid: userRecord.uid,
          memberId: finalMemberId,
          resetLink,
          mode: 'real',
          message: 'Member account created successfully in Auth and Firestore.'
        });
      } else {
        // Sandbox fallback for local environment testing
        const fallbackUid = `sandbox-uid-${Date.now()}`;
        const sandboxResetLink = `${req.protocol}://${req.get('host')}/#reset-password?email=${encodeURIComponent(email)}&uid=${fallbackUid}&code=sandbox_code_${Date.now()}`;
        
        console.log(`[SANDBOX DECREE] Created pending member: ${name} (${email}). Reset Link: ${sandboxResetLink}`);

        return res.status(200).json({
          success: true,
          uid: fallbackUid,
          memberId: finalMemberId,
          resetLink: sandboxResetLink,
          mode: 'sandbox',
          message: 'Sandbox member draft created successfully.'
        });
      }
    } catch (error: any) {
      console.error('Error in createMember endpoint:', error);
      return res.status(500).json({
        error: error.message || 'Failed to complete secure member registration.',
      });
    }
  });

  app.post('/api/bulkCreateMembers', async (req, res) => {
    const { members } = req.body;

    if (!Array.isArray(members)) {
      return res.status(400).json({ error: 'Payload must contain a "members" array.' });
    }

    let adminName = 'System Secretariat';

    // 1. Enforce admin checks server-side if Firebase is active
    if (isAdminInitialized) {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Unauthorized. Authorization header is missing.' });
      }
      const idToken = authHeader.split('Bearer ')[1];
      try {
        const decodedToken = await authAdmin.verifyIdToken(idToken);
        if (decodedToken.admin !== true) {
          return res.status(403).json({ error: 'Forbidden. Administrator custom claims required.' });
        }
        adminName = decodedToken.email || decodedToken.name || adminName;
      } catch (error: any) {
        return res.status(401).json({ error: `Unauthorized. Invalid ID Token: ${error.message}` });
      }
    }

    const successful: any[] = [];
    const failed: any[] = [];

    // Process each member individually, catching exceptions per-row so that one failure does not halt the entire batch.
    for (let i = 0; i < members.length; i++) {
      const row = members[i];
      const { displayName, email, memberId, barCouncilNo, chapter, designation } = row;

      // Clean/Trim inputs
      const cleanName = displayName ? String(displayName).trim() : '';
      const cleanEmail = email ? String(email).trim().toLowerCase() : '';
      const cleanBarNo = barCouncilNo ? String(barCouncilNo).trim() : '';
      const cleanChapter = chapter ? String(chapter).trim() : '';
      const cleanMemberId = memberId ? String(memberId).trim() : '';
      const cleanDesignation = designation ? String(designation).trim() : 'Counsel';

      // Validate required fields
      if (!cleanName || !cleanEmail || !cleanBarNo || !cleanChapter) {
        failed.push({
          row,
          error: 'Missing required field(s). All columns are mandatory: displayName, email, barCouncilNo, chapter.'
        });
        continue;
      }

      // Simple email format check
      if (!cleanEmail.includes('@') || !cleanEmail.includes('.')) {
        failed.push({
          row,
          error: `Invalid email address format: "${cleanEmail}"`
        });
        continue;
      }

      // Generate a strong, independent, cryptographically secure random password
      let securePassword = '';
      try {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+~`|}{[]:;?><,./-=';
        const bytes = crypto.randomBytes(24);
        for (let j = 0; j < bytes.length; j++) {
          securePassword += chars[bytes[j] % chars.length];
        }
      } catch (err) {
        securePassword = Math.random().toString(36).slice(-12) + 'PLA2026_Secure!';
      }

      const finalMemberId = cleanMemberId || `PLA-${Math.floor(100000 + Math.random() * 900000)}`;

      try {
        if (isAdminInitialized) {
          // 1. Create user in Firebase Auth with the secure random throwaway password
          const userRecord = await authAdmin.createUser({
            email: cleanEmail,
            password: securePassword,
            displayName: cleanName,
          });

          const isAdminUser = isSecretariatAdmin(cleanEmail);
          const role = isAdminUser ? 'admin' : 'member';

          // 2. Create corresponding members/{uid} Firestore document with status 'pending'
          const memberRef = dbAdmin.collection('members').doc(userRecord.uid);
          const memberData = {
            displayName: cleanName,
            email: cleanEmail,
            memberId: finalMemberId,
            barCouncilNo: cleanBarNo,
            chapter: cleanChapter,
            status: 'pending',
            designation: cleanDesignation,
            role: role,
            createdAt: FieldValue.serverTimestamp(),
          };
          await memberRef.set(memberData);

          // 3. Sync to public directory profile
          await syncToDirectory(userRecord.uid, memberData);

          // 4. Set custom claims if they are in SECRETARIAT_ADMINS
          if (isAdminUser) {
            await authAdmin.setCustomUserClaims(userRecord.uid, { admin: true });
            console.log(`[BULK SECURE DECREE] Automatically granted admin custom claims to: ${cleanEmail}`);
          }

          // 5. Generate Password Reset Link (which queues a branded Set Your Password email setup)
          const actionCodeSettings = {
            url: `${req.protocol}://${req.get('host')}/?email=${encodeURIComponent(cleanEmail)}`,
            handleCodeInApp: true,
          };
          const resetLink = await authAdmin.generatePasswordResetLink(cleanEmail, actionCodeSettings);

          console.log(`[BULK SECURE DECREE] Created pending member/admin: ${cleanName} (${cleanEmail}). Reset Link: ${resetLink}`);

          successful.push({
            displayName: cleanName,
            email: cleanEmail,
            memberId: finalMemberId,
            uid: userRecord.uid,
            resetLink,
            mode: 'real'
          });
        } else {
          // Local/Sandbox Mock Mode
          const fallbackUid = `sandbox-uid-${Date.now()}-${i}`;
          const sandboxResetLink = `${req.protocol}://${req.get('host')}/#reset-password?email=${encodeURIComponent(cleanEmail)}&uid=${fallbackUid}&code=sandbox_code_${Date.now()}_${i}`;

          console.log(`[BULK SANDBOX DECREE] Created pending member: ${cleanName} (${cleanEmail}). Reset Link: ${sandboxResetLink}`);

          successful.push({
            displayName: cleanName,
            email: cleanEmail,
            memberId: finalMemberId,
            uid: fallbackUid,
            resetLink: sandboxResetLink,
            mode: 'sandbox'
          });
        }
      } catch (err: any) {
        console.error(`Bulk creation row failure for ${cleanEmail}:`, err);
        failed.push({
          row,
          error: err.message || 'Authentication system rejection or duplicate registry constraint.'
        });
      }

      // Add small delay (rate limiting outgoing operations)
      if (i < members.length - 1) {
        await new Promise((resolve) => setTimeout(resolve, 200));
      }
    }

    // Write server-side authoritative audit log summarizing bulk ingestion
    await writeAuditLog(adminName, 'BULK_MEMBER_ADD', `Bulk registered pending member dossiers. Successful: ${successful.length}, Failed: ${failed.length}`);

    return res.status(200).json({
      success: true,
      totalProcessed: members.length,
      successfulCount: successful.length,
      failedCount: failed.length,
      successful,
      failed
    });
  });

  // Dynamic /api/registerSignIn Endpoint for auto-granting custom claims to allow-listed admins on first sign-in
  app.post('/api/registerSignIn', async (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Unauthorized. Authorization header is missing.' });
    }

    const idToken = authHeader.split('Bearer ')[1];
    if (!isAdminInitialized) {
      return res.status(200).json({ success: true, mode: 'sandbox', isAdmin: false });
    }

    try {
      const decodedToken = await authAdmin.verifyIdToken(idToken);
      const email = (decodedToken.email || '').toLowerCase();
      const uid = decodedToken.uid;

      // Check if email matches SECRETARIAT_ADMINS list (case-insensitive)
      const matchedAdmin = SECRETARIAT_ADMINS.find(admin => admin.email.toLowerCase() === email);

      if (matchedAdmin) {
        // Set custom claim { admin: true } if not already set on this session token
        if (!decodedToken.admin) {
          await authAdmin.setCustomUserClaims(uid, { admin: true });
          console.log(`[SECURE DECREE] Automatically set admin custom claims on bootstrapped user: ${email}`);
        }

        // Verify or write the members/{uid} document
        const memberRef = dbAdmin.collection('members').doc(uid);
        const docSnap = await memberRef.get();

        const adminMemberData: any = {
          displayName: matchedAdmin.name,
          email: email,
          memberId: `PLA-ADMIN-${Math.floor(100000 + Math.random() * 900000)}`,
          barCouncilNo: 'SECRETARIAT-ADMIN',
          chapter: 'Punjab Bar Council',
          status: 'active',
          designation: matchedAdmin.designation,
          role: 'admin',
        };

        if (!docSnap.exists) {
          adminMemberData.createdAt = FieldValue.serverTimestamp();
          await memberRef.set(adminMemberData);
          console.log(`[SECURE DECREE] Automatically wrote Firestore doc for allow-listed admin: ${email}`);
        } else {
          // Maintain active and admin status
          await memberRef.update({
            role: 'admin',
            status: 'active'
          });
          const freshSnap = await memberRef.get();
          Object.assign(adminMemberData, freshSnap.data());
        }

        // Sync to Directory
        await syncToDirectory(uid, adminMemberData);

        return res.status(200).json({
          success: true,
          isAdmin: true,
          message: 'Admin access verified and configured successfully.'
        });
      }

      // Sync regular user's active status from DB if it exists
      const memberRef = dbAdmin.collection('members').doc(uid);
      const docSnap = await memberRef.get();
      if (docSnap.exists) {
        await syncToDirectory(uid, docSnap.data());
      }

      return res.status(200).json({
        success: true,
        isAdmin: false,
        message: 'Regular member credentials verified.'
      });
    } catch (error: any) {
      console.error('Error in /api/registerSignIn:', error);
      return res.status(500).json({ error: error.message || 'Validation failed.' });
    }
  });

  // Secure Announcements Management Endpoints
  app.post('/api/createAnnouncement', async (req, res) => {
    let adminName = 'System Secretariat';
    let uid = 'sandbox-admin-uid';
    let email = 'sandbox@admin.com';

    if (isAdminInitialized) {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Unauthorized. Authorization header is missing.' });
      }
      const idToken = authHeader.split('Bearer ')[1];
      try {
        const decodedToken = await authAdmin.verifyIdToken(idToken);
        email = (decodedToken.email || '').toLowerCase();
        uid = decodedToken.uid;
        
        const isAdminUser = decodedToken.admin === true || isSecretariatAdmin(email);
        if (!isAdminUser) {
          return res.status(403).json({ error: 'Forbidden. Administrator custom claims required.' });
        }
        
        adminName = email;
      } catch (error: any) {
        return res.status(401).json({ error: `Unauthorized. Invalid ID Token: ${error.message}` });
      }
    }

    const { title, body, category, chapter, eventDate, eventLocation } = req.body;

    if (!title || !body || !category || !chapter) {
      return res.status(400).json({ error: 'Missing required announcement fields.' });
    }

    if (category === 'Upcoming Event' && (!eventDate || !eventLocation)) {
      return res.status(400).json({ error: 'Upcoming Events require eventDate and eventLocation.' });
    }

    // postedBy — auto-filled from the signed-in admin's displayName (from their members doc)
    let postedBy = 'Farhat Abbas'; // Default fallback
    if (isAdminInitialized && dbAdmin) {
      try {
        const memberSnap = await dbAdmin.collection('members').doc(uid).get();
        if (memberSnap.exists) {
          postedBy = memberSnap.data().displayName || postedBy;
        } else {
          const matched = SECRETARIAT_ADMINS.find(admin => admin.email.toLowerCase() === email);
          if (matched) {
            postedBy = matched.name;
          }
        }
      } catch (err) {
        console.warn('Error fetching member displayName for announcement postedBy:', err);
      }
    }

    try {
      const announcementData: any = {
        title: title.trim(),
        body: body.trim(),
        category,
        chapter,
        postedBy,
        createdAt: FieldValue.serverTimestamp(),
        updatedAt: FieldValue.serverTimestamp()
      };

      if (category === 'Upcoming Event') {
        announcementData.eventDate = eventDate;
        announcementData.eventLocation = eventLocation;
      }

      let docId = `ANN-NEW-${Date.now()}`;
      if (isAdminInitialized && dbAdmin) {
        const docRef = await dbAdmin.collection('announcements').add(announcementData);
        docId = docRef.id;
      }

      await writeAuditLog(postedBy, 'ANNOUNCEMENT_PUBLISH', `Created announcement "${title}" with ID ${docId}`);

      return res.status(200).json({
        success: true,
        id: docId,
        announcement: {
          id: docId,
          ...announcementData,
          date: new Date().toISOString().split('T')[0]
        }
      });
    } catch (error: any) {
      console.error('Error creating announcement:', error);
      return res.status(500).json({ error: 'Failed to create announcement.' });
    }
  });

  app.post('/api/updateAnnouncement', async (req, res) => {
    let adminName = 'System Secretariat';
    let uid = 'sandbox-admin-uid';
    let email = 'sandbox@admin.com';

    if (isAdminInitialized) {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Unauthorized. Authorization header is missing.' });
      }
      const idToken = authHeader.split('Bearer ')[1];
      try {
        const decodedToken = await authAdmin.verifyIdToken(idToken);
        email = (decodedToken.email || '').toLowerCase();
        uid = decodedToken.uid;

        const isAdminUser = decodedToken.admin === true || isSecretariatAdmin(email);
        if (!isAdminUser) {
          return res.status(403).json({ error: 'Forbidden. Administrator custom claims required.' });
        }

        adminName = email;
      } catch (error: any) {
        return res.status(401).json({ error: `Unauthorized. Invalid ID Token: ${error.message}` });
      }
    }

    const { id, title, body, category, chapter, eventDate, eventLocation } = req.body;

    if (!id || !title || !body || !category || !chapter) {
      return res.status(400).json({ error: 'Missing required announcement fields.' });
    }

    if (category === 'Upcoming Event' && (!eventDate || !eventLocation)) {
      return res.status(400).json({ error: 'Upcoming Events require eventDate and eventLocation.' });
    }

    let postedBy = 'Farhat Abbas';
    if (isAdminInitialized && dbAdmin) {
      try {
        const memberSnap = await dbAdmin.collection('members').doc(uid).get();
        if (memberSnap.exists) {
          postedBy = memberSnap.data().displayName || postedBy;
        } else {
          const matched = SECRETARIAT_ADMINS.find(admin => admin.email.toLowerCase() === email);
          if (matched) {
            postedBy = matched.name;
          }
        }
      } catch (err) {
        console.warn('Error fetching member displayName for announcement postedBy:', err);
      }
    }

    try {
      const updateData: any = {
        title: title.trim(),
        body: body.trim(),
        category,
        chapter,
        postedBy,
        updatedAt: FieldValue.serverTimestamp()
      };

      if (category === 'Upcoming Event') {
        updateData.eventDate = eventDate;
        updateData.eventLocation = eventLocation;
      } else {
        updateData.eventDate = null;
        updateData.eventLocation = null;
      }

      if (isAdminInitialized && dbAdmin) {
        const docRef = dbAdmin.collection('announcements').doc(id);
        await docRef.update(updateData);
      }

      await writeAuditLog(postedBy, 'ANNOUNCEMENT_EDIT', `Updated announcement "${title}" with ID ${id}`);

      return res.status(200).json({
        success: true,
        id,
        announcement: {
          id,
          ...updateData,
          date: new Date().toISOString().split('T')[0]
        }
      });
    } catch (error: any) {
      console.error('Error updating announcement:', error);
      return res.status(500).json({ error: 'Failed to update announcement.' });
    }
  });

  app.post('/api/deleteAnnouncement', async (req, res) => {
    let adminName = 'System Secretariat';
    let uid = 'sandbox-admin-uid';
    let email = 'sandbox@admin.com';

    if (isAdminInitialized) {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Unauthorized. Authorization header is missing.' });
      }
      const idToken = authHeader.split('Bearer ')[1];
      try {
        const decodedToken = await authAdmin.verifyIdToken(idToken);
        email = (decodedToken.email || '').toLowerCase();
        uid = decodedToken.uid;

        const isAdminUser = decodedToken.admin === true || isSecretariatAdmin(email);
        if (!isAdminUser) {
          return res.status(403).json({ error: 'Forbidden. Administrator custom claims required.' });
        }

        adminName = email;
      } catch (error: any) {
        return res.status(401).json({ error: `Unauthorized. Invalid ID Token: ${error.message}` });
      }
    }

    const { id } = req.body;

    if (!id) {
      return res.status(400).json({ error: 'Missing required announcement ID.' });
    }

    let postedBy = 'Farhat Abbas';
    if (isAdminInitialized && dbAdmin) {
      try {
        const memberSnap = await dbAdmin.collection('members').doc(uid).get();
        if (memberSnap.exists) {
          postedBy = memberSnap.data().displayName || postedBy;
        } else {
          const matched = SECRETARIAT_ADMINS.find(admin => admin.email.toLowerCase() === email);
          if (matched) {
            postedBy = matched.name;
          }
        }
      } catch (err) {
        console.warn('Error fetching member displayName for delete announcement:', err);
      }
    }

    try {
      if (isAdminInitialized && dbAdmin) {
        await dbAdmin.collection('announcements').doc(id).delete();
      }

      await writeAuditLog(postedBy, 'ANNOUNCEMENT_DELETE', `Deleted announcement with ID ${id}`);

      return res.status(200).json({
        success: true,
        id
      });
    } catch (error: any) {
      console.error('Error deleting announcement:', error);
      return res.status(500).json({ error: 'Failed to delete announcement.' });
    }
  });

  // Server-Side Member Activation Endpoint (Server-Side Only State Transition)
  app.post('/api/activateMember', async (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Unauthorized. Authorization header is missing.' });
    }

    const idToken = authHeader.split('Bearer ')[1];
    if (!isAdminInitialized) {
      return res.status(200).json({ success: true, mode: 'sandbox', message: 'Sandbox bypass success.' });
    }

    try {
      const decodedToken = await authAdmin.verifyIdToken(idToken);
      const uid = decodedToken.uid;
      const email = (decodedToken.email || '').toLowerCase();

      const memberRef = dbAdmin.collection('members').doc(uid);
      const docSnap = await memberRef.get();

      if (!docSnap.exists) {
        return res.status(404).json({ error: 'Member profile not found in Central Registry.' });
      }

      // Autoritative Server-Side update
      await memberRef.update({
        status: 'active',
        activatedAt: FieldValue.serverTimestamp()
      });

      const updatedSnap = await memberRef.get();
      const updatedData = updatedSnap.data();

      // Synchronize with public directory profile
      await syncToDirectory(uid, updatedData);

      // Audit logs
      await writeAuditLog(email, 'MEMBER_ACTIVATE', `Advocate profile ${email} successfully activated credentials.`);

      return res.status(200).json({
        success: true,
        message: 'Your Pakistan Legal Alliance registry credentials have been established successfully.',
        displayName: updatedData.displayName || '',
        memberId: updatedData.memberId || ''
      });
    } catch (error: any) {
      console.error('Error in /api/activateMember:', error);
      return res.status(500).json({ error: error.message || 'Activation handshake failed.' });
    }
  });

  // Public: Secure Request Password Reset (Forgot Password Flow) with Rate-Limiting & App Check
  app.post('/api/requestPasswordReset', requireAppCheck, async (req, res) => {
    const { email } = req.body;
    const ip = req.ip || req.headers['x-forwarded-for'] || 'unknown-ip';

    const cleanEmail = email ? String(email).trim().toLowerCase() : '';
    if (!cleanEmail) {
      return res.status(400).json({ error: 'Valid registry email is required.' });
    }

    // Abuse Protection: Persistent rate limiting
    const ipLimitOk = await checkRateLimit(`pwd_reset_ip_${ip}`, 5, 3 * 60 * 1000); // 5 requests per 3 mins
    const emailLimitOk = await checkRateLimit(`pwd_reset_email_${cleanEmail}`, 3, 5 * 60 * 1000); // 3 requests per 5 mins

    if (!ipLimitOk || !emailLimitOk) {
      return res.status(429).json({ error: 'Rate limit exceeded. Please wait a few minutes before submitting again.' });
    }

    let resetLink = '';

    if (isAdminInitialized) {
      try {
        const userRecord = await authAdmin.getUserByEmail(cleanEmail);
        const actionCodeSettings = {
          url: `${req.protocol}://${req.get('host')}/?email=${encodeURIComponent(cleanEmail)}`,
          handleCodeInApp: true,
        };
        resetLink = await authAdmin.generatePasswordResetLink(cleanEmail, actionCodeSettings);
      } catch (err: any) {
        // Keep it neutral. Do not leak registry information or if user exists.
        console.warn(`[PASSWORD RESET ATTEMPT] Email not found or inactive: ${cleanEmail}`);
      }
    } else {
      // Sandbox fallback link
      resetLink = `${req.protocol}://${req.get('host')}/#reset-password?email=${encodeURIComponent(cleanEmail)}&uid=sandbox-uid-${Date.now()}&code=sandbox_reset_code`;
    }

    // Unified correctly branded email layout in PLA Voice
    const emailTemplate = `
======================================================================
FROM: Pakistan Legal Alliance Secretariat <registry@pakistanlegalalliance.org>
TO: ${cleanEmail}
SUBJECT: Secure Advocate Registry Password Establishment
----------------------------------------------------------------------
DEAR COUNSEL,

An official security transmission has been dispatched to establish or 
reset your access credentials to the Pakistan Legal Alliance (PLA) Central 
Registry.

Please utilize the secure cryptographic link below to configure your password:
${resetLink}

This link is cryptographically signed and will expire shortly.

If you did not request this transmission, please ignore this notice or 
contact the Central Registry Secretariat immediately.

REGARDS,
PLA CENTRAL ASSOCIATION & REGISTRY SECRETARIAT
======================================================================
    `;
    console.log(emailTemplate);

    // Neutral security response
    return res.status(200).json({
      success: true,
      message: 'If an active registry dossier matches, a secure branded transmission was dispatched to set your credentials.'
    });
  });

  // Public: Submit Contact Message with Rate-Limiting, Honeypot, and App Check
  app.post('/api/submitContact', requireAppCheck, async (req, res) => {
    const { name, email, subject, message, faxNumber } = req.body;
    const ip = req.ip || req.headers['x-forwarded-for'] || 'unknown-ip';

    // 1. Honeypot check
    if (faxNumber) {
      console.warn(`[SPAM BLOCK] Contact honeypot triggered from IP: ${ip}`);
      return res.status(200).json({ success: true, message: 'Message logged in secure buffer.' });
    }

    if (!name || !email || !subject || !message) {
      return res.status(400).json({ error: 'Missing required contact submission fields.' });
    }

    // 2. Persistent rate limiting
    const ipLimitOk = await checkRateLimit(`contact_ip_${ip}`, 4, 3 * 60 * 1000); // 4 submissions per 3 mins
    if (!ipLimitOk) {
      return res.status(429).json({ error: 'Transmission frequency exceeded. Please retry in a few minutes.' });
    }

    try {
      if (isAdminInitialized) {
        await dbAdmin.collection('contactMessages').add({
          name: name.trim(),
          email: email.trim().toLowerCase(),
          subject: subject.trim(),
          message: message.trim(),
          createdAt: FieldValue.serverTimestamp()
        });
      }

      console.log(`[CONTACT DISPATCH] Recorded incoming inquiry from ${name} (${email}) regarding ${subject}`);
      return res.status(200).json({ success: true, message: 'Your message has been successfully routed.' });
    } catch (err: any) {
      console.error('Contact submission error:', err);
      return res.status(500).json({ error: 'Failed to record correspondence dossier.' });
    }
  });

  // Public: Submit Recruitment Application with Rate-Limiting, Honeypot, and App Check
  app.post('/api/submitRecruitment', requireAppCheck, async (req, res) => {
    const { fullName, email, position, enrolmentNumber, coverNote, cvFileName, faxNumber } = req.body;
    const ip = req.ip || req.headers['x-forwarded-for'] || 'unknown-ip';

    // 1. Honeypot check
    if (faxNumber) {
      console.warn(`[SPAM BLOCK] Recruitment honeypot triggered from IP: ${ip}`);
      return res.status(200).json({ success: true, message: 'Dossier successfully processed.' });
    }

    if (!fullName || !email || !position) {
      return res.status(400).json({ error: 'Missing required recruitment fields.' });
    }

    // 2. Persistent rate limiting
    const ipLimitOk = await checkRateLimit(`recruitment_ip_${ip}`, 3, 3 * 60 * 1000); // 3 applications per 3 mins
    if (!ipLimitOk) {
      return res.status(429).json({ error: 'Transmission frequency exceeded. Please retry in a few minutes.' });
    }

    try {
      if (isAdminInitialized) {
        await dbAdmin.collection('applications').add({
          fullName: fullName.trim(),
          email: email.trim().toLowerCase(),
          position: position.trim(),
          enrolmentNumber: (enrolmentNumber || '').trim(),
          coverNote: (coverNote || '').trim(),
          cvFileName: cvFileName || 'Uploaded Dossier.pdf',
          createdAt: FieldValue.serverTimestamp()
        });
      }

      console.log(`[RECRUITMENT DISPATCH] Recorded career application from ${fullName} (${email}) for position: ${position}`);
      return res.status(200).json({ success: true, message: 'Application dossier recorded successfully.' });
    } catch (err: any) {
      console.error('Recruitment submission error:', err);
      return res.status(500).json({ error: 'Failed to record career application dossier.' });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Auto-Seed Announcements/Past Events if not already present
  async function seedAnnouncements() {
    if (!isAdminInitialized || !dbAdmin) {
      console.log('[SEED] Skipping announcements seed (Firebase not initialized or in sandbox mode)');
      return;
    }
    try {
      const annColl = dbAdmin.collection('announcements');
      const snap = await annColl.where('title', '==', 'Introducing the PLA Punjab Chapter 2026–2027!').get();
      if (snap.empty) {
        console.log('[SEED] Seeding the 5 new past events & announcements into Firestore...');
        
        const newItems = [
          {
            title: 'Introducing the PLA Punjab Chapter 2026–2027!',
            category: 'Notice',
            body: 'Pakistan Legal Alliance is proud to officially announce the leadership and Campus Ambassadors of the Punjab Chapter for the session 2026–2027!\n\nChapter Leadership:\n• Hussain Ahmad – Chapter Head\n• M. Yahya Sohail – Deputy Head\n• Muhammad Hassaan – Secretary Head\n\nCampus Ambassadors:\n• Anadil – IIUI\n• Duaa Kazmi – Quaid e Azam Law College, Lahore\n• Mubeen Shoukat – Faisalabad College of Law\n• Shehryar Ali – School of Law, Lahore\n• M. Farhan Wali – Punjab University, Lahore\n• Afnan Bhatti – Superior College of Law\n• Zaryab Zafar – Rawalpindi Law College\n\nPunjab is one of PLA\'s most active provinces, and this team carries the responsibility of representing PLA\'s mission across some of the most prestigious law schools in the region.',
            date: '2026-07-20',
            postedBy: 'PLA Secretariat',
            chapter: 'Lahore Chapter',
            createdAt: FieldValue.serverTimestamp()
          },
          {
            title: 'Welcome to the PLA Punjab Chapter 2026–2027 — Campus Ambassadors!',
            category: 'Notice',
            body: 'Pakistan Legal Alliance is proud to introduce another outstanding group of Campus Ambassadors and General Members representing the Punjab Chapter for the session 2026–2027!\n\nCampus Ambassadors & General Members:\n• Hafiza Arooj – Business & Law School\n• Komal Shehzadi – College of Law, GRW\n• Tayyaba Batool – Quaid e Azam Law College, Lahore (General Member)\n• Hafiza Maheen – Toppers Law College, Lahore\n• Farah Ramzan – College of Law, Narowal\n• Ifra Kanwal – Chenab College, Gujrat\n• Ayman Shabbir – Muslim Law College, RWP\n• Adv. Aliza Ali – Punjab University, Faisalabad\n• Zoha Raza – Chiefs Law College\n• Noor Ul Huda – Kahuta Law College\n• Umme Roman Awan – University of Punjab',
            date: '2026-07-20',
            postedBy: 'PLA Secretariat',
            chapter: 'Lahore Chapter',
            createdAt: FieldValue.serverTimestamp()
          },
          {
            title: 'Webinar: From FIR to Pre-Arrest Bail & Understanding Your Legal Rights',
            category: 'Upcoming Event',
            body: 'Pakistan Legal Alliance (PLA) – Punjab Chapter proudly presents an interactive Webinar on:\n"From FIR to Pre-Arrest Bail & Understanding Your Legal Rights"\n\nSpeaker: Mian Maqsood, Advocate\n\nRegistration Link:\nhttps://docs.google.com/forms/d/e/1FAIpQLSdxFfTzFXhVIf--h78guxW37-sO6l75tmur1svldZOVAE57Rg/viewform?usp=header\n\nThis webinar provides practical insight into the criminal justice process, covering FIR registration, pre-arrest bail, and the legal rights every citizen and aspiring lawyer should understand.\n\nDate: 11th & 12th July 2026 (Saturday & Sunday)\nTime: 7:00 PM – 8:30 PM\nMode: Google Meet & YouTube (Online)\nRegistration Fee: FREE OF COST\n🎖️ E-Certificates will be provided to participants.',
            date: '2026-07-08',
            postedBy: 'Mian Maqsood, Advocate',
            chapter: 'Lahore Chapter',
            eventDate: '2026-07-11',
            eventLocation: 'Google Meet & YouTube (Online)',
            createdAt: FieldValue.serverTimestamp()
          },
          {
            title: 'Introducing the PLA Balochistan Chapter 2026–2027!',
            category: 'Notice',
            body: 'Pakistan Legal Alliance is proud to officially announce the leadership, Campus Ambassadors, and General Members of the Balochistan Chapter for the session 2026–2027!\n\nChapter Leadership:\n• Hira Shehzad – Chapter Head\n• Gul Zaman – Secretary Head\n\nCampus Ambassadors:\n• Moen Khan – Shaheed Zulfiqar Ali Bhutto University of Law (SZABUL)\n• Saima – National Law College\n• Meer Mavia Lasi – Quetta Law College\n\nGeneral Members:\n• Sami Ullah Barech\n\nBalochistan is a province of immense potential and PLA is committed to making its voice heard through legal education and awareness. This team carries that responsibility with pride. Welcome aboard!',
            date: '2026-07-19',
            postedBy: 'PLA Secretariat',
            chapter: 'Quetta Chapter',
            createdAt: FieldValue.serverTimestamp()
          },
          {
            title: 'Introducing the PLA Sindh Chapter 2026–2027!',
            category: 'Notice',
            body: 'Pakistan Legal Alliance is proud to officially announce the leadership, Campus Ambassadors, and General Members of the Sindh Chapter for the session 2026–2027!\n\nChapter Leadership:\n• Zahid Ashraf – Chapter Head\n• Alishba Farooq – Secretary Head\n\nCampus Ambassadors:\n• Ahmed Raza – Shah Abdul Latif University\n• Abdul Khalil – Indus College of Law\n• Asad Ali – Hyderabad University\n• Rajesh Kumar – Govt Sindh Law College\n\nGeneral Members:\n• SanaUllah\n• Zartab Riaz\n• Sher Ali\n• Azizullah Chandio\n\nSindh has a rich legal heritage and PLA is proud to plant its roots deeper into this province with a committed and capable team. Welcome aboard — the mission of legal awareness continues to grow!',
            date: '2026-07-19',
            postedBy: 'PLA Secretariat',
            chapter: 'Karachi Chapter',
            createdAt: FieldValue.serverTimestamp()
          }
        ];

        for (const item of newItems) {
          await annColl.add(item);
        }
        console.log('[SEED] Successfully seeded announcements!');
      } else {
        console.log('[SEED] Seeding skipped: Punjab Chapter announcement already present in Firestore.');
      }
    } catch (err: any) {
      if (err?.code === 7 || (err?.message && String(err.message).includes('PERMISSION_DENIED'))) {
        console.log('[SEED] Skipping server-side seed (Firebase Admin SDK lacking GCP IAM permissions in sandbox environment)');
      } else {
        console.error('[SEED ERROR] Failed to check/seed announcements:', err);
      }
    }
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
    seedAnnouncements().catch(err => console.error('[SEED RUN ERROR]', err));
  });
}

startServer();
